import os
import sqlite3
import tempfile


def connect_database(database_path, *, rows=False, read_only=False):
    if read_only:
        uri = f"file:{os.path.abspath(database_path)}?mode=ro"
        connection = sqlite3.connect(uri, uri=True, timeout=30)
    else:
        connection = sqlite3.connect(database_path, timeout=30)
    connection.execute("PRAGMA foreign_keys = ON")
    connection.execute("PRAGMA busy_timeout = 5000")
    if rows:
        connection.row_factory = sqlite3.Row
    return connection


def database_health(database_path):
    try:
        with connect_database(database_path, read_only=True) as connection:
            row = connection.execute("PRAGMA quick_check").fetchone()
        return bool(row and row[0] == "ok"), None
    except (OSError, sqlite3.Error) as error:
        return False, str(error)


def create_consistent_backup(database_path, output_dir=None):
    output_dir = output_dir or tempfile.gettempdir()
    descriptor, backup_path = tempfile.mkstemp(
        prefix="hospital-backup-", suffix=".db", dir=output_dir
    )
    os.close(descriptor)

    try:
        with connect_database(database_path, read_only=True) as source:
            with connect_database(backup_path) as destination:
                source.backup(destination)
                check = destination.execute("PRAGMA integrity_check").fetchone()
                if not check or check[0] != "ok":
                    raise sqlite3.DatabaseError("備份完整性檢查失敗")
        os.chmod(backup_path, 0o600)
        return backup_path
    except Exception:
        remove_file_quietly(backup_path)
        raise


def remove_file_quietly(path):
    try:
        os.remove(path)
    except FileNotFoundError:
        pass
