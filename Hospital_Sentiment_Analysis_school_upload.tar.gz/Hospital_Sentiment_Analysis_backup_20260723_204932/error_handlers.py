import logging

from flask import g, jsonify, render_template, request

from access_control import wants_json_response


LOGGER = logging.getLogger(__name__)


def register_error_handlers(app):
    def error_response(status_code, message):
        request_id = getattr(g, "request_id", None)
        if wants_json_response():
            return jsonify(
                {
                    "error": message,
                    "status": status_code,
                    "request_id": request_id,
                }
            ), status_code
        return render_template(
            "error.html",
            status_code=status_code,
            message=message,
            request_id=request_id,
        ), status_code

    @app.errorhandler(400)
    def bad_request(error):
        return error_response(400, "請求格式不正確，請確認內容後再試一次。")

    @app.errorhandler(403)
    def forbidden(error):
        return error_response(403, "您沒有權限執行這項操作。")

    @app.errorhandler(404)
    def not_found(error):
        return error_response(404, "找不到您要查看的內容。")

    @app.errorhandler(405)
    def method_not_allowed(error):
        return error_response(405, "這個網址不接受目前的操作方式。")

    @app.errorhandler(429)
    def rate_limited(error):
        return error_response(429, "操作太頻繁，請稍後再試。")

    @app.errorhandler(500)
    def internal_error(error):
        LOGGER.error(
            "unhandled_request_error",
            extra={
                "request_id": getattr(g, "request_id", None),
                "method": request.method,
                "path": request.path,
            },
            exc_info=(type(error), error, error.__traceback__),
        )
        return error_response(500, "系統暫時無法處理請求，請稍後再試。")
