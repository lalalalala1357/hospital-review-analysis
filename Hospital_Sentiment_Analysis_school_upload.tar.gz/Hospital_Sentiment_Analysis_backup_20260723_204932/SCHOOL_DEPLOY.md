# 學校專題主機 Docker 部署

這份資料夾已保留：

- `.env`：包含目前的 API key 與系統設定
- `hospital_reviews.db`：目前資料庫
- `Chrome_Spider_Profile/`：Chrome 爬蟲登入與瀏覽器設定檔
- `data/`：醫院清單與上傳資料

## 上傳到主機

把整包資料夾上傳到學校主機後，進入資料夾：

```bash
cd Hospital_Sentiment_Analysis_school_upload
```

如果老師要從別台電腦連到主機，請把 `.env` 裡這行改成：

```env
BIND_ADDRESS=0.0.0.0
```

如果只在主機本機測試，維持 `BIND_ADDRESS=127.0.0.1` 即可。

## 啟動

```bash
docker compose up -d --build
```

開啟：

```text
http://主機IP:5007
```

## 爬蟲設定

Dockerfile 已安裝：

- Chromium
- Chromium Driver
- Noto 中文字型

docker-compose 會掛載：

```text
./Chrome_Spider_Profile:/app/Chrome_Spider_Profile
```

所以 Chrome 的登入與瀏覽器設定檔不會被 Docker build 清掉。

## 建議先修正 Linux 主機權限

Dockerfile 內的程式使用者是 `app`，UID 是 `10001`。上傳到 Linux 主機後，建議先讓這個使用者可以寫入資料庫、Chrome profile 與 debug 資料夾：

```bash
sudo chown -R 10001:10001 Chrome_Spider_Profile data debug hospital_reviews.db
```

再啟動 Docker。

## 如果 Chrome profile 權限仍不能寫入

如果爬蟲啟動時出現 Chrome profile 權限錯誤，在主機資料夾執行：

```bash
sudo chown -R 10001:10001 Chrome_Spider_Profile data debug hospital_reviews.db
```

再重啟：

```bash
docker compose restart
```

## 查看狀態

```bash
docker compose ps
docker compose logs -f hospital-sentiment
```

## 停止

```bash
docker compose down
```
