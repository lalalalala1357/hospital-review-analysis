(function () {
  const iconClasses = {
    success: 'fas fa-circle-check',
    error: 'fas fa-circle-exclamation',
    warning: 'fas fa-triangle-exclamation',
    info: 'fas fa-circle-info',
  };

  function toastRegion() {
    let region = document.getElementById('productToastRegion');
    if (region) return region;
    region = document.createElement('div');
    region.id = 'productToastRegion';
    region.className = 'product-toast-region';
    region.setAttribute('aria-live', 'polite');
    region.setAttribute('aria-atomic', 'false');
    document.body.appendChild(region);
    return region;
  }

  function notify(message, type = 'info', options = {}) {
    const tone = iconClasses[type] ? type : 'info';
    const item = document.createElement('div');
    item.className = `product-toast ${tone}`;
    item.setAttribute('role', tone === 'error' ? 'alert' : 'status');

    const icon = document.createElement('i');
    icon.className = iconClasses[tone];
    icon.setAttribute('aria-hidden', 'true');
    const content = document.createElement('div');
    content.className = 'product-toast-message';
    content.textContent = String(message || '系統暫時無法處理請求。');
    const closeButton = document.createElement('button');
    closeButton.type = 'button';
    closeButton.className = 'product-toast-close';
    closeButton.setAttribute('aria-label', '關閉通知');
    closeButton.innerHTML = '<i class="fas fa-xmark" aria-hidden="true"></i>';
    closeButton.addEventListener('click', () => item.remove());
    item.append(icon, content, closeButton);
    toastRegion().appendChild(item);

    const duration = Number(options.duration || (tone === 'error' ? 8000 : 5000));
    if (duration > 0) window.setTimeout(() => item.remove(), duration);
    return item;
  }

  function setInlineStatus(element, message, type = 'info') {
    if (!element) return;
    element.textContent = String(message || '');
    element.classList.remove('error', 'success');
    if (type === 'error' || type === 'success') element.classList.add(type);
  }

  function errorMessage(response, payload, fallback) {
    if (response?.status === 429) return '操作太頻繁，請稍後再試。';
    if (response?.status === 400) return payload?.message || '請求已失效，請重新整理後再試。';
    if (response?.status === 401 || response?.status === 403) return '登入狀態已失效，請重新登入。';
    return payload?.message || payload?.error || fallback || '系統暫時無法處理請求。';
  }

  function confirmAction(message, options = {}) {
    return new Promise(resolve => {
      const dialog = document.createElement('dialog');
      dialog.className = 'product-confirm-dialog';
      dialog.innerHTML = `
        <div class="product-confirm-body">
          <h2></h2>
          <p></p>
        </div>
        <div class="product-confirm-actions">
          <button type="button" class="product-confirm-cancel">取消</button>
          <button type="button" class="product-confirm-submit">確認</button>
        </div>`;
      dialog.querySelector('h2').textContent = options.title || '確認操作';
      dialog.querySelector('p').textContent = message;
      dialog.querySelector('.product-confirm-submit').textContent = options.confirmLabel || '確認';
      if (options.tone === 'neutral') {
        dialog.querySelector('.product-confirm-submit').classList.add('neutral');
      }
      document.body.appendChild(dialog);
      let settled = false;
      const finish = value => {
        if (settled) return;
        settled = true;
        resolve(value);
        dialog.close();
      };
      dialog.querySelector('.product-confirm-cancel').addEventListener('click', () => finish(false));
      dialog.querySelector('.product-confirm-submit').addEventListener('click', () => finish(true));
      dialog.addEventListener('cancel', event => {
        event.preventDefault();
        finish(false);
      });
      dialog.addEventListener('close', () => {
        if (!settled) {
          settled = true;
          resolve(false);
        }
        dialog.remove();
      });
      dialog.showModal();
    });
  }

  async function confirmFormSubmission(form) {
    const message = form.dataset.confirmMessage;
    if (!message || form.dataset.confirmed === 'true') return;
    const accepted = await confirmAction(message, {
      confirmLabel: form.dataset.confirmLabel,
      tone: form.dataset.confirmTone,
    });
    if (!accepted) return;
    form.dataset.confirmed = 'true';
    form.requestSubmit();
    window.setTimeout(() => delete form.dataset.confirmed, 0);
  }

  document.addEventListener('submit', event => {
    const form = event.target.closest('form[data-confirm-message]');
    if (!form || form.dataset.confirmed === 'true') return;
    event.preventDefault();
    confirmFormSubmission(form);
  });

  document.addEventListener('click', event => {
    const button = event.target.closest('button[data-confirm-message], input[type="submit"][data-confirm-message]');
    if (!button || button.dataset.confirmed === 'true') return;
    const form = button.form;
    if (!form) return;
    event.preventDefault();
    confirmAction(button.dataset.confirmMessage, {
      confirmLabel: button.dataset.confirmLabel,
      tone: button.dataset.confirmTone,
    }).then(accepted => {
      if (!accepted) return;
      button.dataset.confirmed = 'true';
      form.requestSubmit(button);
      delete button.dataset.confirmed;
    });
  });

  window.ProductUI = { notify, confirm: confirmAction, setInlineStatus, errorMessage };
})();
