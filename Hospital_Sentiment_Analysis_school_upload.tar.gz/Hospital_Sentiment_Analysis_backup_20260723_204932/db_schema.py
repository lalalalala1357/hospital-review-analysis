import json
import logging
from datetime import datetime

from database import connect_database


LOGGER = logging.getLogger(__name__)

DEFAULT_STOP_WORDS = [
    "可以", "沒有", "有些", "比較", "真的", "非常", "以為", "其實",
    "結果", "這樣", "只是", "還是", "一點", "一下", "一樣", "一般",
    "稍微", "感覺", "覺得", "主要", "重要", "普通", "正常", "好",
    "可能", "部分", "雖然", "但是", "不過", "甚至", "已經", "醫生",
    "醫師", "護理師", "護士",
]


def _columns(connection, table_name):
    return {
        row[1]: row
        for row in connection.execute(f'PRAGMA table_info("{table_name}")').fetchall()
    }


def _add_column(connection, table_name, column_name, definition):
    if column_name not in _columns(connection, table_name):
        connection.execute(
            f'ALTER TABLE "{table_name}" ADD COLUMN "{column_name}" {definition}'
        )


def _create_tables(connection):
    statements = [
        """
        CREATE TABLE IF NOT EXISTS users(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            reset_token TEXT,
            is_admin INTEGER NOT NULL DEFAULT 0,
            role TEXT NOT NULL DEFAULT 'user',
            hospital_id INTEGER,
            approval_status TEXT NOT NULL DEFAULT 'approved',
            official_email TEXT,
            contact_name TEXT,
            contact_phone TEXT,
            institution_code TEXT,
            requested_hospital_name TEXT,
            rejection_reason TEXT,
            proof_document TEXT,
            is_active INTEGER NOT NULL DEFAULT 1,
            deleted_at TEXT,
            FOREIGN KEY(hospital_id) REFERENCES hospitals(id)
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS hospitals(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            address TEXT,
            google_place_id TEXT UNIQUE,
            created_at TEXT,
            latitude REAL,
            longitude REAL
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS reviews(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            hospital_id INTEGER NOT NULL,
            author TEXT,
            content TEXT,
            rating REAL,
            review_time TEXT,
            analyzed_sentiment TEXT,
            stored_at TEXT,
            department TEXT DEFAULT '綜合/未提及',
            FOREIGN KEY(hospital_id) REFERENCES hospitals(id)
        )
        """,
        "CREATE TABLE IF NOT EXISTS stop_words(id INTEGER PRIMARY KEY AUTOINCREMENT, word TEXT UNIQUE NOT NULL)",
        """
        CREATE TABLE IF NOT EXISTS sentiment_audit_batches(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            batch_name TEXT,
            sample_size INTEGER DEFAULT 30,
            status TEXT DEFAULT 'pending',
            created_at TEXT,
            completed_at TEXT
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS sentiment_audit_items(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            batch_id INTEGER NOT NULL,
            review_id INTEGER NOT NULL,
            manual_sentiment TEXT,
            model_sentiment TEXT,
            is_correct INTEGER,
            created_at TEXT,
            FOREIGN KEY(batch_id) REFERENCES sentiment_audit_batches(id),
            FOREIGN KEY(review_id) REFERENCES reviews(id)
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS hospital_user_review_history(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            action TEXT NOT NULL,
            hospital_id INTEGER,
            note TEXT,
            actor_id INTEGER,
            created_at TEXT
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS batch_crawl_jobs(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            status TEXT NOT NULL DEFAULT 'queued',
            start_index INTEGER DEFAULT 0,
            hospital_count INTEGER DEFAULT 0,
            max_reviews INTEGER DEFAULT 30,
            rest_every INTEGER DEFAULT 5,
            rest_seconds INTEGER DEFAULT 20,
            total INTEGER DEFAULT 0,
            processed INTEGER DEFAULT 0,
            success INTEGER DEFAULT 0,
            skipped INTEGER DEFAULT 0,
            failed INTEGER DEFAULT 0,
            new_reviews INTEGER DEFAULT 0,
            refreshed_reviews INTEGER DEFAULT 0,
            risk_count INTEGER DEFAULT 0,
            top_issue TEXT,
            retry_of_job_id INTEGER,
            requested_hospitals TEXT,
            message TEXT,
            created_at TEXT,
            started_at TEXT,
            finished_at TEXT
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS batch_crawl_job_items(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            job_id INTEGER NOT NULL,
            hospital_name TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'pending',
            new_reviews INTEGER DEFAULT 0,
            refreshed_reviews INTEGER DEFAULT 0,
            positive_reviews INTEGER DEFAULT 0,
            negative_reviews INTEGER DEFAULT 0,
            total_reviews INTEGER DEFAULT 0,
            top_issue TEXT,
            failure_category TEXT,
            error_message TEXT,
            review_samples TEXT,
            started_at TEXT,
            finished_at TEXT,
            FOREIGN KEY(job_id) REFERENCES batch_crawl_jobs(id)
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS batch_crawl_schedules(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            enabled INTEGER DEFAULT 1,
            frequency TEXT DEFAULT 'daily',
            run_time TEXT DEFAULT '02:00',
            hospital_count INTEGER DEFAULT 10,
            max_reviews INTEGER DEFAULT 30,
            rest_every INTEGER DEFAULT 5,
            rest_seconds INTEGER DEFAULT 20,
            next_start_index INTEGER DEFAULT 0,
            last_run_at TEXT,
            next_run_at TEXT,
            created_at TEXT,
            updated_at TEXT
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS hospital_awards(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            hospital_name TEXT NOT NULL,
            department TEXT NOT NULL,
            award_name TEXT NOT NULL,
            UNIQUE(hospital_name, department, award_name)
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS hospital_award_applications(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            hospital_id INTEGER,
            hospital_name TEXT NOT NULL,
            user_id INTEGER,
            department TEXT NOT NULL,
            award_name TEXT NOT NULL,
            status TEXT DEFAULT 'pending',
            admin_note TEXT,
            proof_document TEXT,
            created_at TEXT NOT NULL,
            reviewed_at TEXT,
            reviewed_by INTEGER,
            FOREIGN KEY(hospital_id) REFERENCES hospitals(id),
            FOREIGN KEY(user_id) REFERENCES users(id)
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS hospital_award_application_history(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            application_id INTEGER NOT NULL,
            action TEXT NOT NULL,
            note TEXT,
            proof_document TEXT,
            actor_id INTEGER,
            created_at TEXT NOT NULL,
            FOREIGN KEY(application_id) REFERENCES hospital_award_applications(id),
            FOREIGN KEY(actor_id) REFERENCES users(id)
        )
        """,
        "CREATE TABLE IF NOT EXISTS symptom_logs(id INTEGER PRIMARY KEY AUTOINCREMENT, symptom_text TEXT NOT NULL, created_at TEXT)",
        """
        CREATE TABLE IF NOT EXISTS announcements(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            content TEXT NOT NULL,
            is_active INTEGER DEFAULT 0,
            created_at TEXT
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS ai_usage_logs(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            provider TEXT NOT NULL,
            model TEXT NOT NULL,
            feature TEXT NOT NULL,
            status TEXT NOT NULL,
            error_message TEXT,
            created_at TEXT NOT NULL
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS app_settings(
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS backup_history(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            file_name TEXT NOT NULL,
            file_size_mb REAL NOT NULL,
            file_size_bytes INTEGER NOT NULL,
            created_at TEXT NOT NULL,
            created_by INTEGER,
            actor_username TEXT,
            FOREIGN KEY(created_by) REFERENCES users(id)
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS hospital_notifications(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            hospital_id INTEGER,
            user_id INTEGER,
            title TEXT NOT NULL,
            content TEXT NOT NULL,
            status TEXT DEFAULT 'unread',
            category TEXT DEFAULT 'general',
            link_url TEXT,
            created_at TEXT NOT NULL,
            created_by INTEGER,
            FOREIGN KEY(hospital_id) REFERENCES hospitals(id),
            FOREIGN KEY(user_id) REFERENCES users(id)
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS user_hospital_favorites(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            hospital_id INTEGER NOT NULL,
            note TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            UNIQUE(user_id, hospital_id),
            FOREIGN KEY(user_id) REFERENCES users(id),
            FOREIGN KEY(hospital_id) REFERENCES hospitals(id)
        )
        """,
    ]
    for statement in statements:
        connection.execute(statement)


def _add_legacy_columns(connection):
    additions = {
        "hospitals": {
            "latitude": "REAL",
            "longitude": "REAL",
        },
        "users": {
            "reset_token": "TEXT",
            "is_admin": "INTEGER DEFAULT 0",
            "role": "TEXT DEFAULT 'user'",
            "hospital_id": "INTEGER",
            "approval_status": "TEXT DEFAULT 'approved'",
            "official_email": "TEXT",
            "contact_name": "TEXT",
            "contact_phone": "TEXT",
            "institution_code": "TEXT",
            "requested_hospital_name": "TEXT",
            "rejection_reason": "TEXT",
            "proof_document": "TEXT",
        },
        "reviews": {"department": "TEXT DEFAULT '綜合/未提及'"},
        "batch_crawl_job_items": {"failure_category": "TEXT"},
        "hospital_award_applications": {"proof_document": "TEXT"},
        "hospital_notifications": {
            "category": "TEXT DEFAULT 'general'",
            "link_url": "TEXT",
        },
    }
    for table_name, columns in additions.items():
        for column_name, definition in columns.items():
            _add_column(connection, table_name, column_name, definition)


def _make_notification_hospital_optional(connection):
    hospital_id = _columns(connection, "hospital_notifications").get("hospital_id")
    if not hospital_id or hospital_id[3] == 0:
        return

    connection.execute("PRAGMA foreign_keys = OFF")
    connection.execute("ALTER TABLE hospital_notifications RENAME TO hospital_notifications_old")
    connection.execute(
        """
        CREATE TABLE hospital_notifications(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            hospital_id INTEGER,
            user_id INTEGER,
            title TEXT NOT NULL,
            content TEXT NOT NULL,
            status TEXT DEFAULT 'unread',
            category TEXT DEFAULT 'general',
            link_url TEXT,
            created_at TEXT NOT NULL,
            created_by INTEGER,
            FOREIGN KEY(hospital_id) REFERENCES hospitals(id),
            FOREIGN KEY(user_id) REFERENCES users(id)
        )
        """
    )
    connection.execute(
        """
        INSERT INTO hospital_notifications(
            id, hospital_id, user_id, title, content, status, category,
            link_url, created_at, created_by
        )
        SELECT id, hospital_id, user_id, title, content, status, category,
               link_url, created_at, created_by
        FROM hospital_notifications_old
        """
    )
    connection.execute("DROP TABLE hospital_notifications_old")
    connection.commit()
    connection.execute("PRAGMA foreign_keys = ON")


def _add_indexes_and_defaults(connection):
    indexes = [
        "CREATE INDEX IF NOT EXISTS idx_reviews_hospital_stored ON reviews(hospital_id, stored_at DESC)",
        "CREATE INDEX IF NOT EXISTS idx_reviews_sentiment ON reviews(analyzed_sentiment)",
        "CREATE INDEX IF NOT EXISTS idx_users_role_status ON users(role, approval_status)",
        "CREATE INDEX IF NOT EXISTS idx_notifications_user_status ON hospital_notifications(user_id, status, created_at DESC)",
        "CREATE INDEX IF NOT EXISTS idx_notifications_hospital_status ON hospital_notifications(hospital_id, status, created_at DESC)",
        "CREATE INDEX IF NOT EXISTS idx_batch_items_job_status ON batch_crawl_job_items(job_id, status)",
        "CREATE INDEX IF NOT EXISTS idx_audit_items_batch ON sentiment_audit_items(batch_id)",
    ]
    for statement in indexes:
        connection.execute(statement)

    connection.execute("UPDATE users SET is_admin = 1 WHERE username = 'admin' AND is_admin = 0")
    connection.execute("UPDATE users SET role = 'admin', approval_status = 'approved' WHERE is_admin = 1")
    count = connection.execute("SELECT COUNT(*) FROM stop_words").fetchone()[0]
    if count == 0:
        connection.executemany(
            "INSERT INTO stop_words(word) VALUES (?)",
            [(word,) for word in DEFAULT_STOP_WORDS],
        )
    connection.execute(
        """
        INSERT OR IGNORE INTO app_settings(key, value, updated_at)
        VALUES ('ai_summary_mode', 'auto', ?)
        """,
        (datetime.now().strftime("%Y-%m-%d %H:%M:%S"),),
    )


def _quarantine_rows(connection, source_table, query, reason):
    cursor = connection.execute(query)
    column_names = [column[0] for column in cursor.description]
    rows = cursor.fetchall()
    quarantined_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    for row in rows:
        payload = json.dumps(
            dict(zip(column_names, row)), ensure_ascii=False, default=str
        )
        connection.execute(
            """
            INSERT OR IGNORE INTO data_integrity_quarantine(
                source_table, source_row_id, reason, payload, quarantined_at
            ) VALUES (?, ?, ?, ?, ?)
            """,
            (source_table, row[0], reason, payload, quarantined_at),
        )
        connection.execute(
            f'DELETE FROM "{source_table}" WHERE id = ?', (row[0],)
        )
    return len(rows)


def _add_account_lifecycle_and_repair_orphans(connection):
    _add_column(connection, "users", "is_active", "INTEGER NOT NULL DEFAULT 1")
    _add_column(connection, "users", "deleted_at", "TEXT")
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS data_integrity_quarantine(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source_table TEXT NOT NULL,
            source_row_id INTEGER NOT NULL,
            reason TEXT NOT NULL,
            payload TEXT NOT NULL,
            quarantined_at TEXT NOT NULL,
            UNIQUE(source_table, source_row_id, reason)
        )
        """
    )
    _quarantine_rows(
        connection,
        "hospital_award_application_history",
        """
        SELECT history.*
        FROM hospital_award_application_history history
        LEFT JOIN hospital_award_applications application
          ON application.id = history.application_id
        WHERE application.id IS NULL
        """,
        "missing hospital_award_applications parent",
    )
    _quarantine_rows(
        connection,
        "hospital_notifications",
        """
        SELECT notification.*
        FROM hospital_notifications notification
        LEFT JOIN users user ON user.id = notification.user_id
        WHERE notification.user_id IS NOT NULL AND user.id IS NULL
        """,
        "missing users parent",
    )
    connection.execute(
        "CREATE INDEX IF NOT EXISTS idx_users_active_role ON users(is_active, role, approval_status)"
    )


def _add_hospital_operations(connection):
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS hospital_alert_rules(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            hospital_id INTEGER NOT NULL UNIQUE,
            enabled INTEGER NOT NULL DEFAULT 1,
            rating_threshold INTEGER NOT NULL DEFAULT 2,
            keywords TEXT NOT NULL DEFAULT '',
            last_scanned_review_id INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            FOREIGN KEY(hospital_id) REFERENCES hospitals(id)
        )
        """
    )
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS reputation_alerts(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            hospital_id INTEGER NOT NULL,
            review_id INTEGER NOT NULL,
            rule_id INTEGER NOT NULL,
            severity TEXT NOT NULL DEFAULT 'high',
            reason TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'open',
            created_at TEXT NOT NULL,
            resolved_at TEXT,
            UNIQUE(rule_id, review_id),
            FOREIGN KEY(hospital_id) REFERENCES hospitals(id),
            FOREIGN KEY(review_id) REFERENCES reviews(id) ON DELETE CASCADE,
            FOREIGN KEY(rule_id) REFERENCES hospital_alert_rules(id) ON DELETE CASCADE
        )
        """
    )
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS business_report_schedules(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            hospital_id INTEGER NOT NULL UNIQUE,
            enabled INTEGER NOT NULL DEFAULT 0,
            frequency TEXT NOT NULL DEFAULT 'monthly',
            report_day INTEGER NOT NULL DEFAULT 1,
            period_days INTEGER NOT NULL DEFAULT 90,
            last_run_at TEXT,
            next_run_at TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            FOREIGN KEY(hospital_id) REFERENCES hospitals(id)
        )
        """
    )
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS business_reports(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            hospital_id INTEGER NOT NULL,
            period_days INTEGER NOT NULL,
            period_start TEXT NOT NULL,
            period_end TEXT NOT NULL,
            payload TEXT NOT NULL,
            source TEXT NOT NULL DEFAULT 'manual',
            delivery_status TEXT NOT NULL DEFAULT 'ready',
            created_by INTEGER,
            schedule_id INTEGER,
            scheduled_for TEXT,
            created_at TEXT NOT NULL,
            UNIQUE(schedule_id, scheduled_for),
            FOREIGN KEY(hospital_id) REFERENCES hospitals(id),
            FOREIGN KEY(created_by) REFERENCES users(id),
            FOREIGN KEY(schedule_id) REFERENCES business_report_schedules(id)
        )
        """
    )
    connection.execute(
        "CREATE INDEX IF NOT EXISTS idx_reputation_alerts_hospital_status ON reputation_alerts(hospital_id, status, created_at DESC)"
    )
    connection.execute(
        "CREATE INDEX IF NOT EXISTS idx_business_reports_hospital_created ON business_reports(hospital_id, created_at DESC)"
    )
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    connection.execute(
        """
        INSERT OR IGNORE INTO hospital_alert_rules(
            hospital_id, enabled, rating_threshold, keywords,
            last_scanned_review_id, created_at, updated_at
        )
        SELECT DISTINCT hospital_id, 1, 2,
               '死亡,延誤,誤診,醫療疏失,態度惡劣,等太久,收費爭議',
               0, ?, ?
        FROM users
        WHERE role = 'hospital'
          AND approval_status = 'approved'
          AND COALESCE(is_active, 1) = 1
          AND hospital_id IS NOT NULL
        """,
        (now, now),
    )


def _add_commercial_account_and_privacy_controls(connection):
    user_columns = {
        "email": "TEXT",
        "email_verified_at": "TEXT",
        "terms_accepted_at": "TEXT",
        "privacy_accepted_at": "TEXT",
        "terms_version": "TEXT",
        "password_changed_at": "TEXT",
        "session_version": "INTEGER NOT NULL DEFAULT 0",
    }
    for column_name, definition in user_columns.items():
        _add_column(connection, "users", column_name, definition)

    symptom_columns = {
        "source": "TEXT",
        "expires_at": "TEXT",
        "consent_recorded": "INTEGER NOT NULL DEFAULT 0",
    }
    for column_name, definition in symptom_columns.items():
        _add_column(connection, "symptom_logs", column_name, definition)

    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS password_reset_tokens(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            token_hash TEXT NOT NULL UNIQUE,
            expires_at TEXT NOT NULL,
            used_at TEXT,
            created_at TEXT NOT NULL,
            requested_ip_hash TEXT,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        )
        """
    )
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS email_verification_tokens(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            token_hash TEXT NOT NULL UNIQUE,
            expires_at TEXT NOT NULL,
            used_at TEXT,
            created_at TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        )
        """
    )
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS account_security_events(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            event_type TEXT NOT NULL,
            ip_hash TEXT,
            user_agent TEXT,
            metadata TEXT,
            created_at TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL
        )
        """
    )
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS analysis_jobs(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            public_id TEXT NOT NULL UNIQUE,
            user_id INTEGER NOT NULL,
            hospital_name TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'queued',
            result_json TEXT,
            error_message TEXT,
            created_at TEXT NOT NULL,
            started_at TEXT,
            finished_at TEXT,
            expires_at TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        )
        """
    )

    connection.execute(
        """
        CREATE UNIQUE INDEX IF NOT EXISTS idx_users_active_email_unique
        ON users(lower(email))
        WHERE email IS NOT NULL
          AND email != ''
          AND COALESCE(is_active, 1) = 1
        """
    )
    connection.execute(
        "CREATE INDEX IF NOT EXISTS idx_password_reset_user_active ON password_reset_tokens(user_id, used_at, expires_at)"
    )
    connection.execute(
        "CREATE INDEX IF NOT EXISTS idx_email_verification_user_active ON email_verification_tokens(user_id, used_at, expires_at)"
    )
    connection.execute(
        "CREATE INDEX IF NOT EXISTS idx_security_events_user_created ON account_security_events(user_id, created_at DESC)"
    )
    connection.execute(
        "CREATE INDEX IF NOT EXISTS idx_analysis_jobs_user_created ON analysis_jobs(user_id, created_at DESC)"
    )
    connection.execute(
        "CREATE INDEX IF NOT EXISTS idx_analysis_jobs_status_created ON analysis_jobs(status, created_at)"
    )
    connection.execute(
        "CREATE INDEX IF NOT EXISTS idx_symptom_logs_expiry ON symptom_logs(expires_at)"
    )


MIGRATIONS = (
    (1, "create_tables", _create_tables),
    (2, "add_legacy_columns", _add_legacy_columns),
    (3, "make_notification_hospital_optional", _make_notification_hospital_optional),
    (4, "add_indexes_and_defaults", _add_indexes_and_defaults),
    (5, "account_lifecycle_and_orphan_repair", _add_account_lifecycle_and_repair_orphans),
    (6, "hospital_operations", _add_hospital_operations),
    (7, "commercial_account_and_privacy_controls", _add_commercial_account_and_privacy_controls),
)
LATEST_SCHEMA_VERSION = MIGRATIONS[-1][0]


def ensure_schema(database_path):
    with connect_database(database_path) as connection:
        connection.execute("PRAGMA journal_mode = WAL")
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS schema_migrations(
                version INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                applied_at TEXT NOT NULL
            )
            """
        )
        connection.commit()
        applied = {
            row[0]
            for row in connection.execute("SELECT version FROM schema_migrations").fetchall()
        }

        for version, name, migration in MIGRATIONS:
            if version in applied:
                continue
            LOGGER.info(
                "applying_database_migration",
                extra={"migration_version": version, "migration_name": name},
            )
            migration(connection)
            connection.execute(
                "INSERT INTO schema_migrations(version, name, applied_at) VALUES (?, ?, ?)",
                (version, name, datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
            )
            connection.commit()

        violations = connection.execute("PRAGMA foreign_key_check").fetchmany(10)
        if violations:
            LOGGER.warning("database_foreign_key_violations", extra={"count": len(violations)})
