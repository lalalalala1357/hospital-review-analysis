import os
import threading
import warnings


try:
    from google import genai as current_genai
    from google.genai import types as current_types

    AVAILABLE_BACKEND = "google-genai"
except ImportError:
    current_genai = None
    current_types = None
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        try:
            import google.generativeai as legacy_genai
        except ImportError:
            legacy_genai = None
    AVAILABLE_BACKEND = "legacy" if legacy_genai is not None else None
else:
    legacy_genai = None


class GeminiGateway:
    def __init__(
        self,
        api_key,
        *,
        backend=None,
        new_client_factory=None,
        legacy_module=None,
    ):
        if not api_key:
            raise ValueError("Gemini API Key 未設定")
        self.api_key = api_key
        self.backend = backend or AVAILABLE_BACKEND
        self.default_timeout = max(int(os.getenv("GEMINI_TIMEOUT_SECONDS", "120")), 1)
        self._clients = {}
        self._client_lock = threading.Lock()
        self._new_client_factory = new_client_factory
        self._legacy = legacy_module or legacy_genai

        if self.backend == "legacy":
            if self._legacy is None:
                raise RuntimeError("找不到可用的 Gemini SDK")
            self._legacy.configure(api_key=api_key)
        elif self.backend != "google-genai":
            raise RuntimeError("請安裝 google-genai 套件")

    def _new_client(self, timeout_seconds=None):
        timeout = int(timeout_seconds or self.default_timeout)
        with self._client_lock:
            if timeout not in self._clients:
                if self._new_client_factory:
                    client = self._new_client_factory(timeout)
                else:
                    client = current_genai.Client(
                        api_key=self.api_key,
                        http_options=current_types.HttpOptions(timeout=timeout * 1000),
                    )
                self._clients[timeout] = client
        return self._clients[timeout]

    def generate_content(self, model_name, contents, timeout_seconds=None):
        if self.backend == "google-genai":
            return self._new_client(timeout_seconds).models.generate_content(
                model=model_name,
                contents=contents,
            )

        model = self._legacy.GenerativeModel(model_name)
        request_options = {"timeout": timeout_seconds} if timeout_seconds else None
        return model.generate_content(contents, request_options=request_options)

    def generate_from_file(self, model_name, file_path, prompt, timeout_seconds=None):
        if self.backend == "google-genai":
            client = self._new_client(timeout_seconds)
            uploaded_file = client.files.upload(file=file_path)
            try:
                return client.models.generate_content(
                    model=model_name,
                    contents=[uploaded_file, prompt],
                )
            finally:
                client.files.delete(name=uploaded_file.name)

        uploaded_file = self._legacy.upload_file(path=file_path)
        try:
            model = self._legacy.GenerativeModel(model_name)
            request_options = {"timeout": timeout_seconds} if timeout_seconds else None
            return model.generate_content(
                [uploaded_file, prompt], request_options=request_options
            )
        finally:
            delete_file = getattr(self._legacy, "delete_file", None)
            if delete_file and getattr(uploaded_file, "name", None):
                delete_file(uploaded_file.name)

    def list_model_names(self):
        if self.backend == "google-genai":
            models = self._new_client().models.list()
            names = []
            for model in models:
                actions = getattr(model, "supported_actions", None) or []
                if not actions or any("generatecontent" in str(action).lower() for action in actions):
                    names.append(model.name)
            return names

        names = []
        for model in self._legacy.list_models():
            methods = getattr(model, "supported_generation_methods", [])
            if "generateContent" in methods:
                names.append(model.name)
        return names
