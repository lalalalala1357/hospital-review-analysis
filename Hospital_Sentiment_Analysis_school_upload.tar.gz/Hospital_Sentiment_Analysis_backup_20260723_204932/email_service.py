import logging
import smtplib
import ssl
from email.message import EmailMessage


LOGGER = logging.getLogger(__name__)


def is_email_delivery_configured(app):
    return bool(app.config.get("SMTP_HOST") and app.config.get("MAIL_FROM"))


def send_transactional_email(app, *, recipient, subject, text_body, html_body=None):
    if not is_email_delivery_configured(app):
        LOGGER.warning(
            "transactional_email_not_configured",
            extra={"recipient_domain": _email_domain(recipient)},
        )
        return False

    message = EmailMessage()
    message["From"] = app.config["MAIL_FROM"]
    message["To"] = recipient
    message["Subject"] = subject
    message.set_content(text_body)
    if html_body:
        message.add_alternative(html_body, subtype="html")

    host = app.config["SMTP_HOST"]
    port = app.config["SMTP_PORT"]
    username = app.config.get("SMTP_USERNAME")
    password = app.config.get("SMTP_PASSWORD")
    use_ssl = bool(app.config.get("SMTP_USE_SSL"))
    use_tls = bool(app.config.get("SMTP_USE_TLS"))
    ssl_context = ssl.create_default_context()

    try:
        smtp_class = smtplib.SMTP_SSL if use_ssl else smtplib.SMTP
        smtp_kwargs = {"host": host, "port": port, "timeout": 10}
        if use_ssl:
            smtp_kwargs["context"] = ssl_context
        with smtp_class(**smtp_kwargs) as client:
            if use_tls and not use_ssl:
                client.starttls(context=ssl_context)
            if username:
                client.login(username, password)
            client.send_message(message)
    except (OSError, smtplib.SMTPException):
        LOGGER.exception(
            "transactional_email_failed",
            extra={"recipient_domain": _email_domain(recipient)},
        )
        return False

    LOGGER.info(
        "transactional_email_sent",
        extra={"recipient_domain": _email_domain(recipient)},
    )
    return True


def _email_domain(address):
    value = str(address or "")
    return value.rsplit("@", 1)[-1].lower() if "@" in value else "invalid"
