"""Administrative content, filtering, symptom, and backup controls."""

from datetime import datetime
import os
import sqlite3

from flask import after_this_request, flash, jsonify, redirect, request, send_file, url_for
from flask_login import current_user, login_required

from access_control import admin_required
from database import connect_database, create_consistent_backup, remove_file_quietly


def register_admin_content_routes(app, *, database_path, log_backup_history):
    @app.route('/admin/log_view', methods=['POST'])
    @login_required
    @admin_required
    def admin_log_view():
        if not current_user.is_admin:
            return jsonify({'error': '權限不足'}), 403

        data = request.get_json(silent=True) or {}
        view = str(data.get('view') or '').strip()
        label = str(data.get('label') or '').strip()
        allowed_views = {
            'dashboard': '工作台總覽',
            'reviews': '評論監控',
            'crawler': '爬蟲管理',
            'health': '健康警示',
            'data': '醫院資料庫',
            'users': '會員權限',
        }
        if view not in allowed_views:
            return jsonify({'error': '未知頁面'}), 400

        print(f"Admin 目前頁面：{label or allowed_views[view]} (#{view})", flush=True)
        return jsonify({'ok': True})

    @app.route('/admin/backup', methods=['POST'])
    @login_required
    @admin_required
    def backup_db():
        if not current_user.is_admin:
            flash('權限不足，無法執行備份操作', 'analyze_error')
            return redirect(url_for('index'))

        timestamp = datetime.now().strftime('%Y%m%d_%H%M')
        file_name = f'backup_{timestamp}.db'
        backup_path = create_consistent_backup(database_path)
        file_size_bytes = os.path.getsize(backup_path)
        log_backup_history(file_name, file_size_bytes)

        @after_this_request
        def cleanup_backup(response):
            remove_file_quietly(backup_path)
            return response

        response = send_file(backup_path, as_attachment=True, download_name=file_name)
        response.headers['Cache-Control'] = 'no-store, private'
        return response

    @app.route('/admin/add_stop_word', methods=['POST'])
    @login_required
    @admin_required
    def add_stop_word():
        if not current_user.is_admin:
            return redirect(url_for('index'))
        word = request.form.get('word', '').strip()
        if word:
            try:
                with connect_database(database_path) as conn:
                    cursor = conn.cursor()
                    cursor.execute('INSERT INTO stop_words (word) VALUES (?)', (word,))
                    conn.commit()
                flash(f'已新增過濾詞：{word}', 'analyze_success')
            except sqlite3.IntegrityError:
                flash(f'過濾詞「{word}」已經存在囉！', 'analyze_error')
        return redirect(url_for('admin_page'))

    @app.route('/admin/delete_stop_word/<int:word_id>', methods=['POST'])
    @login_required
    @admin_required
    def delete_stop_word(word_id):
        if not current_user.is_admin:
            return redirect(url_for('index'))
        with connect_database(database_path) as conn:
            cursor = conn.cursor()
            cursor.execute('DELETE FROM stop_words WHERE id = ?', (word_id,))
            conn.commit()
        flash('過濾詞已刪除', 'analyze_success')
        return redirect(url_for('admin_page'))

    @app.route('/admin/delete_symptom', methods=['POST'])
    @login_required
    @admin_required
    def delete_symptom():
        if not current_user.is_admin:
            return redirect(url_for('index'))

        symptom_text = request.form.get('symptom_text', '').strip()
        if symptom_text:
            try:
                with connect_database(database_path) as conn:
                    cursor = conn.cursor()
                    cursor.execute('DELETE FROM symptom_logs WHERE symptom_text = ?', (symptom_text,))
                    conn.commit()
                flash(f'已成功刪除所有關於「{symptom_text}」的紀錄！', 'analyze_success')
            except Exception as error:
                app.logger.warning('delete_symptom_failed', exc_info=error)
                flash('刪除失敗，請稍後再試。', 'analyze_error')

        return redirect(url_for('admin_page') + '#health')

    @app.route('/admin/add_announcement', methods=['POST'])
    @login_required
    @admin_required
    def add_announcement():
        if not current_user.is_admin:
            return redirect(url_for('index'))
        content = request.form.get('content', '').strip()
        if content:
            with connect_database(database_path) as conn:
                cursor = conn.cursor()
                cursor.execute(
                    'INSERT INTO announcements (content, is_active, created_at) VALUES (?, 0, ?)',
                    (content, datetime.now().strftime('%Y-%m-%d %H:%M:%S')),
                )
                announcement_id = cursor.lastrowid
                conn.commit()
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return jsonify({
                    'status': 'ok',
                    'message': '公告已建立',
                    'id': announcement_id,
                    'content': content,
                })
            flash('公告已建立（預設為關閉狀態，請手動開啟）', 'analyze_success')
        return redirect(url_for('admin_page') + '#health')

    @app.route('/admin/toggle_announcement/<int:ann_id>', methods=['POST'])
    @login_required
    @admin_required
    def toggle_announcement(ann_id):
        if not current_user.is_admin:
            return redirect(url_for('index'))
        with connect_database(database_path) as conn:
            cursor = conn.cursor()
            cursor.execute('UPDATE announcements SET is_active = 0')
            cursor.execute('UPDATE announcements SET is_active = 1 WHERE id = ?', (ann_id,))
            conn.commit()
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({'status': 'ok', 'message': '公告狀態已更新'})
        flash('公告狀態已更新！', 'analyze_success')
        return redirect(url_for('admin_page') + '#health')

    @app.route('/admin/delete_announcement/<int:ann_id>', methods=['POST'])
    @login_required
    @admin_required
    def delete_announcement(ann_id):
        if not current_user.is_admin:
            return redirect(url_for('index'))
        with connect_database(database_path) as conn:
            cursor = conn.cursor()
            cursor.execute('DELETE FROM announcements WHERE id = ?', (ann_id,))
            conn.commit()
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({'status': 'ok', 'message': '公告已刪除'})
        flash('公告已刪除', 'analyze_success')
        return redirect(url_for('admin_page') + '#health')
