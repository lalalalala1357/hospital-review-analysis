from functools import wraps

from flask import Blueprint, abort, flash, redirect, render_template, request, url_for
from flask_login import current_user, login_required

from business_intelligence import (
    ALLOWED_PERIODS,
    build_operations_dashboard,
    create_business_report,
    get_business_report,
    get_operations_state,
    normalize_period,
    save_report_schedule,
)


def hospital_account_required(view):
    @login_required
    @wraps(view)
    def wrapped_view(*args, **kwargs):
        if (
            getattr(current_user, "role", None) != "hospital"
            or getattr(current_user, "approval_status", None) != "approved"
            or not getattr(current_user, "hospital_id", None)
        ):
            flash("只有已核准的院方帳號可以使用營運中心。", "analyze_error")
            return redirect(url_for("index"))
        return view(*args, **kwargs)

    return wrapped_view


def register_hospital_operations(app, database_path):
    blueprint = Blueprint("hospital_operations", __name__)

    @blueprint.route("/hospital/operations")
    @hospital_account_required
    def dashboard():
        period_days = normalize_period(request.args.get("period"))
        hospital_id = current_user.hospital_id
        dashboard_data = build_operations_dashboard(
            database_path, hospital_id, period_days
        )
        if not dashboard_data:
            abort(404)
        operations_state = get_operations_state(database_path, hospital_id)
        return render_template(
            "hospital_operations.html",
            dashboard=dashboard_data,
            operations=operations_state,
            period_options=ALLOWED_PERIODS,
        )

    @blueprint.route("/hospital/operations/reports", methods=["POST"])
    @hospital_account_required
    def create_report():
        report_id = create_business_report(
            database_path,
            current_user.hospital_id,
            normalize_period(request.form.get("period")),
            created_by=current_user.id,
        )
        flash("營運報告已產生。", "analyze_success")
        return redirect(
            url_for("hospital_operations.report", report_id=report_id)
        )

    @blueprint.route("/hospital/operations/reports/<int:report_id>")
    @hospital_account_required
    def report(report_id):
        report_data = get_business_report(
            database_path, report_id, current_user.hospital_id
        )
        if not report_data:
            abort(404)
        return render_template("hospital_business_report.html", report=report_data)

    @blueprint.route("/hospital/operations/report-schedule", methods=["POST"])
    @hospital_account_required
    def report_schedule():
        try:
            save_report_schedule(
                database_path,
                current_user.hospital_id,
                enabled=request.form.get("enabled") == "1",
                frequency=request.form.get("frequency", "monthly"),
                report_day=request.form.get("report_day", 1),
                period_days=request.form.get("period", 90),
            )
        except (TypeError, ValueError):
            flash("定期報告設定格式不正確。", "analyze_error")
        else:
            flash("定期報告設定已儲存。", "analyze_success")
        return redirect(url_for("hospital_operations.dashboard") + "#reports")

    app.register_blueprint(blueprint)
