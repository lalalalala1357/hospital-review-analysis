import os
import sqlite3
from datetime import datetime, timedelta, timezone

from flask import jsonify

from database import connect_database, database_health


def _writable_directory(path):
    return bool(path and os.path.isdir(path) and os.access(path, os.W_OK))


def _database_runtime_checks(database_path, expected_schema_version, stale_minutes):
    schema_ok = expected_schema_version is None
    stale_jobs = 0
    try:
        with connect_database(database_path, read_only=True) as connection:
            if expected_schema_version is not None:
                row = connection.execute(
                    "SELECT COALESCE(MAX(version), 0) FROM schema_migrations"
                ).fetchone()
                schema_ok = bool(row and row[0] >= expected_schema_version)

            table_exists = connection.execute(
                "SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'analysis_jobs'"
            ).fetchone()
            if table_exists:
                stale_before = datetime.now() - timedelta(minutes=stale_minutes)
                row = connection.execute(
                    """
                    SELECT COUNT(*)
                    FROM analysis_jobs
                    WHERE status = 'running' AND started_at < ?
                    """,
                    (stale_before.strftime("%Y-%m-%d %H:%M:%S"),),
                ).fetchone()
                stale_jobs = int(row[0] if row else 0)
    except (OSError, sqlite3.Error):
        schema_ok = False
        stale_jobs = -1
    return schema_ok, stale_jobs


def register_health_routes(
    app,
    database_path,
    required_paths=None,
    required_writable_paths=None,
    expected_schema_version=None,
):
    required_paths = tuple(required_paths or ())
    required_writable_paths = tuple(required_writable_paths or ())

    @app.get("/health/live")
    def health_live():
        return jsonify(
            {
                "status": "ok",
                "time": datetime.now(timezone.utc).isoformat(),
            }
        )

    @app.get("/health/ready")
    def health_ready():
        database_ok, _ = database_health(database_path)
        files_ok = all(os.path.exists(path) for path in required_paths)
        writable_paths_ok = all(
            _writable_directory(path) for path in required_writable_paths
        )
        schema_ok, stale_jobs = _database_runtime_checks(
            database_path,
            expected_schema_version,
            app.config.get("ANALYSIS_JOB_STALE_MINUTES", 30),
        )
        email_config_ok = (
            not app.config.get("EMAIL_VERIFICATION_REQUIRED", False)
            or all(
                app.config.get(key)
                for key in ("SMTP_HOST", "MAIL_FROM", "PUBLIC_BASE_URL")
            )
        )
        background_jobs_ok = stale_jobs == 0
        ready = all(
            (
                database_ok,
                files_ok,
                writable_paths_ok,
                schema_ok,
                email_config_ok,
                background_jobs_ok,
            )
        )
        return (
            jsonify(
                {
                    "status": "ready" if ready else "not_ready",
                    "checks": {
                        "database": database_ok,
                        "database_schema": schema_ok,
                        "required_files": files_ok,
                        "writable_storage": writable_paths_ok,
                        "email_delivery": email_config_ok,
                        "background_jobs": background_jobs_ok,
                    },
                    "metrics": {"stale_analysis_jobs": max(stale_jobs, 0)},
                }
            ),
            200 if ready else 503,
        )
