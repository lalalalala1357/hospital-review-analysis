"""Fast keyword extraction for synchronous hospital profile pages."""

import jieba.posseg as pseg

from database import connect_database


SINGLE_CHARACTER_KEYWORDS = {'兇', '差', '爛', '慢', '久', '貴'}
DOMAIN_KEYWORDS = {
    '等待', '排隊', '掛號', '停車', '動線', '態度', '效率',
    '櫃台', '護理師', '醫生', '醫師', '時間', '流程',
}


def extract_profile_keywords(database_path, reviews_list, top_n=10, tokenizer=None):
    """Extract profile keywords without Jieba HMM's request-time cost."""
    dynamic_stop_words = set()
    try:
        with connect_database(database_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS stop_words(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    word TEXT UNIQUE NOT NULL
                )
            """)
            cursor.execute('SELECT word FROM stop_words')
            dynamic_stop_words = {
                str(row[0]).strip()
                for row in cursor.fetchall()
                if str(row[0]).strip()
            }
    except Exception:
        dynamic_stop_words = set()

    all_text = '\n'.join(str(review.get('text') or '') for review in reviews_list)
    cut = tokenizer or pseg.cut
    words = cut(all_text, HMM=False)
    candidates = set()

    for word, flag in words:
        clean_word = str(word).strip()
        if not clean_word or clean_word in dynamic_stop_words:
            continue
        if len(clean_word) < 2 and clean_word not in SINGLE_CHARACTER_KEYWORDS:
            continue
        if str(flag).startswith('a') or clean_word in DOMAIN_KEYWORDS:
            candidates.add(clean_word)

    statistics = []
    for keyword in candidates:
        count = sum(1 for review in reviews_list if keyword in str(review.get('text') or ''))
        if count:
            statistics.append((keyword, count))

    statistics.sort(key=lambda item: (-item[1], item[0]))
    top_results = statistics[:top_n]
    return {
        'labels': [item[0] for item in top_results],
        'data': [item[1] for item in top_results],
    }
