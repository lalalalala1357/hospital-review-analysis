import os
import re
import shutil
import uuid


EXTENSION_TO_KIND = {
    "pdf": "pdf",
    "png": "png",
    "jpg": "jpeg",
    "jpeg": "jpeg",
}
KIND_TO_MIMETYPE = {
    "pdf": "application/pdf",
    "png": "image/png",
    "jpeg": "image/jpeg",
}
STORED_FILENAME_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,199}$")


def detect_file_kind(header):
    if header.startswith(b"%PDF-"):
        return "pdf"
    if header.startswith(b"\x89PNG\r\n\x1a\n"):
        return "png"
    if header.startswith(b"\xff\xd8\xff"):
        return "jpeg"
    return None


def save_proof_document(file_storage, upload_folder):
    if not file_storage or not file_storage.filename:
        return None, None

    original_name = str(file_storage.filename).strip()
    if "." not in original_name:
        return None, "請上傳 PDF、PNG、JPG 或 JPEG 格式的證明文件。"
    extension = original_name.rsplit(".", 1)[1].lower()
    expected_kind = EXTENSION_TO_KIND.get(extension)
    if not expected_kind:
        return None, "證明文件格式不支援，請上傳 PDF、PNG、JPG 或 JPEG。"

    header = file_storage.stream.read(16)
    file_storage.stream.seek(0)
    actual_kind = detect_file_kind(header)
    if actual_kind != expected_kind:
        return None, "檔案內容與副檔名不符，請重新匯出後再上傳。"

    os.makedirs(upload_folder, mode=0o700, exist_ok=True)
    stored_extension = "jpg" if actual_kind == "jpeg" else actual_kind
    filename = f"{uuid.uuid4().hex}.{stored_extension}"
    output_path = os.path.join(upload_folder, filename)
    file_storage.save(output_path)
    os.chmod(output_path, 0o600)
    return filename, None


def is_safe_stored_filename(filename):
    value = str(filename or "")
    return bool(STORED_FILENAME_PATTERN.fullmatch(value)) and ".." not in value


def proof_mimetype(filename):
    extension = str(filename or "").rsplit(".", 1)[-1].lower()
    return KIND_TO_MIMETYPE.get(EXTENSION_TO_KIND.get(extension))


def migrate_legacy_proofs(legacy_folder, private_folder):
    if not os.path.isdir(legacy_folder):
        return 0
    os.makedirs(private_folder, mode=0o700, exist_ok=True)
    copied = 0
    for filename in os.listdir(legacy_folder):
        if not is_safe_stored_filename(filename):
            continue
        source = os.path.join(legacy_folder, filename)
        target = os.path.join(private_folder, filename)
        if not os.path.isfile(source) or os.path.exists(target):
            continue
        shutil.copy2(source, target)
        os.chmod(target, 0o600)
        copied += 1
    return copied
