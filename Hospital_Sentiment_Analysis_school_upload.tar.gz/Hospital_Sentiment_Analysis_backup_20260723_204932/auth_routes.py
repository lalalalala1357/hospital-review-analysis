import hashlib
import hmac
import json
import logging
import os
import re
import secrets
import sqlite3
from datetime import datetime, timedelta

from flask import (
    flash,
    redirect,
    render_template,
    request,
    send_from_directory,
    session,
    url_for,
)
from flask_login import UserMixin, current_user, login_required, login_user, logout_user

from database import connect_database, remove_file_quietly
from email_service import is_email_delivery_configured, send_transactional_email
from file_uploads import (
    is_safe_stored_filename,
    proof_mimetype,
    save_proof_document,
)
from security_utils import (
    WEAK_BOOTSTRAP_PASSWORDS,
    require_strong_env_value,
    validate_password,
    validate_username,
)


LOGGER = logging.getLogger(__name__)
CURRENT_TERMS_VERSION = "2026-07-27"
EMAIL_PATTERN = re.compile(r"[^\s@]+@[^\s@]+\.[^\s@]+")
TOKEN_HASH_PATTERN = re.compile(r"^[a-f0-9]{64}$")


def _now():
    return datetime.now()


def _timestamp(value=None):
    return (value or _now()).strftime("%Y-%m-%d %H:%M:%S")


def _row_value(row, key, default=None):
    if row is None:
        return default
    try:
        return row[key]
    except (KeyError, IndexError):
        return default


def _normalize_email(value):
    return str(value or "").strip().lower()


def _validate_email(value):
    email = _normalize_email(value)
    if not email or len(email) > 254 or not EMAIL_PATTERN.fullmatch(email):
        return "請填寫有效的 Email。"
    return None


def _hash_token(token):
    return hashlib.sha256(str(token).encode("utf-8")).hexdigest()


def _client_ip_hash(app):
    source = (request.headers.get("X-Forwarded-For", "").split(",")[0].strip()
              if app.config.get("TRUST_PROXY") else "")
    source = source or request.remote_addr or "unknown"
    return hmac.new(
        str(app.secret_key).encode("utf-8"),
        source.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()


def _record_security_event(app, database_path, event_type, user_id=None, metadata=None):
    try:
        with connect_database(database_path) as connection:
            connection.execute(
                """
                INSERT INTO account_security_events(
                    user_id, event_type, ip_hash, user_agent, metadata, created_at
                ) VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    user_id,
                    event_type,
                    _client_ip_hash(app),
                    str(request.user_agent.string or "")[:250],
                    json.dumps(metadata or {}, ensure_ascii=False),
                    _timestamp(),
                ),
            )
            connection.commit()
    except Exception:
        LOGGER.exception("account_security_event_write_failed")


def _create_one_time_token(connection, table_name, user_id, lifetime):
    if table_name not in {"password_reset_tokens", "email_verification_tokens"}:
        raise ValueError("Unsupported token table")
    raw_token = secrets.token_urlsafe(32)
    now = _now()
    connection.execute(
        f"UPDATE {table_name} SET used_at = ? WHERE user_id = ? AND used_at IS NULL",
        (_timestamp(now), user_id),
    )
    connection.execute(
        f"""
        INSERT INTO {table_name}(user_id, token_hash, expires_at, created_at)
        VALUES (?, ?, ?, ?)
        """,
        (
            user_id,
            _hash_token(raw_token),
            _timestamp(now + lifetime),
            _timestamp(now),
        ),
    )
    return raw_token


def _valid_token_row(connection, table_name, raw_token):
    if table_name not in {"password_reset_tokens", "email_verification_tokens"}:
        return None
    token_hash = _hash_token(raw_token)
    if not TOKEN_HASH_PATTERN.fullmatch(token_hash):
        return None
    return connection.execute(
        f"""
        SELECT token.*, user.username, user.email, user.is_active
        FROM {table_name} token
        JOIN users user ON user.id = token.user_id
        WHERE token.token_hash = ?
          AND token.used_at IS NULL
          AND token.expires_at > ?
          AND COALESCE(user.is_active, 1) = 1
        """,
        (token_hash, _timestamp()),
    ).fetchone()


def _public_link(app, endpoint, **values):
    path = url_for(endpoint, **values)
    base_url = app.config.get("PUBLIC_BASE_URL") or request.url_root.rstrip("/")
    return f"{base_url.rstrip('/')}{path}"


def _send_verification_email(app, recipient, token):
    link = _public_link(app, "verify_email", token=token)
    return send_transactional_email(
        app,
        recipient=recipient,
        subject="驗證你的醫療口碑監測平台 Email",
        text_body=f"請開啟以下連結完成 Email 驗證（24 小時內有效）：\n{link}",
        html_body=(
            "<p>請完成醫療口碑監測平台 Email 驗證。</p>"
            f'<p><a href="{link}">驗證 Email</a></p>'
            "<p>此連結將於 24 小時後失效。</p>"
        ),
    )


def _send_password_reset_email(app, recipient, token):
    link = _public_link(app, "reset_password", token=token)
    return send_transactional_email(
        app,
        recipient=recipient,
        subject="重設醫療口碑監測平台密碼",
        text_body=f"請開啟以下連結重設密碼（1 小時內有效）：\n{link}",
        html_body=(
            "<p>我們收到你的密碼重設要求。</p>"
            f'<p><a href="{link}">重設密碼</a></p>'
            "<p>若不是你提出的要求，請忽略這封信。</p>"
        ),
    )


class User(UserMixin):
    def __init__(
        self,
        id_,
        username,
        password,
        is_admin=0,
        role="user",
        hospital_id=None,
        approval_status="approved",
        rejection_reason=None,
        email=None,
        email_verified_at=None,
        terms_accepted_at=None,
        privacy_accepted_at=None,
        terms_version=None,
        session_version=0,
    ):
        self.id = id_
        self.username = username
        self.password = password
        self.is_admin = is_admin
        self.role = role or ("admin" if is_admin else "user")
        self.hospital_id = hospital_id
        self.approval_status = approval_status or "approved"
        self.rejection_reason = rejection_reason
        self.email = email
        self.email_verified_at = email_verified_at
        self.terms_accepted_at = terms_accepted_at
        self.privacy_accepted_at = privacy_accepted_at
        self.terms_version = terms_version
        self.session_version = int(session_version or 0)

    @property
    def is_hospital_user(self):
        return (
            self.role == "hospital"
            and self.approval_status == "approved"
            and self.hospital_id is not None
        )

    @property
    def has_policy_consent(self):
        return bool(self.terms_accepted_at and self.privacy_accepted_at)


def _user_from_row(row):
    return User(
        id_=_row_value(row, "id"),
        username=_row_value(row, "username"),
        password=_row_value(row, "password"),
        is_admin=_row_value(row, "is_admin", 0),
        role=_row_value(row, "role", "user"),
        hospital_id=_row_value(row, "hospital_id"),
        approval_status=_row_value(row, "approval_status", "approved"),
        rejection_reason=_row_value(row, "rejection_reason"),
        email=_row_value(row, "email"),
        email_verified_at=_row_value(row, "email_verified_at"),
        terms_accepted_at=_row_value(row, "terms_accepted_at"),
        privacy_accepted_at=_row_value(row, "privacy_accepted_at"),
        terms_version=_row_value(row, "terms_version"),
        session_version=_row_value(row, "session_version", 0),
    )


def _initialize_admin(app, database_path, bcrypt):
    admin_username = os.getenv("DEFAULT_ADMIN_USERNAME", "admin").strip() or "admin"
    with connect_database(database_path, rows=True) as connection:
        row = connection.execute(
            "SELECT * FROM users WHERE username = ? AND COALESCE(is_active, 1) = 1",
            (admin_username,),
        ).fetchone()
        if row:
            if app.config.get("IS_PRODUCTION") and any(
                bcrypt.check_password_hash(row["password"], weak_password)
                for weak_password in WEAK_BOOTSTRAP_PASSWORDS
            ):
                raise RuntimeError("正式環境管理員仍使用弱密碼，請先完成密碼更換。")
            return

        bootstrap_password = require_strong_env_value(
            "DEFAULT_ADMIN_PASSWORD", WEAK_BOOTSTRAP_PASSWORDS, min_length=12
        )
        hashed_password = bcrypt.generate_password_hash(bootstrap_password).decode("utf-8")
        connection.execute(
            """
            INSERT INTO users(username, password, is_admin, role, approval_status)
            VALUES (?, ?, 1, 'admin', 'approved')
            """,
            (admin_username, hashed_password),
        )
        connection.commit()
        LOGGER.info("bootstrap_admin_created", extra={"admin_username": admin_username})


def register_auth_routes(
    app,
    *,
    bcrypt,
    login_manager,
    limiter,
    database_path,
    hospital_names,
    upload_folder,
):
    def role_home(user):
        if user.role == "hospital":
            if user.approval_status != "approved" or not user.hospital_id:
                return url_for("hospital_application_status")
            return url_for("hospital_dashboard")
        if user.is_admin:
            return url_for("admin_page")
        return url_for("index")

    def complete_login(user, next_path=None):
        session.clear()
        login_user(user, remember=False, fresh=True)
        session.permanent = True
        session["username"] = user.username
        session["session_version"] = user.session_version
        if not user.has_policy_consent:
            return redirect(url_for("account_consent"))
        if (
            app.config.get("EMAIL_VERIFICATION_REQUIRED")
            and (not user.email or not user.email_verified_at)
        ):
            return redirect(url_for("verification_required"))
        if next_path and next_path.startswith("/") and not next_path.startswith("//"):
            return redirect(next_path)
        return redirect(role_home(user))

    @login_manager.user_loader
    def load_user(user_id):
        with connect_database(database_path, rows=True) as connection:
            row = connection.execute(
                "SELECT * FROM users WHERE id = ? AND COALESCE(is_active, 1) = 1",
                (user_id,),
            ).fetchone()
        if not row:
            return None
        user = _user_from_row(row)
        session_version = session.get("session_version")
        if session_version is None or int(session_version) != user.session_version:
            return None
        return user

    @app.before_request
    def enforce_account_requirements():
        if not current_user.is_authenticated:
            return None
        endpoint = request.endpoint or ""
        allowed = {
            "static",
            "logout",
            "privacy_policy",
            "terms_of_service",
            "account_consent",
            "account_page",
            "update_account_email",
            "verification_required",
            "resend_verification_email",
            "verify_email",
        }
        if endpoint in allowed or endpoint.startswith("health_"):
            return None
        if not current_user.has_policy_consent:
            return redirect(url_for("account_consent"))
        if (
            app.config.get("EMAIL_VERIFICATION_REQUIRED")
            and (not current_user.email or not current_user.email_verified_at)
        ):
            return redirect(url_for("verification_required"))
        return None

    @app.route("/privacy")
    def privacy_policy():
        return render_template(
            "privacy.html",
            support_email=app.config.get("SUPPORT_EMAIL"),
            symptom_retention_days=app.config.get("SYMPTOM_RETENTION_DAYS", 90),
            policy_version=CURRENT_TERMS_VERSION,
        )

    @app.route("/terms")
    def terms_of_service():
        return render_template(
            "terms.html",
            support_email=app.config.get("SUPPORT_EMAIL"),
            policy_version=CURRENT_TERMS_VERSION,
        )

    @app.route("/proofs/<path:filename>")
    @login_required
    def download_proof_document(filename):
        if not is_safe_stored_filename(filename):
            return ("找不到檔案", 404)

        allowed = bool(current_user.is_admin)
        if not allowed:
            with connect_database(database_path) as connection:
                row = connection.execute(
                    """
                    SELECT 1
                    FROM users
                    WHERE id = ? AND proof_document = ?
                    UNION ALL
                    SELECT 1
                    FROM hospital_award_applications
                    WHERE proof_document = ?
                      AND (user_id = ? OR hospital_id = ?)
                    UNION ALL
                    SELECT 1
                    FROM hospital_award_application_history history
                    JOIN hospital_award_applications application
                      ON application.id = history.application_id
                    WHERE history.proof_document = ?
                      AND (application.user_id = ? OR application.hospital_id = ?)
                    LIMIT 1
                    """,
                    (
                        current_user.id,
                        filename,
                        filename,
                        current_user.id,
                        current_user.hospital_id,
                        filename,
                        current_user.id,
                        current_user.hospital_id,
                    ),
                ).fetchone()
                allowed = row is not None

        if not allowed or not os.path.isfile(os.path.join(upload_folder, filename)):
            return ("找不到檔案", 404)
        return send_from_directory(
            upload_folder,
            filename,
            mimetype=proof_mimetype(filename),
            as_attachment=True,
            max_age=0,
        )

    @app.route("/login", methods=["GET", "POST"])
    @limiter.limit("5 per minute")
    def login():
        if request.method == "GET" and current_user.is_authenticated:
            return redirect(role_home(current_user))

        if request.method == "POST":
            username = request.form.get("username", "").strip()
            password = request.form.get("password", "")
            user_captcha = request.form.get("captcha", "").upper()
            real_captcha = session.pop("captcha_code", None)

            if not real_captcha or user_captcha != real_captcha:
                _record_security_event(
                    app, database_path, "login_failed", metadata={"reason": "captcha"}
                )
                flash("驗證碼錯誤", "login_error")
                return redirect(url_for("login"))

            with connect_database(database_path, rows=True) as connection:
                row = connection.execute(
                    """
                    SELECT * FROM users
                    WHERE username = ? AND COALESCE(is_active, 1) = 1
                    """,
                    (username,),
                ).fetchone()

            if row and bcrypt.check_password_hash(row["password"], password):
                user = _user_from_row(row)
                _record_security_event(app, database_path, "login_succeeded", user.id)
                return complete_login(user, request.form.get("next"))

            _record_security_event(
                app,
                database_path,
                "login_failed",
                _row_value(row, "id"),
                {"reason": "credentials"},
            )
            flash("帳號或密碼錯誤", "login_error")
        return render_template("login.html", next_path=request.args.get("next", ""))

    @app.route("/register", methods=["GET", "POST"])
    @limiter.limit("5 per hour")
    def register():
        if request.method == "POST":
            username = request.form.get("username", "").strip()
            email = _normalize_email(request.form.get("email"))
            password = request.form.get("password", "")
            password_confirmation = request.form.get("password_confirmation", "")
            account_type = request.form.get("account_type", "user")
            account_type = account_type if account_type in {"user", "hospital"} else "user"

            credential_error = (
                validate_username(username)
                or _validate_email(email)
                or validate_password(password, username)
            )
            if credential_error:
                flash(credential_error, "register_error")
                return redirect(url_for("register"))
            if password != password_confirmation:
                flash("兩次輸入的密碼不一致。", "register_error")
                return redirect(url_for("register"))
            if not request.form.get("accept_terms") or not request.form.get("accept_privacy"):
                flash("請閱讀並同意使用條款與隱私政策。", "register_error")
                return redirect(url_for("register"))

            official_email = email if account_type == "hospital" else ""
            contact_name = request.form.get("contact_name", "").strip()
            contact_phone = request.form.get("contact_phone", "").strip()
            institution_code = request.form.get("institution_code", "").strip()
            requested_hospital_name = request.form.get(
                "requested_hospital_name", ""
            ).replace("臺", "台").strip()
            if account_type == "hospital":
                if not all([official_email, contact_name, contact_phone, requested_hospital_name]):
                    flash("院方帳號必須填寫 Email、聯絡人、電話與醫院名稱。", "register_error")
                    return redirect(url_for("register"))
                if any(
                    len(value) > 200
                    for value in [contact_name, contact_phone, institution_code, requested_hospital_name]
                ):
                    flash("申請欄位內容過長，請縮短後再送出。", "register_error")
                    return redirect(url_for("register"))

            hashed_password = bcrypt.generate_password_hash(password).decode("utf-8")
            proof_filename = None
            if "proof_document" in request.files:
                proof_filename, upload_error = save_proof_document(
                    request.files["proof_document"], upload_folder
                )
                if upload_error:
                    flash(upload_error, "register_error")
                    return redirect(url_for("register"))

            now = _timestamp()
            verification_required = bool(app.config.get("EMAIL_VERIFICATION_REQUIRED"))
            verification_token = None
            try:
                with connect_database(database_path) as connection:
                    cursor = connection.execute(
                        """
                        INSERT INTO users(
                            username, email, email_verified_at, password, is_admin,
                            role, approval_status, official_email, contact_name,
                            contact_phone, institution_code, requested_hospital_name,
                            proof_document, terms_accepted_at, privacy_accepted_at,
                            terms_version, password_changed_at, session_version
                        ) VALUES (?, ?, ?, ?, 0, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0)
                        """,
                        (
                            username,
                            email,
                            None if verification_required else now,
                            hashed_password,
                            "hospital" if account_type == "hospital" else "user",
                            "pending" if account_type == "hospital" else "approved",
                            official_email,
                            contact_name,
                            contact_phone,
                            institution_code,
                            requested_hospital_name,
                            proof_filename,
                            now,
                            now,
                            CURRENT_TERMS_VERSION,
                            now,
                        ),
                    )
                    user_id = cursor.lastrowid
                    if verification_required:
                        verification_token = _create_one_time_token(
                            connection,
                            "email_verification_tokens",
                            user_id,
                            timedelta(hours=24),
                        )
                    connection.commit()

                if verification_token:
                    _send_verification_email(app, email, verification_token)
                _record_security_event(app, database_path, "account_registered", user_id)
                flash(
                    "醫院帳號申請已送出，請完成 Email 驗證並等待管理員審核。"
                    if account_type == "hospital" and verification_required
                    else "醫院帳號申請已送出，請等待管理員審核。"
                    if account_type == "hospital"
                    else "註冊成功，請至信箱完成驗證。"
                    if verification_required
                    else "註冊成功",
                    "register_success",
                )
                return redirect(url_for("login"))
            except sqlite3.IntegrityError:
                if proof_filename:
                    remove_file_quietly(os.path.join(upload_folder, proof_filename))
                with connect_database(database_path) as connection:
                    username_exists = connection.execute(
                        "SELECT 1 FROM users WHERE username = ?", (username,)
                    ).fetchone()
                flash("帳號已存在" if username_exists else "Email 已被使用", "register_error")
            except Exception:
                if proof_filename:
                    remove_file_quietly(os.path.join(upload_folder, proof_filename))
                raise

        return render_template("register.html", all_hospitals=hospital_names)

    @app.route("/account/consent", methods=["GET", "POST"])
    @login_required
    def account_consent():
        if request.method == "POST":
            if not request.form.get("accept_terms") or not request.form.get("accept_privacy"):
                flash("必須同意使用條款與隱私政策才能繼續使用。", "account_error")
            else:
                now = _timestamp()
                with connect_database(database_path) as connection:
                    connection.execute(
                        """
                        UPDATE users
                        SET terms_accepted_at = ?, privacy_accepted_at = ?, terms_version = ?
                        WHERE id = ?
                        """,
                        (now, now, CURRENT_TERMS_VERSION, current_user.id),
                    )
                    connection.commit()
                current_user.terms_accepted_at = now
                current_user.privacy_accepted_at = now
                current_user.terms_version = CURRENT_TERMS_VERSION
                _record_security_event(app, database_path, "policy_accepted", current_user.id)
                return redirect(role_home(current_user))
        return render_template("account_consent.html", policy_version=CURRENT_TERMS_VERSION)

    @app.route("/account/verification-required")
    @login_required
    def verification_required():
        if current_user.email_verified_at or not app.config.get("EMAIL_VERIFICATION_REQUIRED"):
            return redirect(role_home(current_user))
        return render_template(
            "verification_required.html",
            email=current_user.email,
            delivery_configured=is_email_delivery_configured(app),
        )

    @app.route("/account/resend-verification", methods=["POST"])
    @login_required
    @limiter.limit("3 per hour")
    def resend_verification_email():
        if not current_user.email or current_user.email_verified_at:
            return redirect(role_home(current_user))
        with connect_database(database_path) as connection:
            token = _create_one_time_token(
                connection,
                "email_verification_tokens",
                current_user.id,
                timedelta(hours=24),
            )
            connection.commit()
        delivered = _send_verification_email(app, current_user.email, token)
        flash(
            "驗證信已重新寄出。" if delivered else "Email 服務尚未設定完成，請聯絡管理員。",
            "account_success" if delivered else "account_error",
        )
        return redirect(url_for("verification_required"))

    @app.route("/verify-email/<token>")
    @limiter.limit("10 per hour")
    def verify_email(token):
        with connect_database(database_path, rows=True) as connection:
            row = _valid_token_row(connection, "email_verification_tokens", token)
            if not row:
                flash("驗證連結無效或已過期。", "login_error")
                return redirect(url_for("login"))
            now = _timestamp()
            connection.execute(
                "UPDATE email_verification_tokens SET used_at = ? WHERE id = ?",
                (now, row["id"]),
            )
            connection.execute(
                "UPDATE users SET email_verified_at = ? WHERE id = ?",
                (now, row["user_id"]),
            )
            connection.commit()
        _record_security_event(app, database_path, "email_verified", row["user_id"])
        flash("Email 驗證完成，現在可以登入。", "register_success")
        return redirect(url_for("login"))

    @app.route("/forgot-password", methods=["GET", "POST"])
    @limiter.limit("5 per hour")
    def forgot_password():
        if request.method == "POST":
            email = _normalize_email(request.form.get("email"))
            with connect_database(database_path, rows=True) as connection:
                row = connection.execute(
                    """
                    SELECT id, email FROM users
                    WHERE lower(email) = ? AND COALESCE(is_active, 1) = 1
                    """,
                    (email,),
                ).fetchone()
                if row:
                    token = _create_one_time_token(
                        connection,
                        "password_reset_tokens",
                        row["id"],
                        timedelta(hours=1),
                    )
                    connection.execute(
                        """
                        UPDATE password_reset_tokens
                        SET requested_ip_hash = ?
                        WHERE token_hash = ?
                        """,
                        (_client_ip_hash(app), _hash_token(token)),
                    )
                    connection.commit()
                    _send_password_reset_email(app, row["email"], token)
                    _record_security_event(
                        app, database_path, "password_reset_requested", row["id"]
                    )
            flash("若此 Email 已註冊，系統會寄出密碼重設連結。", "account_success")
            return redirect(url_for("forgot_password"))
        return render_template(
            "forgot_password.html",
            delivery_configured=is_email_delivery_configured(app),
        )

    @app.route("/reset-password/<token>", methods=["GET", "POST"])
    @limiter.limit("10 per hour")
    def reset_password(token):
        with connect_database(database_path, rows=True) as connection:
            row = _valid_token_row(connection, "password_reset_tokens", token)
        if not row:
            return render_template("reset_password.html", invalid_token=True), 400

        if request.method == "POST":
            password = request.form.get("password", "")
            confirmation = request.form.get("password_confirmation", "")
            validation_error = validate_password(password, row["username"])
            if validation_error:
                flash(validation_error, "account_error")
            elif password != confirmation:
                flash("兩次輸入的密碼不一致。", "account_error")
            else:
                now = _timestamp()
                hashed_password = bcrypt.generate_password_hash(password).decode("utf-8")
                with connect_database(database_path) as connection:
                    connection.execute(
                        """
                        UPDATE users
                        SET password = ?, password_changed_at = ?,
                            session_version = COALESCE(session_version, 0) + 1
                        WHERE id = ?
                        """,
                        (hashed_password, now, row["user_id"]),
                    )
                    connection.execute(
                        "UPDATE password_reset_tokens SET used_at = ? WHERE user_id = ? AND used_at IS NULL",
                        (now, row["user_id"]),
                    )
                    connection.commit()
                _record_security_event(
                    app, database_path, "password_reset_completed", row["user_id"]
                )
                flash("密碼已更新，請使用新密碼登入。", "register_success")
                return redirect(url_for("login"))
        return render_template("reset_password.html", invalid_token=False)

    @app.route("/account")
    @login_required
    def account_page():
        with connect_database(database_path, rows=True) as connection:
            events = connection.execute(
                """
                SELECT event_type, metadata, created_at
                FROM account_security_events
                WHERE user_id = ?
                ORDER BY created_at DESC, id DESC
                LIMIT 10
                """,
                (current_user.id,),
            ).fetchall()
        return render_template(
            "account.html",
            events=events,
            email_verification_required=app.config.get("EMAIL_VERIFICATION_REQUIRED"),
            delivery_configured=is_email_delivery_configured(app),
        )

    @app.route("/account/email", methods=["POST"])
    @login_required
    @limiter.limit("5 per hour")
    def update_account_email():
        email = _normalize_email(request.form.get("email"))
        password = request.form.get("current_password", "")
        error = _validate_email(email)
        if error:
            flash(error, "account_error")
            return redirect(url_for("account_page"))
        if not bcrypt.check_password_hash(current_user.password, password):
            flash("目前密碼不正確。", "account_error")
            return redirect(url_for("account_page"))

        verification_required = bool(app.config.get("EMAIL_VERIFICATION_REQUIRED"))
        token = None
        try:
            with connect_database(database_path) as connection:
                connection.execute(
                    """
                    UPDATE users
                    SET email = ?, official_email = CASE WHEN role = 'hospital' THEN ? ELSE official_email END,
                        email_verified_at = ?
                    WHERE id = ?
                    """,
                    (
                        email,
                        email,
                        None if verification_required else _timestamp(),
                        current_user.id,
                    ),
                )
                if verification_required:
                    token = _create_one_time_token(
                        connection,
                        "email_verification_tokens",
                        current_user.id,
                        timedelta(hours=24),
                    )
                connection.commit()
        except sqlite3.IntegrityError:
            flash("Email 已被使用。", "account_error")
            return redirect(url_for("account_page"))

        current_user.email = email
        current_user.email_verified_at = None if verification_required else _timestamp()
        delivered = _send_verification_email(app, email, token) if token else True
        _record_security_event(app, database_path, "email_changed", current_user.id)
        flash(
            "Email 已更新，請至信箱完成驗證。" if token and delivered else
            "Email 已更新，但驗證信暫時無法寄出。" if token else
            "Email 已更新。",
            "account_success" if delivered else "account_error",
        )
        return redirect(url_for("verification_required" if token else "account_page"))

    @app.route("/account/password", methods=["POST"])
    @login_required
    @limiter.limit("5 per hour")
    def change_account_password():
        current_password = request.form.get("current_password", "")
        new_password = request.form.get("new_password", "")
        confirmation = request.form.get("password_confirmation", "")
        if not bcrypt.check_password_hash(current_user.password, current_password):
            flash("目前密碼不正確。", "account_error")
        elif new_password != confirmation:
            flash("兩次輸入的新密碼不一致。", "account_error")
        else:
            validation_error = validate_password(new_password, current_user.username)
            if validation_error:
                flash(validation_error, "account_error")
            else:
                hashed_password = bcrypt.generate_password_hash(new_password).decode("utf-8")
                now = _timestamp()
                with connect_database(database_path) as connection:
                    connection.execute(
                        """
                        UPDATE users
                        SET password = ?, password_changed_at = ?,
                            session_version = COALESCE(session_version, 0) + 1
                        WHERE id = ?
                        """,
                        (hashed_password, now, current_user.id),
                    )
                    new_version = connection.execute(
                        "SELECT session_version FROM users WHERE id = ?",
                        (current_user.id,),
                    ).fetchone()[0]
                    connection.commit()
                current_user.password = hashed_password
                current_user.session_version = new_version
                session["session_version"] = new_version
                _record_security_event(app, database_path, "password_changed", current_user.id)
                flash("密碼已更新，其他工作階段已登出。", "account_success")
        return redirect(url_for("account_page"))

    @app.route("/account/logout-others", methods=["POST"])
    @login_required
    @limiter.limit("5 per hour")
    def logout_other_sessions():
        with connect_database(database_path) as connection:
            connection.execute(
                "UPDATE users SET session_version = COALESCE(session_version, 0) + 1 WHERE id = ?",
                (current_user.id,),
            )
            new_version = connection.execute(
                "SELECT session_version FROM users WHERE id = ?", (current_user.id,)
            ).fetchone()[0]
            connection.commit()
        current_user.session_version = new_version
        session["session_version"] = new_version
        _record_security_event(app, database_path, "other_sessions_revoked", current_user.id)
        flash("其他裝置上的登入狀態已失效。", "account_success")
        return redirect(url_for("account_page"))

    @app.route("/account/delete", methods=["POST"])
    @login_required
    @limiter.limit("2 per hour")
    def delete_account():
        if current_user.is_admin:
            flash("管理員帳號不可在前台自行停用。", "account_error")
            return redirect(url_for("account_page"))
        password = request.form.get("current_password", "")
        confirmation = request.form.get("confirmation", "").strip()
        if confirmation != "停用帳號" or not bcrypt.check_password_hash(
            current_user.password, password
        ):
            flash("確認文字或目前密碼不正確。", "account_error")
            return redirect(url_for("account_page"))

        with connect_database(database_path, rows=True) as connection:
            row = connection.execute(
                "SELECT proof_document FROM users WHERE id = ?", (current_user.id,)
            ).fetchone()
            proof_filename = row["proof_document"] if row else None
            deleted_username = f"deleted_{current_user.id}_{secrets.token_hex(4)}"
            unusable_password = bcrypt.generate_password_hash(
                secrets.token_urlsafe(32)
            ).decode("utf-8")
            now = _timestamp()
            connection.execute(
                "DELETE FROM user_hospital_favorites WHERE user_id = ?",
                (current_user.id,),
            )
            connection.execute(
                "DELETE FROM password_reset_tokens WHERE user_id = ?",
                (current_user.id,),
            )
            connection.execute(
                "DELETE FROM email_verification_tokens WHERE user_id = ?",
                (current_user.id,),
            )
            connection.execute(
                """
                UPDATE users
                SET username = ?, email = NULL, email_verified_at = NULL,
                    password = ?, official_email = NULL, contact_name = NULL,
                    contact_phone = NULL, institution_code = NULL,
                    requested_hospital_name = NULL, rejection_reason = NULL,
                    proof_document = NULL, hospital_id = NULL, is_active = 0,
                    deleted_at = ?, session_version = COALESCE(session_version, 0) + 1
                WHERE id = ?
                """,
                (deleted_username, unusable_password, now, current_user.id),
            )
            connection.commit()
        if proof_filename:
            remove_file_quietly(os.path.join(upload_folder, proof_filename))
        _record_security_event(app, database_path, "account_deactivated", current_user.id)
        logout_user()
        session.clear()
        flash("帳號已停用，個人聯絡資料已移除。", "register_success")
        return redirect(url_for("login"))

    @app.route("/logout", methods=["POST"])
    @login_required
    def logout():
        user_id = current_user.id
        _record_security_event(app, database_path, "logout", user_id)
        logout_user()
        session.clear()
        return redirect(url_for("login"))

    _initialize_admin(app, database_path, bcrypt)
