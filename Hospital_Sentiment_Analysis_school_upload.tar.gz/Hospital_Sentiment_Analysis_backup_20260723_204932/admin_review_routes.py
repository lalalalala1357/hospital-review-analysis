"""Administrative review inspection, moderation, and export routes."""

from datetime import datetime
import io
from urllib.parse import quote

from flask import flash, jsonify, redirect, send_file, url_for
from flask_login import current_user, login_required
import pandas as pd

from access_control import admin_required
from database import connect_database
from review_time_utils import normalize_stored_review_time


def register_admin_review_routes(
    app,
    *,
    database_path,
    classify_negative_issue,
    get_negative_issue_rows,
    generate_improvement_suggestions,
    get_representative_reviews,
):
    @app.route('/admin/get_reviews/<int:hospital_id>')
    @login_required
    @admin_required
    def get_hospital_reviews(hospital_id):
        if not current_user.is_admin:
            return jsonify({'error': 'Unauthorized'}), 403

        with connect_database(database_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT id, content, analyzed_sentiment, review_time, stored_at
                FROM reviews
                WHERE hospital_id = ?
                ORDER BY id DESC
            """, (hospital_id,))
            reviews = cursor.fetchall()

        data = []
        issue_source = []
        for review in reviews:
            issue_category = classify_negative_issue(review[1], review[2])
            data.append({
                'id': review[0],
                'content': review[1],
                'sentiment': review[2],
                'time': normalize_stored_review_time(review[3], review[4]),
                'issue_category': issue_category,
            })
            issue_source.append({'text': review[1], 'label': review[2]})

        pos_count = sum(1 for item in data if item['sentiment'] == 'POSITIVE')
        neg_count = sum(1 for item in data if item['sentiment'] == 'NEGATIVE')
        issue_summary = get_negative_issue_rows(issue_source)

        return jsonify({
            'reviews': data,
            'issue_summary': issue_summary,
            'suggestions': generate_improvement_suggestions(issue_summary, neg_count, len(data)),
            'representative_reviews': get_representative_reviews(data, issue_summary),
            'pos': pos_count,
            'neg': neg_count,
            'total': len(data),
        })

    @app.route('/admin/get_issue_reviews/<path:issue_category>')
    @login_required
    @admin_required
    def get_issue_reviews(issue_category):
        if not current_user.is_admin:
            return jsonify({'error': 'Unauthorized'}), 403

        with connect_database(database_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT r.id, r.content, r.analyzed_sentiment, r.review_time,
                       h.id, h.name, r.stored_at
                FROM reviews r
                JOIN hospitals h ON r.hospital_id = h.id
                WHERE r.analyzed_sentiment = 'NEGATIVE'
                ORDER BY r.id DESC
            """)
            reviews = cursor.fetchall()

        data = []
        for review in reviews:
            detected_issue = classify_negative_issue(review[1], review[2])
            if detected_issue != issue_category:
                continue
            data.append({
                'id': review[0],
                'content': review[1],
                'sentiment': review[2],
                'time': normalize_stored_review_time(review[3], review[6]),
                'hospital_id': review[4],
                'hospital': review[5],
                'issue_category': detected_issue,
            })

        return jsonify(data)

    @app.route('/admin/delete_review/<int:review_id>', methods=['POST'])
    @login_required
    @admin_required
    def delete_review(review_id):
        if not current_user.is_admin:
            return redirect(url_for('index'))

        with connect_database(database_path) as conn:
            cursor = conn.cursor()
            cursor.execute('DELETE FROM sentiment_audit_items WHERE review_id = ?', (review_id,))
            cursor.execute('DELETE FROM reviews WHERE id = ?', (review_id,))
            conn.commit()

        flash('評論已刪除', 'analyze_success')
        return redirect(url_for('admin_page'))

    @app.route('/admin/export_csv/<int:hospital_id>')
    @login_required
    @admin_required
    def export_hospital_csv(hospital_id):
        if not current_user.is_admin:
            return redirect(url_for('index'))

        with connect_database(database_path) as conn:
            data_frame = pd.read_sql_query("""
                SELECT r.review_time AS '評論時間',
                       r.stored_at AS '爬取時間',
                       r.content AS '評論內容',
                       r.analyzed_sentiment AS '情緒分析',
                       h.name AS '醫院名稱'
                FROM reviews r
                JOIN hospitals h ON r.hospital_id = h.id
                WHERE r.hospital_id = ?
                ORDER BY r.review_time DESC
            """, conn, params=(hospital_id,))

        if data_frame.empty:
            flash('該醫院沒有評論可匯出', 'analyze_error')
            return redirect(url_for('admin_page'))

        data_frame['評論時間'] = data_frame.apply(
            lambda row: normalize_stored_review_time(row['評論時間'], row['爬取時間']),
            axis=1,
        )
        data_frame = data_frame.drop(columns=['爬取時間'])
        data_frame['負評原因'] = data_frame.apply(
            lambda row: classify_negative_issue(row['評論內容'], row['情緒分析']),
            axis=1,
        )
        data_frame = data_frame[['醫院名稱', '評論時間', '情緒分析', '負評原因', '評論內容']]

        output = io.BytesIO()
        data_frame.to_csv(output, index=False, encoding='utf-8-sig')
        output.seek(0)
        hospital_name = data_frame.iloc[0]['醫院名稱']
        filename = quote(f"{hospital_name}_評論報表_{datetime.now().strftime('%Y%m%d')}.csv")

        return send_file(
            output,
            mimetype='text/csv',
            as_attachment=True,
            download_name=filename,
        )
