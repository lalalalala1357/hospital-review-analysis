# 正式環境部署手冊

## 營運基線

正式環境必須使用 HTTPS、獨立網域、Redis、定期離站備份與主機層監控。`app.py` 仍是唯一入口；本機使用 `python3 app.py`，正式環境使用映像檔內建的 Gunicorn。

執行環境固定使用 Python 3.11。不要以作業系統內建且已停止支援的 Python 3.9 部署。

目前批次爬蟲狀態與查詢任務執行器保存在程序記憶體，且主資料庫仍是 SQLite，因此正式環境固定使用一個 Gunicorn worker。可使用多個 threads 服務一般請求，但不可增加 worker 數量。要水平擴充到多台主機前，必須先把資料庫改成 PostgreSQL，並把背景工作移到獨立 queue worker。

## 套件版本與建置

正式映像與 CI 一律從 `requirements.lock` 安裝精確版本；`requirements.txt` 只描述允許升級的相容範圍。更新套件時需同步修改兩份檔案，並依序執行完整單元與 smoke test、`pip check`、`pip-audit` 及 Bandit，通過後才可發布。Docker 建置已在安裝後執行 `pip check`，避免相依衝突進入映像。

測試與維護工具可另行安裝，不得加入正式映像。至少每月檢查安全公告；重大漏洞立即升級，其餘升級集中在有回歸測試的維護時段。

## 必要環境變數

```env
APP_ENV=production
STRICT_PRODUCTION_CONFIG=1
FLASK_SECRET_KEY=至少32字元的隨機值
DEFAULT_ADMIN_PASSWORD=至少12字元且符合複雜度的隨機值
SESSION_COOKIE_SECURE=1
TRUST_PROXY=1
RATELIMIT_STORAGE_URI=redis://redis:6379/0
GOOGLE_GEMINI_API_KEY=正式金鑰
ENABLE_BATCH_SCHEDULER=0
LOG_FORMAT=json
LOG_LEVEL=INFO
PUBLIC_BASE_URL=https://你的正式網域
SUPPORT_EMAIL=客服信箱
EMAIL_VERIFICATION_REQUIRED=1
SMTP_HOST=郵件伺服器
SMTP_PORT=587
SMTP_USERNAME=郵件帳號
SMTP_PASSWORD=郵件密碼或應用程式密碼
SMTP_USE_TLS=1
SMTP_USE_SSL=0
MAIL_FROM=寄件者信箱
SYMPTOM_RETENTION_DAYS=90
ANALYSIS_JOB_RETENTION_HOURS=24
ANALYSIS_JOB_STALE_MINUTES=30
BACKGROUND_ANALYSIS_WORKERS=1
```

可用以下命令產生密鑰：

```bash
python3 -c "import secrets; print(secrets.token_urlsafe(48))"
```

`FLASK_SECRET_KEY` 變更會讓現有登入 session 失效。金鑰不可寫進 Git、Docker image、工單或聊天紀錄。

## 啟動與驗證

```bash
docker compose -f docker-compose.yml -f docker-compose.production.yml build --pull
docker compose -f docker-compose.yml -f docker-compose.production.yml up -d
docker compose -f docker-compose.yml -f docker-compose.production.yml ps
docker compose -f docker-compose.yml -f docker-compose.production.yml logs --tail=200 hospital-sentiment
```

負載平衡器或監控服務應檢查：

```text
GET /health/live
GET /health/ready
```

`live` 只確認程序存活；`ready` 會檢查 SQLite 完整性、schema 版本、必要醫院資料檔、私有資料目錄可寫、Email 驗證設定，以及是否有超時未完成的分析任務。只有 `ready` 回傳 200 才應接收流量。

部署完成後至少驗證：註冊、驗證信、忘記密碼、登入、醫院查詢、帳號安全頁、管理後台、資料庫備份與 `/health/ready`。不要在正式資料上用自動化測試執行刪除帳號、刪除評論或批次爬蟲。

## HTTPS 與反向代理

不要把容器的 `5007` 連接埠直接公開到網際網路。前方必須使用受管理的 HTTPS load balancer、Nginx、Caddy 或雲端反向代理，並只轉送可信任的 `X-Forwarded-*` 標頭。正式環境需保持 `SESSION_COOKIE_SECURE=1` 與 `TRUST_PROXY=1`。

## 備份與還原

後台的「備份資料庫」使用 SQLite backup API 產生一致性快照，適合人工下載。營運上還需要每天自動備份 `hospital_reviews.db` 與 `data/private_uploads/` 到另一個加密儲存位置，建議保留 7 份每日、4 份每週與 12 份每月版本。備份儲存帳號不可與網站執行帳號共用刪除權限。

每月至少做一次還原演練。還原前先停止網站，保留目前 DB，再以已驗證的備份替換 `hospital_reviews.db`；啟動時 migration 會自動補齊 schema。完成後確認 `/health/ready`、登入、評論查詢、背景查詢與管理後台。

## 監控與告警

- 每分鐘檢查 `/health/live`，連續 3 次失敗立即通知。
- 每分鐘檢查 `/health/ready`，任何 503 都需保留回應中的 checks 與 `X-Request-ID`。
- 監控 HTTP 5xx 比例、P95 延遲、磁碟剩餘空間、SQLite 檔案大小、備份時間與備份失敗。
- JSON log 送到主機日誌或集中式日誌平台；告警中不得附上評論全文、症狀內容、Email 或 session。
- 爬蟲與第三方 AI 失敗要和網站不可用分開告警，避免外部服務波動被誤判為整站故障。

## 發布與回復

1. 發布前在測試資料庫跑完整單元測試、模板解析與 Python 編譯。
2. 產生一致性 SQLite 備份並記錄目前映像版本。
3. 更新映像後先等待 `/health/ready` 回傳 200，再開放流量。
4. 若核心流程失敗，停止新映像、還原上一版映像；只有 migration 或資料異常時才還原資料庫。
5. 回復後重新驗證登入、查詢、後台與備份，不可只看程序是否存活。

## 上線檢查

- DNS、TLS 憑證與 HTTPS redirect 正常。
- `.env` 權限僅部署帳號可讀，正式金鑰未進入 image。
- 管理員預設密碼已變更，未共用帳號。
- Redis 沒有公開對外連接埠。
- 健康檢查、錯誤率、延遲、磁碟空間與備份失敗均有告警。
- 上傳目錄與資料庫都有持久化，且不在公開 static 路徑。
- Email 驗證信與密碼重設信可送達，連結使用正式 HTTPS 網域。
- Gunicorn 維持 `--workers 1`，背景分析 worker 維持 `1`。
- CI 的單元測試、`pip-audit` 與 Bandit 全部通過。
- 已完成資料處理告知、隱私權政策、服務條款及第三方資料來源合規審查。
