# 系統架構與演進

## 目前模組

- `app.py`：Flask 入口與尚未搬出的業務路由。
- `auth_routes.py`：使用者載入、登入、註冊、登出、初始管理員與私密文件授權。
- `email_service.py`：驗證信與密碼重設信的安全 SMTP 傳送。
- `analysis_job_service.py`：SQLite 背景分析任務、狀態查詢、取消與過期清理。
- `app_config.py`：環境設定、Cookie、session 與正式環境防呆。
- `db_schema.py`：版本化 schema migration 與索引。
- `database.py`：SQLite 連線、健康檢查與一致性備份。
- `access_control.py`：管理員權限與 JSON/HTML 回應判斷。
- `production_security.py`：安全標頭、proxy 與舊公開上傳路徑封鎖。
- `file_uploads.py`：私密佐證文件驗證與儲存。
- `observability.py`：JSON log、request ID 與請求耗時。
- `health_routes.py`：liveness 與資料庫、儲存、郵件、背景任務 readiness。
- `error_handlers.py`：不洩漏內部例外的統一錯誤回應。
- `gemini_gateway.py`：Google Gen AI 新版 SDK 封裝、timeout 與舊環境過渡相容。
- `business_intelligence.py`：期間同比、問題分類、競品基準、預警去重與報告快照。
- `hospital_operations.py`：院方營運中心 Blueprint 與租戶資料權限。
- `hospital_profile_service.py`：醫院檔案統計、趨勢、獎項與收藏 read model。
- `hospital_profile_routes.py`：醫院檔案、收藏、通知、院方申請與獎項送審路由。
- `profile_keywords.py`：醫院檔案同步頁面使用的低延遲關鍵字分析，不改動爬蟲共用分析函式。
- `sentiment_audit.py`：人工情緒抽驗選樣、指標計算與路由。
- `admin_content_routes.py`：後台備份、停用詞、症狀紀錄與公告。
- `admin_review_routes.py`：後台評論檢視、刪除與匯出。
- `admin_user_routes.py`：會員角色、院方審核與個資移除。
- `admin_award_routes.py`：獎項新增、審核與刪除。

為維持既有模板的 `url_for()` endpoint，相容性敏感的舊路由使用顯式註冊函式，而不是加上 Blueprint 名稱前綴。每個模組都有路徑、HTTP method 與 endpoint 契約測試。

## 營運功能邊界

營運功能只讀取 `hospitals` 與 `reviews`，寫入範圍限制在 `business_report_schedules`、`business_reports` 與院方通知。`hospital_alert_rules` 與 `reputation_alerts` 僅保留舊資料供回溯，執行階段不再讀寫。Google Maps 爬蟲、評論解析、情緒分析與批次排程不依賴營運模組。

## 下一階段拆分順序

1. 先為 Google Maps 爬蟲補錄製式 fixture 與解析回歸測試，再把 route 與爬取 service 分離。
2. 把 Gemini、情緒模型與本地 fallback 移到 `ai` service。
3. 拆分 `admin_page` 的大型唯讀查詢與 PK／排名服務。
4. 保留 SQLite 單機部署；需要多 worker 或多主機時，再遷移 PostgreSQL 與獨立 queue worker。

每次搬移都必須先補 characterization test，保留既有 endpoint 名稱與回應格式，再刪除舊程式。啟動方式在整個過程都維持 `python3 app.py` 或 `gunicorn app:app`。
