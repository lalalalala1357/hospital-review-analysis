import json
import logging
import os
import re
import sys
import time
import uuid
from datetime import datetime, timezone

from flask import g, request


class JsonFormatter(logging.Formatter):
    def format(self, record):
        payload = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        for name in ("request_id", "method", "path", "status", "duration_ms"):
            value = getattr(record, name, None)
            if value is not None:
                payload[name] = value
        if record.exc_info:
            payload["exception"] = self.formatException(record.exc_info)
        return json.dumps(payload, ensure_ascii=False)


class HumanFormatter(logging.Formatter):
    def format(self, record):
        message = record.getMessage()
        if record.exc_info:
            message = f"{message}\n{self.formatException(record.exc_info)}"
        if record.levelno >= logging.ERROR:
            return f"❌ {message}"
        if record.levelno >= logging.WARNING:
            return f"⚠️ {message}"
        return message


def configure_logging(app):
    level_name = os.getenv("LOG_LEVEL", "INFO").upper()
    level = getattr(logging, level_name, logging.INFO)
    handler = logging.StreamHandler(sys.stdout)
    if os.getenv("FORCE_JSON_LOGS", "0").strip() == "1":
        handler.setFormatter(JsonFormatter())
    else:
        handler.setFormatter(HumanFormatter())

    root_logger = logging.getLogger()
    root_logger.handlers.clear()
    root_logger.addHandler(handler)
    root_logger.setLevel(level)
    app.logger.handlers.clear()
    app.logger.propagate = True
    for noisy_logger in (
        "werkzeug",
        "selenium",
        "urllib3",
        "WDM",
        "webdriver_manager",
        "transformers",
    ):
        logging.getLogger(noisy_logger).setLevel(logging.WARNING)


def register_request_logging(app):
    request_logger = logging.getLogger("hospital.requests")

    def describe_request(response, duration_ms):
        path = request.path
        method = request.method
        status = response.status_code
        suffix = f"{status}，{duration_ms} ms"

        if path.startswith("/static/") or path == "/favicon.ico":
            return None
        if method == "GET" and path.startswith("/api/analysis-jobs/") and status < 400:
            return None
        if path == "/api/analysis-jobs" and method == "POST":
            return f"🧪 已建立醫院分析任務（{suffix}）"
        if path.startswith("/api/analysis-jobs/"):
            return f"🔎 正在查看分析任務狀態：{path.rsplit('/', 1)[-1]}（{suffix}）"
        if path == "/analyze":
            return f"🧪 正在分析醫院評論（{suffix}）"
        if path.startswith("/api/"):
            label = "API 完成" if status < 400 else "API 發生錯誤"
            return f"🔌 {label}：{method} {path}（{suffix}）"
        if method == "GET":
            endpoint = request.endpoint or "頁面"
            return f"📍 開啟頁面：{path}（{endpoint}，{suffix}）"
        return f"➡️ 處理請求：{method} {path}（{suffix}）"

    @app.before_request
    def start_request_timer():
        supplied_id = request.headers.get("X-Request-ID", "").strip()[:128]
        g.request_id = (
            supplied_id
            if supplied_id and re.fullmatch(r"[A-Za-z0-9._-]+", supplied_id)
            else uuid.uuid4().hex
        )
        g.request_started_at = time.perf_counter()

    @app.after_request
    def log_request(response):
        duration_ms = round(
            (time.perf_counter() - getattr(g, "request_started_at", time.perf_counter()))
            * 1000,
            2,
        )
        response.headers["X-Request-ID"] = getattr(g, "request_id", "")
        message = describe_request(response, duration_ms)
        if not message:
            return response

        log_method = request_logger.info if response.status_code < 400 else request_logger.warning
        if (
            request.method == "GET"
            and request.path.startswith("/api/analysis-jobs/")
            and response.status_code < 400
        ):
            log_method = request_logger.debug

        log_method(
            message,
            extra={
                "request_id": getattr(g, "request_id", None),
                "method": request.method,
                "path": request.path,
                "status": response.status_code,
                "duration_ms": duration_ms,
            },
        )
        return response
