from functools import wraps

from flask import flash, jsonify, redirect, request, url_for
from flask_login import current_user


def wants_json_response():
    return (
        request.is_json
        or request.path.startswith('/api/')
        or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
        or 'application/json' in request.headers.get('Accept', '')
    )


def admin_required(view_func):
    @wraps(view_func)
    def wrapped_view(*args, **kwargs):
        if not getattr(current_user, 'is_admin', False):
            if wants_json_response():
                return jsonify({'error': '權限不足'}), 403
            flash('您沒有權限進入管理後台', 'login_error')
            return redirect(url_for('index'))
        return view_func(*args, **kwargs)
    return wrapped_view


def can_access_hospital_profile(user, hospital_id):
    if getattr(user, "is_admin", False):
        return True
    if getattr(user, "role", None) != "hospital":
        return True
    return (
        getattr(user, "approval_status", None) == "approved"
        and getattr(user, "hospital_id", None) == hospital_id
    )
