import sqlite3
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

from flask import Flask

from hospital_profile_routes import (
    HospitalProfileRouteDependencies,
    register_hospital_profile_routes,
)
from hospital_profile_service import HospitalProfileService


class HospitalProfileRouteContractTest(unittest.TestCase):
    def test_legacy_endpoints_paths_and_methods_are_preserved(self):
        app = Flask(__name__)
        dependencies = HospitalProfileRouteDependencies(
            database_path='unused.db',
            hospital_names=[],
            get_profile_data=lambda hospital_id: None,
            can_view_profile=lambda hospital_id: True,
            get_user_favorites=lambda user_id: [],
            save_proof_document=lambda file_storage: (None, None),
            log_award_application_history=lambda *args: None,
            normalize_hospital_name=lambda name: name,
        )

        register_hospital_profile_routes(app, dependencies)

        actual = {
            rule.endpoint: (rule.rule, frozenset(rule.methods - {'HEAD', 'OPTIONS'}))
            for rule in app.url_map.iter_rules()
            if rule.endpoint != 'static'
        }
        expected = {
            'hospital_profile': ('/hospital/<int:hospital_id>', frozenset({'GET'})),
            'hospital_report': ('/hospital/<int:hospital_id>/report', frozenset({'GET'})),
            'submit_award_application': (
                '/hospital/<int:hospital_id>/award_application',
                frozenset({'POST'}),
            ),
            'hospital_profile_by_name': (
                '/hospital/by-name/<path:hospital_name>',
                frozenset({'GET'}),
            ),
            'favorites_page': ('/favorites', frozenset({'GET'})),
            'toggle_hospital_favorite': (
                '/hospital/<int:hospital_id>/favorite',
                frozenset({'POST'}),
            ),
            'api_toggle_hospital_favorite': (
                '/api/hospital/<int:hospital_id>/favorite',
                frozenset({'POST'}),
            ),
            'update_favorite_note': (
                '/favorites/<int:hospital_id>/note',
                frozenset({'POST'}),
            ),
            'hospital_dashboard': ('/hospital/dashboard', frozenset({'GET'})),
            'hospital_notifications_page': ('/hospital/notifications', frozenset({'GET'})),
            'mark_hospital_notification_read': (
                '/hospital/notifications/<int:notification_id>/read',
                frozenset({'POST'}),
            ),
            'mark_all_hospital_notifications_read': (
                '/hospital/notifications/read_all',
                frozenset({'POST'}),
            ),
            'hospital_application_status': (
                '/hospital/application',
                frozenset({'GET', 'POST'}),
            ),
            'resubmit_award_application': (
                '/hospital/award_application/<int:app_id>/resubmit',
                frozenset({'POST'}),
            ),
            'delete_award_application': (
                '/hospital/award_application/<int:app_id>/delete',
                frozenset({'POST'}),
            ),
        }
        self.assertEqual(actual, expected)


class HospitalProfileServiceTest(unittest.TestCase):
    def test_profile_statistics_are_aggregated_without_flask_routes(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            database_path = Path(temp_dir) / 'profile.db'
            self._create_database(database_path)

            service = HospitalProfileService(
                database_path=str(database_path),
                award_departments=['急診'],
                classify_negative_issue=lambda text, sentiment: (
                    '等待時間' if sentiment == 'NEGATIVE' else None
                ),
                get_negative_issue_rows=lambda items, limit: [],
                generate_improvement_suggestions=lambda issues, negative, total: [],
                get_representative_reviews=lambda reviews, issues: reviews[:1],
                extract_keywords=lambda items, top_n: {'labels': ['服務'], 'data': [2]},
                generate_hospital_feature_tags=lambda reviews, issues, awards, stats: ['服務穩定'],
                resolve_hospital_address=lambda name, address: (address, 'database'),
                get_favorite_info=lambda user_id, hospital_id: {'note': '追蹤'},
            )
            user = SimpleNamespace(id=7, role='member', hospital_id=None)

            profile = service.build(1, user)

            self.assertEqual(profile['hospital']['name'], '測試醫院')
            self.assertEqual(profile['stats']['total'], 2)
            self.assertEqual(profile['stats']['positive_rate'], 50)
            self.assertEqual(profile['stats']['negative_rate'], 50)
            self.assertEqual(profile['stats']['satisfaction_score'], 5.0)
            self.assertEqual(profile['keywords']['labels'], ['服務'])
            self.assertEqual(profile['favorite']['note'], '追蹤')

    @staticmethod
    def _create_database(database_path):
        with sqlite3.connect(database_path) as conn:
            conn.executescript("""
                CREATE TABLE hospitals (
                    id INTEGER PRIMARY KEY,
                    name TEXT,
                    address TEXT,
                    created_at TEXT
                );
                CREATE TABLE reviews (
                    id INTEGER PRIMARY KEY,
                    hospital_id INTEGER,
                    content TEXT,
                    analyzed_sentiment TEXT,
                    review_time TEXT,
                    stored_at TEXT,
                    department TEXT
                );
                CREATE TABLE hospital_awards (
                    hospital_name TEXT,
                    department TEXT,
                    award_name TEXT
                );
                CREATE TABLE hospital_award_applications (
                    id INTEGER PRIMARY KEY,
                    hospital_id INTEGER,
                    hospital_name TEXT,
                    department TEXT,
                    award_name TEXT,
                    status TEXT,
                    admin_note TEXT,
                    proof_document TEXT,
                    created_at TEXT,
                    reviewed_at TEXT
                );
                INSERT INTO hospitals(id, name, address, created_at)
                VALUES (1, '測試醫院', '台北市測試路 1 號', '2026-07-01 09:00:00');
                INSERT INTO reviews(
                    id, hospital_id, content, analyzed_sentiment,
                    review_time, stored_at, department
                ) VALUES
                    (1, 1, '服務很好', 'POSITIVE', '2026-07-20', '2026-07-20 10:00:00', '急診'),
                    (2, 1, '等待太久', 'NEGATIVE', '2026-07-21', '2026-07-21 10:00:00', '急診');
            """)


if __name__ == '__main__':
    unittest.main()
