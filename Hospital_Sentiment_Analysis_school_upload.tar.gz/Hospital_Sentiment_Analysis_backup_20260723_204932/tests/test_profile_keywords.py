import sqlite3
import tempfile
import unittest
from pathlib import Path

from profile_keywords import extract_profile_keywords


class ProfileKeywordTest(unittest.TestCase):
    def test_profile_extractor_disables_hmm_and_applies_stop_words(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            database_path = Path(temp_dir) / 'keywords.db'
            with sqlite3.connect(database_path) as conn:
                conn.execute('CREATE TABLE stop_words(id INTEGER PRIMARY KEY, word TEXT UNIQUE)')
                conn.execute('INSERT INTO stop_words(word) VALUES (?)', ('服務',))

            calls = []

            def tokenizer(text, **kwargs):
                calls.append((text, kwargs))
                return iter([
                    ('服務', 'n'),
                    ('等待', 'v'),
                    ('親切', 'a'),
                ])

            result = extract_profile_keywords(
                str(database_path),
                [
                    {'text': '服務親切，但等待較久'},
                    {'text': '等待時間偏長'},
                ],
                tokenizer=tokenizer,
            )

        self.assertEqual(calls[0][1], {'HMM': False})
        self.assertEqual(result['labels'], ['等待', '親切'])
        self.assertEqual(result['data'], [2, 1])


if __name__ == '__main__':
    unittest.main()
