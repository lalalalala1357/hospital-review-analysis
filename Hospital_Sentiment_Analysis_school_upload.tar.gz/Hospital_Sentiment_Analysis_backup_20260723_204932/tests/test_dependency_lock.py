import re
import unittest
from pathlib import Path


class DependencyLockTest(unittest.TestCase):
    def test_lock_covers_every_direct_requirement_with_exact_versions(self):
        project_root = Path(__file__).resolve().parents[1]

        def package_lines(path):
            return [
                line.strip()
                for line in path.read_text(encoding='utf-8').splitlines()
                if line.strip() and not line.lstrip().startswith('#')
            ]

        def package_name(line):
            return re.split(r'[<>=!~\[]', line, maxsplit=1)[0].lower().replace('_', '-')

        requirements = package_lines(project_root / 'requirements.txt')
        lock = package_lines(project_root / 'requirements.lock')

        self.assertTrue(all('==' in line for line in lock))
        self.assertEqual(
            {package_name(line) for line in requirements},
            {package_name(line) for line in lock},
        )


if __name__ == '__main__':
    unittest.main()
