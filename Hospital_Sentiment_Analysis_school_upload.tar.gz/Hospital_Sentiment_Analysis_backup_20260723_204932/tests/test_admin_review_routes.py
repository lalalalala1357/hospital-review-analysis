import unittest

from flask import Flask

from admin_review_routes import register_admin_review_routes


class AdminReviewRouteContractTest(unittest.TestCase):
    def test_legacy_admin_review_endpoints_are_preserved(self):
        app = Flask(__name__)
        register_admin_review_routes(
            app,
            database_path='unused.db',
            classify_negative_issue=lambda text, sentiment: None,
            get_negative_issue_rows=lambda reviews: [],
            generate_improvement_suggestions=lambda issues, negative, total: [],
            get_representative_reviews=lambda reviews, issues: [],
        )

        actual = {
            rule.endpoint: (rule.rule, frozenset(rule.methods - {'HEAD', 'OPTIONS'}))
            for rule in app.url_map.iter_rules()
            if rule.endpoint != 'static'
        }
        self.assertEqual(actual, {
            'get_hospital_reviews': (
                '/admin/get_reviews/<int:hospital_id>',
                frozenset({'GET'}),
            ),
            'get_issue_reviews': (
                '/admin/get_issue_reviews/<path:issue_category>',
                frozenset({'GET'}),
            ),
            'delete_review': (
                '/admin/delete_review/<int:review_id>',
                frozenset({'POST'}),
            ),
            'export_hospital_csv': (
                '/admin/export_csv/<int:hospital_id>',
                frozenset({'GET'}),
            ),
        })


if __name__ == '__main__':
    unittest.main()
