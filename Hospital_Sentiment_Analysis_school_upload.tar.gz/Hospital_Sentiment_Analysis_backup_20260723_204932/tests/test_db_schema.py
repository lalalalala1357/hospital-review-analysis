import os
import sqlite3
import tempfile
import unittest

from db_schema import MIGRATIONS, ensure_schema


class DatabaseSchemaTest(unittest.TestCase):
    def test_schema_is_versioned_and_idempotent(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            database_path = os.path.join(temp_dir, "schema.db")
            ensure_schema(database_path)
            ensure_schema(database_path)

            with sqlite3.connect(database_path) as connection:
                migration_count = connection.execute(
                    "SELECT COUNT(*) FROM schema_migrations"
                ).fetchone()[0]
                user_columns = {
                    row[1]
                    for row in connection.execute("PRAGMA table_info(users)").fetchall()
                }
                review_indexes = {
                    row[1]
                    for row in connection.execute("PRAGMA index_list(reviews)").fetchall()
                }
                operations_tables = {
                    row[0]
                    for row in connection.execute(
                        "SELECT name FROM sqlite_master WHERE type = 'table'"
                    ).fetchall()
                }

            self.assertEqual(migration_count, len(MIGRATIONS))
            self.assertIn("proof_document", user_columns)
            self.assertIn("idx_reviews_hospital_stored", review_indexes)
            self.assertIn("hospital_alert_rules", operations_tables)
            self.assertIn("reputation_alerts", operations_tables)
            self.assertIn("business_reports", operations_tables)

    def test_orphan_rows_are_quarantined(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            database_path = os.path.join(temp_dir, "legacy.db")
            with sqlite3.connect(database_path) as connection:
                connection.execute(
                    "CREATE TABLE users(id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, password TEXT NOT NULL)"
                )
                connection.execute(
                    """
                    CREATE TABLE hospital_notifications(
                        id INTEGER PRIMARY KEY, hospital_id INTEGER, user_id INTEGER,
                        title TEXT NOT NULL, content TEXT NOT NULL, status TEXT,
                        created_at TEXT NOT NULL, created_by INTEGER
                    )
                    """
                )
                connection.execute(
                    """
                    INSERT INTO hospital_notifications(
                        id, user_id, title, content, status, created_at
                    ) VALUES (1, 999, 'orphan', 'content', 'unread', '2026-07-23')
                    """
                )

            ensure_schema(database_path)
            with sqlite3.connect(database_path) as connection:
                orphan_count = connection.execute(
                    "SELECT COUNT(*) FROM hospital_notifications WHERE id = 1"
                ).fetchone()[0]
                quarantine_count = connection.execute(
                    "SELECT COUNT(*) FROM data_integrity_quarantine WHERE source_table = 'hospital_notifications'"
                ).fetchone()[0]
            self.assertEqual(orphan_count, 0)
            self.assertEqual(quarantine_count, 1)


if __name__ == "__main__":
    unittest.main()
