import unittest
from types import SimpleNamespace

from access_control import can_access_hospital_profile


class HospitalProfileAccessTest(unittest.TestCase):
    def test_regular_members_and_admins_can_view_public_profiles(self):
        member = SimpleNamespace(
            is_admin=False,
            role="user",
            approval_status="approved",
            hospital_id=None,
        )
        admin = SimpleNamespace(is_admin=True, role="admin")
        self.assertTrue(can_access_hospital_profile(member, 12))
        self.assertTrue(can_access_hospital_profile(admin, 12))

    def test_hospital_accounts_are_limited_to_their_approved_hospital(self):
        hospital = SimpleNamespace(
            is_admin=False,
            role="hospital",
            approval_status="approved",
            hospital_id=12,
        )
        pending = SimpleNamespace(
            is_admin=False,
            role="hospital",
            approval_status="pending",
            hospital_id=12,
        )
        self.assertTrue(can_access_hospital_profile(hospital, 12))
        self.assertFalse(can_access_hospital_profile(hospital, 13))
        self.assertFalse(can_access_hospital_profile(pending, 12))


if __name__ == "__main__":
    unittest.main()
