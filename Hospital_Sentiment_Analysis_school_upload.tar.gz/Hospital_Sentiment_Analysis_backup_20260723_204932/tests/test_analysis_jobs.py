import json
import os
import tempfile
import time
import unittest

from flask import Flask

from analysis_job_service import AnalysisJobService
from database import connect_database
from db_schema import ensure_schema


class AnalysisJobServiceTest(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.database_path = os.path.join(self.temp_dir.name, "jobs.db")
        ensure_schema(self.database_path)
        with connect_database(self.database_path) as connection:
            cursor = connection.execute(
                """
                INSERT INTO users(username, password, role, approval_status)
                VALUES ('worker-user', 'unused', 'user', 'approved')
                """
            )
            self.user_id = cursor.lastrowid
            connection.commit()

        self.app = Flask(__name__)
        self.app.config.update(
            BACKGROUND_ANALYSIS_WORKERS=1,
            ANALYSIS_JOB_RETENTION_HOURS=24,
        )
        self.service = None

    def tearDown(self):
        if self.service:
            self.service.executor.shutdown(wait=True, cancel_futures=True)
        self.temp_dir.cleanup()

    def _wait_for_terminal_status(self, public_id):
        deadline = time.time() + 2
        while time.time() < deadline:
            job = self.service.get(public_id, self.user_id)
            if job["status"] in {"succeeded", "failed", "cancelled"}:
                return job
            time.sleep(0.02)
        self.fail("analysis job did not complete")

    def test_successful_job_persists_result(self):
        def callback(user_id, hospital_name):
            return {
                "status": "success",
                "hospital": hospital_name,
                "requested_by": user_id,
            }, 200

        self.service = AnalysisJobService(self.app, self.database_path, callback)
        public_id = self.service.create(self.user_id, "測試醫院")
        job = self._wait_for_terminal_status(public_id)
        self.assertEqual(job["status"], "succeeded")
        payload = json.loads(job["result_json"])
        self.assertEqual(payload["hospital"], "測試醫院")
        self.assertEqual(payload["requested_by"], self.user_id)

    def test_failed_job_keeps_safe_error_message(self):
        def callback(_user_id, _hospital_name):
            return {"status": "error", "message": "資料暫時無法取得"}, 200

        self.service = AnalysisJobService(self.app, self.database_path, callback)
        public_id = self.service.create(self.user_id, "測試診所")
        job = self._wait_for_terminal_status(public_id)
        self.assertEqual(job["status"], "failed")
        self.assertEqual(job["error_message"], "資料暫時無法取得")
        self.assertIsNone(job["result_json"])

    def test_startup_marks_interrupted_jobs_failed(self):
        with connect_database(self.database_path) as connection:
            connection.execute(
                """
                INSERT INTO analysis_jobs(
                    public_id, user_id, hospital_name, status,
                    created_at, expires_at
                ) VALUES ('interrupted', ?, '測試醫院', 'running', ?, ?)
                """,
                (self.user_id, "2026-01-01 00:00:00", "2099-01-01 00:00:00"),
            )
            connection.commit()

        self.service = AnalysisJobService(
            self.app,
            self.database_path,
            lambda _user_id, _hospital_name: ({"status": "success"}, 200),
        )
        job = self.service.get("interrupted", self.user_id)
        self.assertEqual(job["status"], "failed")
        self.assertIn("重新啟動", job["error_message"])


if __name__ == "__main__":
    unittest.main()
