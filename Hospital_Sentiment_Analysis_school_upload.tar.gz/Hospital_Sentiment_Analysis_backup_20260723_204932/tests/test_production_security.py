import unittest

from flask import Flask

from production_security import register_security_controls


class ProductionSecurityTest(unittest.TestCase):
    def setUp(self):
        self.app = Flask(__name__)
        self.app.config.update(TRUST_PROXY=False, IS_PRODUCTION=False)

        @self.app.get("/probe")
        def probe():
            return "ok"

        register_security_controls(self.app)
        self.client = self.app.test_client()

    def test_security_headers_are_added(self):
        response = self.client.get("/probe")
        self.assertEqual(response.headers["X-Content-Type-Options"], "nosniff")
        self.assertEqual(response.headers["X-Frame-Options"], "DENY")
        self.assertIn("frame-ancestors 'none'", response.headers["Content-Security-Policy"])

    def test_legacy_public_proof_path_is_blocked(self):
        response = self.client.get("/static/uploads/proofs/private.pdf")
        self.assertEqual(response.status_code, 404)


if __name__ == "__main__":
    unittest.main()
