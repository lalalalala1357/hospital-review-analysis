import os
import tempfile
import unittest

from flask import Flask
from flask_bcrypt import Bcrypt
from flask_login import LoginManager
from flask_wtf.csrf import CSRFProtect

from auth_routes import register_auth_routes
from database import connect_database
from db_schema import ensure_schema


class _NoopLimiter:
    def limit(self, _value):
        return lambda function: function


class AuthLifecycleTest(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.database_path = os.path.join(self.temp_dir.name, "auth.db")
        self.upload_folder = os.path.join(self.temp_dir.name, "proofs")
        os.makedirs(self.upload_folder)
        ensure_schema(self.database_path)

        self.app = Flask(__name__, template_folder="../templates", static_folder="../static")
        self.app.config.update(
            TESTING=True,
            SECRET_KEY="test-secret-key-that-is-long-enough",
            WTF_CSRF_ENABLED=False,
            EMAIL_VERIFICATION_REQUIRED=False,
            SMTP_HOST="",
            MAIL_FROM="",
            PUBLIC_BASE_URL="http://localhost",
        )
        self.app.secret_key = self.app.config["SECRET_KEY"]
        CSRFProtect(self.app)
        self.bcrypt = Bcrypt(self.app)
        self.login_manager = LoginManager(self.app)

        admin_password = self.bcrypt.generate_password_hash(
            "Admin-Strong-Password-123!"
        ).decode("utf-8")
        with connect_database(self.database_path) as connection:
            connection.execute(
                """
                INSERT INTO users(
                    username, password, is_admin, role, approval_status,
                    terms_accepted_at, privacy_accepted_at, terms_version
                ) VALUES ('admin', ?, 1, 'admin', 'approved', ?, ?, 'test')
                """,
                (admin_password, "2026-01-01 00:00:00", "2026-01-01 00:00:00"),
            )
            connection.commit()

        self._add_stub_routes()
        register_auth_routes(
            self.app,
            bcrypt=self.bcrypt,
            login_manager=self.login_manager,
            limiter=_NoopLimiter(),
            database_path=self.database_path,
            hospital_names=["測試醫院"],
            upload_folder=self.upload_folder,
        )
        self.client = self.app.test_client()

    def tearDown(self):
        self.temp_dir.cleanup()

    def _add_stub_routes(self):
        for endpoint, path in {
            "index": "/index",
            "admin_page": "/admin",
            "hospital_application_status": "/hospital/status",
            "hospital_dashboard": "/hospital/dashboard",
            "get_captcha": "/captcha",
            "google_page": "/google",
            "region": "/region",
            "symptom_checker": "/symptom-checker",
            "pk_page": "/pk",
            "ranking_page": "/ranking",
            "favorites_page": "/favorites",
        }.items():
            self.app.add_url_rule(
                path,
                endpoint,
                lambda endpoint=endpoint: endpoint,
            )

    def _register_user(self, **overrides):
        payload = {
            "username": "member01",
            "email": "member@example.com",
            "password": "Strong-Password-123!",
            "password_confirmation": "Strong-Password-123!",
            "account_type": "user",
            "accept_terms": "1",
            "accept_privacy": "1",
        }
        payload.update(overrides)
        return self.client.post("/register", data=payload)

    def _login(self, password="Strong-Password-123!"):
        with self.client.session_transaction() as flask_session:
            flask_session["captcha_code"] = "ABCD"
        return self.client.post(
            "/login",
            data={
                "username": "member01",
                "password": password,
                "captcha": "ABCD",
            },
        )

    def test_registration_requires_policy_consent_and_email(self):
        response = self._register_user(accept_terms="", accept_privacy="")
        self.assertEqual(response.status_code, 302)
        with connect_database(self.database_path) as connection:
            count = connection.execute(
                "SELECT COUNT(*) FROM users WHERE username = 'member01'"
            ).fetchone()[0]
        self.assertEqual(count, 0)

        response = self._register_user()
        self.assertEqual(response.status_code, 302)
        with connect_database(self.database_path, rows=True) as connection:
            user = connection.execute(
                "SELECT * FROM users WHERE username = 'member01'"
            ).fetchone()
        self.assertEqual(user["email"], "member@example.com")
        self.assertIsNotNone(user["email_verified_at"])
        self.assertIsNotNone(user["terms_accepted_at"])
        self.assertIsNotNone(user["privacy_accepted_at"])

    def test_password_change_rotates_session_version(self):
        self._register_user()
        login_response = self._login()
        self.assertEqual(login_response.status_code, 302)
        with connect_database(self.database_path) as connection:
            before = connection.execute(
                "SELECT session_version FROM users WHERE username = 'member01'"
            ).fetchone()[0]

        response = self.client.post(
            "/account/password",
            data={
                "current_password": "Strong-Password-123!",
                "new_password": "New-Strong-Password-456!",
                "password_confirmation": "New-Strong-Password-456!",
            },
        )
        self.assertEqual(response.status_code, 302)
        with connect_database(self.database_path, rows=True) as connection:
            user = connection.execute(
                "SELECT password, session_version FROM users WHERE username = 'member01'"
            ).fetchone()
        self.assertGreater(user["session_version"], before)
        self.assertTrue(
            self.bcrypt.check_password_hash(user["password"], "New-Strong-Password-456!")
        )

    def test_forgot_password_stores_only_hashed_token(self):
        self._register_user()
        response = self.client.post(
            "/forgot-password", data={"email": "member@example.com"}
        )
        self.assertEqual(response.status_code, 302)
        with connect_database(self.database_path, rows=True) as connection:
            token = connection.execute(
                "SELECT * FROM password_reset_tokens ORDER BY id DESC LIMIT 1"
            ).fetchone()
        self.assertEqual(len(token["token_hash"]), 64)
        self.assertNotIn("member@example.com", token["token_hash"])
        self.assertIsNone(token["used_at"])

    def test_logout_others_keeps_current_session_version_in_sync(self):
        self._register_user()
        self._login()
        response = self.client.post("/account/logout-others")
        self.assertEqual(response.status_code, 302)
        with self.client.session_transaction() as flask_session:
            session_version = flask_session["session_version"]
        with connect_database(self.database_path) as connection:
            stored_version = connection.execute(
                "SELECT session_version FROM users WHERE username = 'member01'"
            ).fetchone()[0]
        self.assertEqual(session_version, stored_version)

    def test_production_email_gate_includes_existing_accounts_without_email(self):
        self._register_user()
        with connect_database(self.database_path) as connection:
            connection.execute(
                "UPDATE users SET email = NULL, email_verified_at = NULL WHERE username = 'member01'"
            )
            connection.commit()
        self.app.config["EMAIL_VERIFICATION_REQUIRED"] = True

        login_response = self._login()
        self.assertEqual(login_response.status_code, 302)
        self.assertTrue(
            login_response.headers["Location"].endswith("/account/verification-required")
        )

        blocked_response = self.client.get("/index")
        self.assertEqual(blocked_response.status_code, 302)
        self.assertTrue(
            blocked_response.headers["Location"].endswith("/account/verification-required")
        )
        self.assertEqual(self.client.get("/account").status_code, 200)


if __name__ == "__main__":
    unittest.main()
