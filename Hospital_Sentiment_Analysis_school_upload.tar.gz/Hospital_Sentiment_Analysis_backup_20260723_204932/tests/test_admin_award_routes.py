import unittest

from flask import Flask

from admin_award_routes import register_admin_award_routes


class AdminAwardRouteContractTest(unittest.TestCase):
    def test_legacy_admin_award_endpoints_are_preserved(self):
        app = Flask(__name__)
        register_admin_award_routes(
            app,
            database_path='unused.db',
            normalize_hospital_name=lambda name: name,
            log_award_application_history=lambda *args: None,
        )

        actual = {
            rule.endpoint: (rule.rule, frozenset(rule.methods - {'HEAD', 'OPTIONS'}))
            for rule in app.url_map.iter_rules()
            if rule.endpoint != 'static'
        }
        self.assertEqual(actual, {
            'add_award': ('/admin/add_award', frozenset({'POST'})),
            'review_award_application': (
                '/admin/award_application/<int:application_id>/<action>',
                frozenset({'POST'}),
            ),
            'delete_award': (
                '/admin/delete_award/<int:award_id>',
                frozenset({'POST'}),
            ),
        })


if __name__ == '__main__':
    unittest.main()
