import unittest

from flask import Flask

from sentiment_audit import (
    calculate_sentiment_audit_metrics,
    normalize_binary_sentiment,
    register_sentiment_audit_routes,
)


class SentimentAuditTest(unittest.TestCase):
    def test_sentiment_aliases_are_normalized(self):
        self.assertEqual(normalize_binary_sentiment('正向'), 'POSITIVE')
        self.assertEqual(normalize_binary_sentiment('負評'), 'NEGATIVE')
        self.assertIsNone(normalize_binary_sentiment('中立'))

    def test_metrics_keep_binary_confusion_matrix_contract(self):
        items = [
            {'manual_sentiment': 'POSITIVE', 'model_sentiment': 'POSITIVE'},
            {'manual_sentiment': 'POSITIVE', 'model_sentiment': 'NEGATIVE'},
            {'manual_sentiment': 'NEGATIVE', 'model_sentiment': 'POSITIVE'},
            {'manual_sentiment': 'NEGATIVE', 'model_sentiment': 'NEGATIVE'},
        ]

        metrics = calculate_sentiment_audit_metrics(items)

        self.assertEqual(metrics['total'], 4)
        self.assertEqual(metrics['correct'], 2)
        self.assertEqual(metrics['accuracy'], 0.5)
        self.assertEqual(
            (metrics['tp'], metrics['fn'], metrics['fp'], metrics['tn']),
            (1, 1, 1, 1),
        )

    def test_route_contract_is_preserved(self):
        app = Flask(__name__)
        register_sentiment_audit_routes(app, 'unused.db')

        actual = {
            rule.endpoint: (rule.rule, frozenset(rule.methods - {'HEAD', 'OPTIONS'}))
            for rule in app.url_map.iter_rules()
            if rule.endpoint != 'static'
        }
        self.assertEqual(actual, {
            'sentiment_audit_list': ('/sentiment_audit', frozenset({'GET'})),
            'create_sentiment_audit_batch': (
                '/api/sentiment_audit/create',
                frozenset({'POST'}),
            ),
            'sentiment_audit_detail': (
                '/sentiment_audit/<int:batch_id>',
                frozenset({'GET'}),
            ),
            'submit_sentiment_audit_batch': (
                '/api/sentiment_audit/<int:batch_id>/submit',
                frozenset({'POST'}),
            ),
        })


if __name__ == '__main__':
    unittest.main()
