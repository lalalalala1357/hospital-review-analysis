import os
import unittest
from unittest.mock import patch

from security_utils import (
    WEAK_SECRET_VALUES,
    clean_ai_html_output,
    require_strong_env_value,
    sanitize_ai_style,
    validate_password,
    validate_username,
)


class SecurityUtilsTest(unittest.TestCase):
    def test_require_strong_env_value_rejects_missing_weak_and_short_values(self):
        with patch.dict(os.environ, {}, clear=True):
            with self.assertRaises(RuntimeError):
                require_strong_env_value("FLASK_SECRET_KEY", WEAK_SECRET_VALUES, min_length=32)

        with patch.dict(os.environ, {"FLASK_SECRET_KEY": "change-this-during-demo"}, clear=True):
            with self.assertRaises(RuntimeError):
                require_strong_env_value("FLASK_SECRET_KEY", WEAK_SECRET_VALUES, min_length=32)

        with patch.dict(os.environ, {"FLASK_SECRET_KEY": "short-secret"}, clear=True):
            with self.assertRaises(RuntimeError):
                require_strong_env_value("FLASK_SECRET_KEY", WEAK_SECRET_VALUES, min_length=32)

    def test_require_strong_env_value_accepts_strong_value(self):
        value = "x" * 32
        with patch.dict(os.environ, {"FLASK_SECRET_KEY": value}, clear=True):
            self.assertEqual(
                require_strong_env_value("FLASK_SECRET_KEY", WEAK_SECRET_VALUES, min_length=32),
                value,
            )

    def test_sanitize_ai_style_keeps_only_safe_properties(self):
        cleaned = sanitize_ai_style("color: red; position: fixed; border-left: 5px solid #17a2b8")
        self.assertIn("color: red", cleaned)
        self.assertIn("border-left: 5px solid #17a2b8", cleaned)
        self.assertNotIn("position", cleaned)

    def test_sanitize_ai_style_rejects_active_content(self):
        self.assertEqual(sanitize_ai_style("background-image: url(javascript:alert(1)); color: red"), "")

    def test_clean_ai_html_output_strips_scripts_events_and_unknown_tags(self):
        dirty = (
            "```html"
            "<div class=\"ok\" onclick=\"alert(1)\" style=\"color: red; position: fixed\">"
            "Hello <script>alert(1)</script><img src=x onerror=\"alert(2)\"><strong>World</strong>"
            "</div>```"
        )
        cleaned = clean_ai_html_output(dirty)
        self.assertIn("<div class=\"ok\" style=\"color: red\">", cleaned)
        self.assertIn("Hello", cleaned)
        self.assertIn("<strong>World</strong>", cleaned)
        self.assertNotIn("script", cleaned.lower())
        self.assertNotIn("onclick", cleaned.lower())
        self.assertNotIn("onerror", cleaned.lower())
        self.assertNotIn("<img", cleaned.lower())
        self.assertNotIn("position", cleaned.lower())

    def test_clean_ai_html_output_escapes_text_content(self):
        cleaned = clean_ai_html_output("<p>1 < 2 & 3 > 2</p>")
        self.assertEqual(cleaned, "<p>1 &lt; 2 &amp; 3 &gt; 2</p>")

    def test_username_validation(self):
        self.assertIsNone(validate_username("hospital.admin"))
        self.assertIsNotNone(validate_username("ab"))
        self.assertIsNotNone(validate_username("bad account"))

    def test_password_validation(self):
        self.assertIsNone(validate_password("Strong!Password2026", "operator"))
        self.assertIsNotNone(validate_password("short", "operator"))
        self.assertIsNotNone(validate_password("operator!Password2026", "operator"))


if __name__ == "__main__":
    unittest.main()
