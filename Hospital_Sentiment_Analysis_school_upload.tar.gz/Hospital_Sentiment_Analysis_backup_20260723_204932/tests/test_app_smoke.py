import os
import subprocess
import sys
import tempfile
import textwrap
import unittest
from pathlib import Path


class AppSmokeTest(unittest.TestCase):
    def test_app_imports_routes_and_health_checks_with_isolated_database(self):
        project_root = Path(__file__).resolve().parents[1]
        with tempfile.TemporaryDirectory() as temp_dir:
            environment = os.environ.copy()
            environment.update({
                'APP_ENV': 'testing',
                'DATABASE_PATH': str(Path(temp_dir) / 'smoke.db'),
                'FLASK_SECRET_KEY': 'smoke-test-secret-key-with-at-least-32-characters',
                'DEFAULT_ADMIN_PASSWORD': 'Smoke-Test-Admin-Password-123!',
                'RATELIMIT_STORAGE_URI': 'memory://',
                'EMAIL_VERIFICATION_REQUIRED': '0',
                'ENABLE_BATCH_SCHEDULER': '0',
                'ENABLE_OPERATIONS_SCHEDULER': '0',
            })
            script = textwrap.dedent("""
                from app import app

                endpoints = {rule.endpoint for rule in app.url_map.iter_rules()}
                required = {
                    'hospital_profile',
                    'hospital_report',
                    'favorites_page',
                    'sentiment_audit_list',
                    'admin_log_view',
                    'get_hospital_reviews',
                    'update_user_role',
                    'review_award_application',
                }
                missing = required - endpoints
                assert not missing, sorted(missing)

                client = app.test_client()
                assert client.get('/health/live').status_code == 200
                assert client.get('/health/ready').status_code == 200
                assert client.get('/login').status_code == 200
                response = client.get('/index', follow_redirects=False)
                assert response.status_code == 302
                assert '/login' in response.headers['Location']
            """)

            result = subprocess.run(
                [sys.executable, '-c', script],
                cwd=project_root,
                env=environment,
                capture_output=True,
                text=True,
                timeout=45,
            )

        self.assertEqual(
            result.returncode,
            0,
            msg=f"stdout:\n{result.stdout}\nstderr:\n{result.stderr}",
        )


if __name__ == '__main__':
    unittest.main()
