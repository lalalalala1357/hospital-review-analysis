import os
import sqlite3
import tempfile
import unittest
from datetime import date, datetime, timedelta

from business_intelligence import (
    build_operations_dashboard,
    create_business_report,
    get_business_report,
    process_due_reports,
    save_report_schedule,
)
from db_schema import ensure_schema


class BusinessIntelligenceTest(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.database_path = os.path.join(self.temp_dir.name, "operations.db")
        ensure_schema(self.database_path)
        with sqlite3.connect(self.database_path) as connection:
            connection.executemany(
                "INSERT INTO hospitals(id, name, address, created_at) VALUES (?, ?, ?, ?)",
                [
                    (1, "測試醫院", "台北市中正區測試路1號", "2026-01-01"),
                    (2, "同區醫院", "台北市中正區比較路2號", "2026-01-01"),
                ],
            )
            connection.execute(
                """
                INSERT INTO users(
                    id, username, password, role, hospital_id, approval_status
                ) VALUES (1, 'hospital-user', 'hash', 'hospital', 1, 'approved')
                """
            )
            reviews = [
                (1, 1, "醫師說明清楚", 5, "2026-07-20", "POSITIVE", "2026-07-20 10:00:00", "門診"),
                (2, 1, "候診等太久，態度也不好", 1, "2026-07-21", "NEGATIVE", "2026-07-21 10:00:00", "門診"),
                (3, 1, "上個月服務很好", 4, "2026-06-20", "POSITIVE", "2026-06-20 10:00:00", "門診"),
                (4, 2, "服務很好", 5, "2026-07-18", "POSITIVE", "2026-07-18 10:00:00", "急診"),
                (5, 2, "說明清楚", 5, "2026-07-19", "POSITIVE", "2026-07-19 10:00:00", "急診"),
                (6, 2, "環境整潔", 4, "2026-07-20", "POSITIVE", "2026-07-20 10:00:00", "急診"),
            ]
            connection.executemany(
                """
                INSERT INTO reviews(
                    id, hospital_id, content, rating, review_time,
                    analyzed_sentiment, stored_at, department
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                reviews,
            )

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_dashboard_compares_periods_and_anonymizes_peer_benchmarks(self):
        dashboard = build_operations_dashboard(
            self.database_path, 1, 30, today=date(2026, 7, 23)
        )

        self.assertEqual(dashboard["metrics"]["total"], 2)
        self.assertEqual(dashboard["metrics"]["positive_rate"], 50.0)
        self.assertEqual(dashboard["previous_metrics"]["positive_rate"], 100.0)
        self.assertEqual(dashboard["deltas"]["positive_rate"], -50.0)
        self.assertEqual(dashboard["issues"][0]["name"], "等待時間")
        self.assertEqual(dashboard["competition"]["scope"], "台北市")
        self.assertEqual(dashboard["competition"]["peer_count"], 1)
        positive_benchmark = dashboard["competition"]["benchmarks"][0]
        self.assertEqual(positive_benchmark["hospital_value"], 50.0)
        self.assertEqual(positive_benchmark["peer_average"], 100.0)
        self.assertNotIn("rows", dashboard["competition"])
        self.assertEqual(len(dashboard["recent_negative_reviews"]), 1)
        self.assertEqual(
            dashboard["recent_negative_reviews"][0]["issue"], "等待時間"
        )

    def test_manual_and_due_reports_create_snapshots(self):
        report_id = create_business_report(
            self.database_path, 1, 30, created_by=1
        )
        report = get_business_report(self.database_path, report_id, 1)
        self.assertEqual(report["payload"]["hospital"]["name"], "測試醫院")
        self.assertIsNone(get_business_report(self.database_path, report_id, 2))

        save_report_schedule(
            self.database_path,
            1,
            enabled=True,
            frequency="weekly",
            report_day=1,
            period_days=30,
        )
        due_at = (datetime.now() - timedelta(minutes=1)).strftime(
            "%Y-%m-%d %H:%M:%S"
        )
        with sqlite3.connect(self.database_path) as connection:
            connection.execute(
                "UPDATE business_report_schedules SET next_run_at = ? WHERE hospital_id = 1",
                (due_at,),
            )

        self.assertEqual(process_due_reports(self.database_path), 1)
        self.assertEqual(process_due_reports(self.database_path), 0)
        with sqlite3.connect(self.database_path) as connection:
            scheduled_count = connection.execute(
                "SELECT COUNT(*) FROM business_reports WHERE source = 'scheduled'"
            ).fetchone()[0]
            notification_count = connection.execute(
                "SELECT COUNT(*) FROM hospital_notifications WHERE category = 'business_report'"
            ).fetchone()[0]
        self.assertEqual(scheduled_count, 1)
        self.assertEqual(notification_count, 1)


if __name__ == "__main__":
    unittest.main()
