import os
import sqlite3
import tempfile
import unittest

from database import create_consistent_backup, database_health, remove_file_quietly


class DatabaseTest(unittest.TestCase):
    def test_consistent_backup_contains_committed_data(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            source_path = os.path.join(temp_dir, "source.db")
            with sqlite3.connect(source_path) as connection:
                connection.execute("CREATE TABLE sample(id INTEGER PRIMARY KEY, value TEXT)")
                connection.execute("INSERT INTO sample(value) VALUES ('ready')")

            backup_path = create_consistent_backup(source_path, temp_dir)
            try:
                with sqlite3.connect(backup_path) as connection:
                    value = connection.execute("SELECT value FROM sample").fetchone()[0]
                self.assertEqual(value, "ready")
                self.assertTrue(database_health(backup_path)[0])
            finally:
                remove_file_quietly(backup_path)


if __name__ == "__main__":
    unittest.main()
