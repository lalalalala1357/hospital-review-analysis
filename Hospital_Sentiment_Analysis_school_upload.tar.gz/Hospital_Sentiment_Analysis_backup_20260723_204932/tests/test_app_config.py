import unittest

from flask import Flask, request
from flask_wtf.csrf import CSRFProtect, generate_csrf

from app_config import configure_app, env_flag, env_int


class AppConfigTest(unittest.TestCase):
    def test_env_flag_truthy_values(self):
        for value in ["1", "true", "TRUE", "yes", "on", "enabled"]:
            with self.subTest(value=value):
                self.assertTrue(env_flag("FLAG", environ={"FLAG": value}))

    def test_env_flag_falsey_values(self):
        for value in ["0", "false", "FALSE", "no", "off", "disabled", ""]:
            with self.subTest(value=value):
                self.assertFalse(env_flag("FLAG", default=True, environ={"FLAG": value}))

    def test_env_flag_uses_default_for_missing_or_unknown_values(self):
        self.assertTrue(env_flag("FLAG", default=True, environ={}))
        self.assertFalse(env_flag("FLAG", default=False, environ={"FLAG": "maybe"}))

    def test_env_int_uses_bounds_and_default(self):
        self.assertEqual(env_int("PORT", 5007, 1, 65535, {"PORT": "70000"}), 65535)
        self.assertEqual(env_int("PORT", 5007, environ={"PORT": "invalid"}), 5007)

    def test_development_config_is_runnable_locally(self):
        app = Flask(__name__)
        configure_app(app, "/tmp/project", environ={"APP_ENV": "development"})
        self.assertFalse(app.config["SESSION_COOKIE_SECURE"])
        self.assertEqual(app.config["ENVIRONMENT"], "development")
        self.assertEqual(app.config["RATELIMIT_STORAGE_URI"], "memory://")
        self.assertEqual(app.config["WTF_CSRF_TIME_LIMIT"], 7200)
        self.assertIsInstance(app.config["WTF_CSRF_TIME_LIMIT"], int)

    def test_csrf_time_limit_accepts_a_valid_post_token(self):
        app = Flask(__name__)
        app.config["SECRET_KEY"] = "csrf-regression-test-secret"
        configure_app(app, "/tmp/project", environ={"APP_ENV": "testing"})
        CSRFProtect(app)

        @app.route("/csrf-check", methods=["GET", "POST"])
        def csrf_check():
            return generate_csrf() if request.method == "GET" else "ok"

        client = app.test_client()
        token = client.get("/csrf-check").get_data(as_text=True)
        response = client.post("/csrf-check", data={"csrf_token": token})

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.get_data(as_text=True), "ok")

    def test_production_rejects_in_memory_rate_limit_storage(self):
        app = Flask(__name__)
        with self.assertRaises(RuntimeError):
            configure_app(
                app,
                "/tmp/project",
                environ={
                    "APP_ENV": "production",
                    "SESSION_COOKIE_SECURE": "1",
                    "RATELIMIT_STORAGE_URI": "memory://",
                },
            )


if __name__ == "__main__":
    unittest.main()
