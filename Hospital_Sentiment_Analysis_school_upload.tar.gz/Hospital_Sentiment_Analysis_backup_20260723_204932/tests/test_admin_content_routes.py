import unittest

from flask import Flask

from admin_content_routes import register_admin_content_routes


class AdminContentRouteContractTest(unittest.TestCase):
    def test_legacy_admin_content_endpoints_are_preserved(self):
        app = Flask(__name__)
        register_admin_content_routes(
            app,
            database_path='unused.db',
            log_backup_history=lambda file_name, file_size: None,
        )

        actual = {
            rule.endpoint: (rule.rule, frozenset(rule.methods - {'HEAD', 'OPTIONS'}))
            for rule in app.url_map.iter_rules()
            if rule.endpoint != 'static'
        }
        self.assertEqual(actual, {
            'admin_log_view': ('/admin/log_view', frozenset({'POST'})),
            'backup_db': ('/admin/backup', frozenset({'POST'})),
            'add_stop_word': ('/admin/add_stop_word', frozenset({'POST'})),
            'delete_stop_word': (
                '/admin/delete_stop_word/<int:word_id>',
                frozenset({'POST'}),
            ),
            'delete_symptom': ('/admin/delete_symptom', frozenset({'POST'})),
            'add_announcement': ('/admin/add_announcement', frozenset({'POST'})),
            'toggle_announcement': (
                '/admin/toggle_announcement/<int:ann_id>',
                frozenset({'POST'}),
            ),
            'delete_announcement': (
                '/admin/delete_announcement/<int:ann_id>',
                frozenset({'POST'}),
            ),
        })


if __name__ == '__main__':
    unittest.main()
