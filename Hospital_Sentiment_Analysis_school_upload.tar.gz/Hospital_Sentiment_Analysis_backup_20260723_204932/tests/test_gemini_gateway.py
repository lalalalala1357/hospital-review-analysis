import unittest

from gemini_gateway import GeminiGateway


class FakeResponse:
    text = "ok"


class FakeModels:
    def __init__(self):
        self.calls = []

    def generate_content(self, **kwargs):
        self.calls.append(kwargs)
        return FakeResponse()

    def list(self):
        return [
            type(
                "Model",
                (),
                {
                    "name": "models/gemini-test",
                    "supported_actions": ["generateContent"],
                },
            )()
        ]


class FakeFiles:
    def __init__(self):
        self.deleted = []

    def upload(self, file):
        return type("UploadedFile", (), {"name": "files/test"})()

    def delete(self, name):
        self.deleted.append(name)


class FakeClient:
    def __init__(self):
        self.models = FakeModels()
        self.files = FakeFiles()


class GeminiGatewayTest(unittest.TestCase):
    def setUp(self):
        self.client = FakeClient()
        self.gateway = GeminiGateway(
            "test-key",
            backend="google-genai",
            new_client_factory=lambda timeout: self.client,
        )

    def test_generate_content_uses_model_and_prompt(self):
        response = self.gateway.generate_content("gemini-test", "hello", 30)
        self.assertEqual(response.text, "ok")
        self.assertEqual(
            self.client.models.calls[0],
            {"model": "gemini-test", "contents": "hello"},
        )

    def test_uploaded_file_is_deleted_after_generation(self):
        response = self.gateway.generate_from_file(
            "gemini-test", "/tmp/proof.pdf", "read it", 30
        )
        self.assertEqual(response.text, "ok")
        self.assertEqual(self.client.files.deleted, ["files/test"])

    def test_list_model_names_filters_generate_models(self):
        self.assertEqual(self.gateway.list_model_names(), ["models/gemini-test"])


if __name__ == "__main__":
    unittest.main()
