import unittest

from flask import Flask

from admin_user_routes import register_admin_user_routes


class AdminUserRouteContractTest(unittest.TestCase):
    def test_legacy_admin_user_endpoints_are_preserved(self):
        app = Flask(__name__)
        register_admin_user_routes(
            app,
            database_path='unused.db',
            bcrypt=object(),
            upload_folder='/tmp',
        )

        actual = {
            rule.endpoint: (rule.rule, frozenset(rule.methods - {'HEAD', 'OPTIONS'}))
            for rule in app.url_map.iter_rules()
            if rule.endpoint != 'static'
        }
        self.assertEqual(actual, {
            'toggle_admin': (
                '/admin/toggle_admin/<int:user_id>',
                frozenset({'POST'}),
            ),
            'update_user_role': (
                '/admin/update_user_role/<int:user_id>',
                frozenset({'POST'}),
            ),
            'delete_user': (
                '/admin/delete_user/<int:user_id>',
                frozenset({'POST'}),
            ),
        })


if __name__ == '__main__':
    unittest.main()
