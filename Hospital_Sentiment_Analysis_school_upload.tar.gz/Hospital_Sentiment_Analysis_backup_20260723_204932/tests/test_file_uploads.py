import io
import os
import tempfile
import unittest

from werkzeug.datastructures import FileStorage

from file_uploads import is_safe_stored_filename, save_proof_document


class FileUploadsTest(unittest.TestCase):
    def test_valid_pdf_is_saved_with_private_permissions(self):
        upload = FileStorage(stream=io.BytesIO(b"%PDF-1.7\ncontent"), filename="proof.pdf")
        with tempfile.TemporaryDirectory() as temp_dir:
            filename, error = save_proof_document(upload, temp_dir)
            path = os.path.join(temp_dir, filename)
            self.assertIsNone(error)
            self.assertTrue(os.path.isfile(path))
            self.assertEqual(os.stat(path).st_mode & 0o777, 0o600)

    def test_spoofed_extension_is_rejected(self):
        upload = FileStorage(stream=io.BytesIO(b"<script>alert(1)</script>"), filename="proof.pdf")
        with tempfile.TemporaryDirectory() as temp_dir:
            filename, error = save_proof_document(upload, temp_dir)
            self.assertIsNone(filename)
            self.assertIn("不符", error)
            self.assertEqual(os.listdir(temp_dir), [])

    def test_stored_filename_blocks_traversal(self):
        self.assertTrue(is_safe_stored_filename("abc123.pdf"))
        self.assertFalse(is_safe_stored_filename("../secret.pdf"))


if __name__ == "__main__":
    unittest.main()
