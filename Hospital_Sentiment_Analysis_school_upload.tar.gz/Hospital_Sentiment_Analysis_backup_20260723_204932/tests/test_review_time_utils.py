import unittest
from datetime import datetime

from review_time_utils import (
    normalize_google_review_time,
    normalize_stored_review_time,
    parse_chinese_number,
    subtract_months,
)


class ReviewTimeUtilsTest(unittest.TestCase):
    def test_parse_chinese_number(self):
        self.assertEqual(parse_chinese_number("兩"), 2)
        self.assertEqual(parse_chinese_number("十一"), 11)
        self.assertEqual(parse_chinese_number("二十"), 20)
        self.assertEqual(parse_chinese_number("半"), 0.5)
        self.assertEqual(parse_chinese_number("3"), 3.0)

    def test_subtract_months_clamps_day(self):
        self.assertEqual(subtract_months(datetime(2026, 3, 31), 1).strftime("%Y/%m/%d"), "2026/02/28")
        self.assertEqual(subtract_months(datetime(2024, 3, 31), 1).strftime("%Y/%m/%d"), "2024/02/29")

    def test_normalize_google_review_time_relative_days(self):
        now = datetime(2026, 7, 23, 15, 30)
        self.assertEqual(normalize_google_review_time("剛剛", now), "2026/07/23")
        self.assertEqual(normalize_google_review_time("昨天", now), "2026/07/22")
        self.assertEqual(normalize_google_review_time("前天", now), "2026/07/21")
        self.assertEqual(normalize_google_review_time("兩週前", now), "2026/07/09")

    def test_normalize_google_review_time_month_and_year(self):
        now = datetime(2026, 1, 31, 9, 0)
        self.assertEqual(normalize_google_review_time("1 個月前", now), "2025/12/31")
        self.assertEqual(normalize_google_review_time("一年前", now), "2025/01/31")

    def test_normalize_stored_review_time(self):
        self.assertEqual(normalize_stored_review_time("2026-7-3"), "2026/07/03")
        self.assertEqual(
            normalize_stored_review_time("昨天", stored_at="2026-07-23 12:00:00"),
            "2026/07/22",
        )
        self.assertEqual(normalize_stored_review_time(""), "未知時間")


if __name__ == "__main__":
    unittest.main()
