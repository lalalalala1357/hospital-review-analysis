import os
import sqlite3
import tempfile
import unittest

from flask import Flask

from health_routes import register_health_routes


class HealthRoutesTest(unittest.TestCase):
    def test_readiness_checks_database_and_required_file(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            database_path = os.path.join(temp_dir, "health.db")
            required_path = os.path.join(temp_dir, "hospitals.xlsx")
            with sqlite3.connect(database_path) as connection:
                connection.execute("CREATE TABLE probe(id INTEGER)")
                connection.execute(
                    "CREATE TABLE schema_migrations(version INTEGER PRIMARY KEY)"
                )
                connection.execute("INSERT INTO schema_migrations VALUES (7)")
            with open(required_path, "wb") as required_file:
                required_file.write(b"placeholder")

            app = Flask(__name__)
            register_health_routes(
                app,
                database_path,
                [required_path],
                [temp_dir],
                expected_schema_version=7,
            )
            response = app.test_client().get("/health/ready")
            self.assertEqual(response.status_code, 200)
            self.assertEqual(response.get_json()["status"], "ready")

    def test_readiness_rejects_outdated_schema_and_email_config(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            database_path = os.path.join(temp_dir, "health.db")
            with sqlite3.connect(database_path) as connection:
                connection.execute(
                    "CREATE TABLE schema_migrations(version INTEGER PRIMARY KEY)"
                )
                connection.execute("INSERT INTO schema_migrations VALUES (6)")

            app = Flask(__name__)
            app.config["EMAIL_VERIFICATION_REQUIRED"] = True
            register_health_routes(
                app,
                database_path,
                required_writable_paths=[temp_dir],
                expected_schema_version=7,
            )
            response = app.test_client().get("/health/ready")
            payload = response.get_json()
            self.assertEqual(response.status_code, 503)
            self.assertFalse(payload["checks"]["database_schema"])
            self.assertFalse(payload["checks"]["email_delivery"])

    def test_readiness_rejects_stale_analysis_job(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            database_path = os.path.join(temp_dir, "health.db")
            with sqlite3.connect(database_path) as connection:
                connection.execute(
                    "CREATE TABLE schema_migrations(version INTEGER PRIMARY KEY)"
                )
                connection.execute("INSERT INTO schema_migrations VALUES (7)")
                connection.execute(
                    "CREATE TABLE analysis_jobs(status TEXT, started_at TEXT)"
                )
                connection.execute(
                    "INSERT INTO analysis_jobs VALUES ('running', '2000-01-01 00:00:00')"
                )

            app = Flask(__name__)
            register_health_routes(
                app,
                database_path,
                required_writable_paths=[temp_dir],
                expected_schema_version=7,
            )
            response = app.test_client().get("/health/ready")
            payload = response.get_json()
            self.assertEqual(response.status_code, 503)
            self.assertFalse(payload["checks"]["background_jobs"])
            self.assertEqual(payload["metrics"]["stale_analysis_jobs"], 1)


if __name__ == "__main__":
    unittest.main()
