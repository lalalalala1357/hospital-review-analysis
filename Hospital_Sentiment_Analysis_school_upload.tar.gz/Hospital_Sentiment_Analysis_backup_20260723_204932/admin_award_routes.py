"""Administrative award creation, review, and deletion routes."""

from datetime import datetime
import sqlite3

from flask import flash, redirect, request, url_for
from flask_login import current_user, login_required

from access_control import admin_required
from database import connect_database


def register_admin_award_routes(
    app,
    *,
    database_path,
    normalize_hospital_name,
    log_award_application_history,
):
    @app.route('/admin/add_award', methods=['POST'])
    @login_required
    @admin_required
    def add_award():
        if not current_user.is_admin:
            return redirect(url_for('index'))

        hospital_name = request.form.get('hospital_name', '').replace('臺', '台').strip()
        department = request.form.get('department', '').strip()
        award_name = request.form.get('award_name', '').strip()

        if hospital_name and department and award_name:
            try:
                with connect_database(database_path) as conn:
                    cursor = conn.cursor()
                    cursor.execute("""
                        INSERT INTO hospital_awards (hospital_name, department, award_name)
                        VALUES (?, ?, ?)
                    """, (hospital_name, department, award_name))
                    conn.commit()
                flash(f'已成功新增：{hospital_name} 的得獎紀錄！', 'analyze_success')
            except sqlite3.IntegrityError:
                flash(f'該獎項 ({hospital_name} - {award_name}) 已經存在囉！', 'analyze_error')
        else:
            flash('請填寫完整資訊！', 'analyze_error')

        return redirect(url_for('admin_page') + '#data')

    @app.route('/admin/award_application/<int:application_id>/<action>', methods=['POST'])
    @login_required
    @admin_required
    def review_award_application(application_id, action):
        if not current_user.is_admin:
            return redirect(url_for('index'))
        if action not in ['approve', 'reject']:
            flash('不支援的審核操作。', 'analyze_error')
            return redirect(url_for('admin_page') + '#data')

        admin_note = request.form.get('admin_note', '').strip()
        now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

        with connect_database(database_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute(
                'SELECT * FROM hospital_award_applications WHERE id = ?',
                (application_id,),
            )
            application = cursor.fetchone()

            if not application:
                flash('找不到這筆獎項/認證申請。', 'analyze_error')
                return redirect(url_for('admin_page') + '#data')
            if application['status'] != 'pending':
                flash('這筆申請已審核過。', 'analyze_error')
                return redirect(url_for('admin_page') + '#data')

            if action == 'approve':
                cursor.execute("""
                    INSERT OR IGNORE INTO hospital_awards (hospital_name, department, award_name)
                    VALUES (?, ?, ?)
                """, (
                    normalize_hospital_name(application['hospital_name']),
                    application['department'],
                    application['award_name'],
                ))
                cursor.execute("""
                    UPDATE hospital_award_applications
                    SET status = 'approved', admin_note = ?, reviewed_at = ?, reviewed_by = ?
                    WHERE id = ?
                """, (admin_note, now, current_user.id, application_id))
                flash('已通過申請，該獎項/認證會顯示在醫院詳細檔案中。', 'analyze_success')
                notice_title = '獎項/認證申請已通過'
                notice_content = (
                    f"您申請的「{application['department']} - {application['award_name']}」"
                    '已通過審核，將顯示在醫院詳細檔案中。'
                )
                if admin_note:
                    notice_content += f' 管理員備註：{admin_note}'
                history_action = 'approved'
                history_note = admin_note or '管理員通過申請'
            else:
                if not admin_note:
                    admin_note = '申請資料不足或需補充佐證資料'
                cursor.execute("""
                    UPDATE hospital_award_applications
                    SET status = 'rejected', admin_note = ?, reviewed_at = ?, reviewed_by = ?
                    WHERE id = ?
                """, (admin_note, now, current_user.id, application_id))
                notice_title = '獎項/認證申請已退回'
                notice_content = (
                    f"您申請的「{application['department']} - {application['award_name']}」"
                    f'已被退回。退回原因：{admin_note}。請修正後重新送出。'
                )
                history_action = 'rejected'
                history_note = admin_note
                flash('已拒絕這筆獎項/認證申請。', 'analyze_success')

            log_award_application_history(
                cursor,
                application_id,
                history_action,
                history_note,
                application['proof_document'] if 'proof_document' in application.keys() else None,
                current_user.id,
            )

            link_url = (
                url_for(
                    'hospital_profile',
                    hospital_id=application['hospital_id'],
                    _anchor=f'award-application-{application_id}',
                )
                if application['hospital_id']
                else url_for('hospital_notifications_page')
            )
            cursor.execute("""
                INSERT INTO hospital_notifications
                    (hospital_id, user_id, title, content, status, category,
                     link_url, created_at, created_by)
                VALUES (?, ?, ?, ?, 'unread', 'award', ?, ?, ?)
            """, (
                application['hospital_id'],
                application['user_id'],
                notice_title,
                notice_content,
                link_url,
                now,
                current_user.id,
            ))
            conn.commit()

        return redirect(url_for('admin_page') + '#data')

    @app.route('/admin/delete_award/<int:award_id>', methods=['POST'])
    @login_required
    @admin_required
    def delete_award(award_id):
        if not current_user.is_admin:
            return redirect(url_for('index'))

        with connect_database(database_path) as conn:
            cursor = conn.cursor()
            cursor.execute(
                'SELECT hospital_name, department, award_name FROM hospital_awards WHERE id = ?',
                (award_id,),
            )
            award = cursor.fetchone()
            cursor.execute('DELETE FROM hospital_awards WHERE id = ?', (award_id,))

            if award:
                hospital_name, department, award_name = award
                cursor.execute("""
                    DELETE FROM hospital_award_application_history
                    WHERE application_id IN (
                        SELECT id FROM hospital_award_applications
                        WHERE hospital_name = ? AND department = ? AND award_name = ?
                          AND status = 'approved'
                    )
                """, (hospital_name, department, award_name))
                cursor.execute("""
                    DELETE FROM hospital_award_applications
                    WHERE hospital_name = ? AND department = ? AND award_name = ?
                      AND status = 'approved'
                """, (hospital_name, department, award_name))
            conn.commit()

        flash('得獎紀錄與相關申請資料已徹底刪除', 'analyze_success')
        return redirect(url_for('admin_page') + '#data')
