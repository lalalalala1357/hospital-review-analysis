import html
import os
import re
from html.parser import HTMLParser

WEAK_SECRET_VALUES = {
    "",
    "change-this-during-demo",
    "dev-only-change-this-secret-key",
    "your-secret-key",
    "secret",
}

WEAK_BOOTSTRAP_PASSWORDS = {
    "123456",
    "password",
    "admin",
    "change-this-during-demo",
}

USERNAME_PATTERN = re.compile(r"^[\w.@+-]+$", re.UNICODE)

SAFE_AI_HTML_TAGS = {
    "article", "blockquote", "br", "div", "em", "h1", "h2", "h3", "h4", "h5", "h6",
    "hr", "i", "li", "ol", "p", "section", "small", "span", "strong", "table",
    "tbody", "td", "th", "thead", "tr", "ul",
}
SAFE_AI_VOID_TAGS = {"br", "hr"}
BLOCKED_AI_HTML_TAGS = {
    "base", "button", "embed", "form", "iframe", "input", "link", "meta", "object",
    "script", "select", "style", "textarea",
}
SAFE_AI_GLOBAL_ATTRS = {"class", "role", "title"}
SAFE_AI_TAG_ATTRS = {
    "td": {"colspan", "rowspan"},
    "th": {"colspan", "rowspan"},
}
SAFE_AI_STYLE_PROPERTIES = {
    "background", "background-color", "border", "border-left", "border-radius",
    "color", "display", "line-height", "margin", "margin-bottom", "margin-left",
    "margin-right", "margin-top", "padding", "padding-bottom", "padding-left",
    "padding-right", "padding-top", "text-align",
}


def require_strong_env_value(name, weak_values, min_length=16):
    value = os.getenv(name, "").strip()
    if not value or value in weak_values or len(value) < min_length:
        raise RuntimeError(
            f"請在 .env 設定安全的 {name}，長度至少 {min_length} 字元，且不要使用範例值。"
        )
    return value


def validate_username(username):
    value = str(username or "").strip()
    if not 3 <= len(value) <= 64:
        return "帳號長度必須介於 3 到 64 個字元。"
    if not USERNAME_PATTERN.fullmatch(value):
        return "帳號只能包含文字、數字、底線、句點、@、+ 或 -。"
    return None


def validate_password(password, username=""):
    value = str(password or "")
    if len(value) < 12:
        return "密碼至少需要 12 個字元。"
    if len(value) > 128:
        return "密碼不可超過 128 個字元。"
    if value.lower() in WEAK_BOOTSTRAP_PASSWORDS:
        return "這組密碼太常見，請改用不重複的密碼。"
    if username and str(username).lower() in value.lower():
        return "密碼不可包含完整帳號。"

    character_groups = sum(
        bool(pattern.search(value))
        for pattern in (
            re.compile(r"[a-z]"),
            re.compile(r"[A-Z]"),
            re.compile(r"\d"),
            re.compile(r"[^\w\s]", re.UNICODE),
        )
    )
    if character_groups < 3:
        return "密碼需混合英文大小寫、數字或符號中的至少三類。"
    return None


def sanitize_ai_style(style_text):
    style_text = str(style_text or "")
    if re.search(r"(url\s*\(|expression\s*\(|javascript:|@import)", style_text, re.IGNORECASE):
        return ""

    safe_declarations = []
    for declaration in style_text.split(";"):
        if ":" not in declaration:
            continue
        property_name, value = declaration.split(":", 1)
        property_name = property_name.strip().lower()
        value = value.strip()
        if property_name not in SAFE_AI_STYLE_PROPERTIES:
            continue
        if not value or re.search(r"[<>{}]", value):
            continue
        safe_declarations.append(f"{property_name}: {value}")
    return "; ".join(safe_declarations)


class SafeAIHTMLSanitizer(HTMLParser):
    def __init__(self):
        super().__init__()
        self.parts = []
        self.skip_depth = 0

    def handle_starttag(self, tag, attrs):
        tag = tag.lower()
        if tag in BLOCKED_AI_HTML_TAGS:
            self.skip_depth += 1
            return
        if self.skip_depth or tag not in SAFE_AI_HTML_TAGS:
            return

        safe_attrs = []
        allowed_attrs = SAFE_AI_GLOBAL_ATTRS | SAFE_AI_TAG_ATTRS.get(tag, set())
        for raw_name, raw_value in attrs:
            attr_name = str(raw_name or "").lower()
            attr_value = "" if raw_value is None else str(raw_value)
            if attr_name.startswith("on"):
                continue
            if attr_name == "style":
                attr_value = sanitize_ai_style(attr_value)
                if not attr_value:
                    continue
            elif attr_name.startswith("aria-"):
                pass
            elif attr_name not in allowed_attrs:
                continue
            safe_attrs.append(f"{attr_name}=\"{html.escape(attr_value, quote=True)}\"")

        attr_text = " " + " ".join(safe_attrs) if safe_attrs else ""
        self.parts.append(f"<{tag}{attr_text}>")

    def handle_endtag(self, tag):
        tag = tag.lower()
        if tag in BLOCKED_AI_HTML_TAGS and self.skip_depth:
            self.skip_depth -= 1
            return
        if self.skip_depth or tag not in SAFE_AI_HTML_TAGS or tag in SAFE_AI_VOID_TAGS:
            return
        self.parts.append(f"</{tag}>")

    def handle_data(self, data):
        if not self.skip_depth:
            self.parts.append(html.escape(data))


def clean_ai_html_output(text):
    cleaned = str(text or "").strip()
    cleaned = re.sub(r"^```(?:html)?\s*", "", cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r"\s*```$", "", cleaned)
    sanitizer = SafeAIHTMLSanitizer()
    sanitizer.feed(cleaned.strip())
    sanitizer.close()
    return "".join(sanitizer.parts).strip()
