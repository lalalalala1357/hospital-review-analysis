import os
from datetime import timedelta


TRUTHY_VALUES = {"1", "true", "yes", "on", "enabled"}
FALSY_VALUES = {"0", "false", "no", "off", "disabled", ""}
VALID_ENVIRONMENTS = {"development", "testing", "production"}


def env_flag(name, default=False, environ=None):
    source = environ if environ is not None else os.environ
    raw_value = source.get(name)
    if raw_value is None:
        return default

    normalized = str(raw_value).strip().lower()
    if normalized in TRUTHY_VALUES:
        return True
    if normalized in FALSY_VALUES:
        return False
    return default


def env_int(name, default, minimum=None, maximum=None, environ=None):
    source = environ if environ is not None else os.environ
    raw_value = source.get(name)
    try:
        value = int(raw_value) if raw_value is not None else int(default)
    except (TypeError, ValueError):
        value = int(default)
    if minimum is not None:
        value = max(value, minimum)
    if maximum is not None:
        value = min(value, maximum)
    return value


def configure_app(app, base_dir, environ=None):
    source = environ if environ is not None else os.environ
    environment = str(source.get("APP_ENV", "development")).strip().lower()
    if environment not in VALID_ENVIRONMENTS:
        raise RuntimeError(
            f"APP_ENV 必須是 {', '.join(sorted(VALID_ENVIRONMENTS))} 其中之一。"
        )

    is_production = environment == "production"
    upload_root = source.get("PRIVATE_UPLOAD_ROOT") or os.path.join(
        base_dir, "data", "private_uploads"
    )
    rate_limit_storage = source.get("RATELIMIT_STORAGE_URI", "memory://").strip()

    app.config.update(
        ENVIRONMENT=environment,
        IS_PRODUCTION=is_production,
        MAX_CONTENT_LENGTH=env_int(
            "MAX_UPLOAD_MB", 8, minimum=1, maximum=25, environ=source
        )
        * 1024
        * 1024,
        PERMANENT_SESSION_LIFETIME=timedelta(
            hours=env_int("SESSION_LIFETIME_HOURS", 8, 1, 24 * 7, source)
        ),
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        SESSION_COOKIE_SECURE=env_flag(
            "SESSION_COOKIE_SECURE", default=is_production, environ=source
        ),
        REMEMBER_COOKIE_HTTPONLY=True,
        REMEMBER_COOKIE_SAMESITE="Lax",
        REMEMBER_COOKIE_SECURE=env_flag(
            "SESSION_COOKIE_SECURE", default=is_production, environ=source
        ),
        WTF_CSRF_SSL_STRICT=is_production,
        # Flask-WTF passes this value directly to itsdangerous as max_age,
        # which must be an integer number of seconds.
        WTF_CSRF_TIME_LIMIT=2 * 60 * 60,
        RATELIMIT_STORAGE_URI=rate_limit_storage,
        RATELIMIT_DEFAULT=source.get(
            "RATELIMIT_DEFAULT", "2000 per day;300 per hour"
        ).split(";"),
        UPLOAD_FOLDER=os.path.join(upload_root, "proofs"),
        TRUST_PROXY=env_flag("TRUST_PROXY", default=is_production, environ=source),
        PUBLIC_BASE_URL=str(source.get("PUBLIC_BASE_URL", "")).strip().rstrip("/"),
        SUPPORT_EMAIL=str(source.get("SUPPORT_EMAIL", "")).strip(),
        SMTP_HOST=str(source.get("SMTP_HOST", "")).strip(),
        SMTP_PORT=env_int("SMTP_PORT", 587, 1, 65535, source),
        SMTP_USERNAME=str(source.get("SMTP_USERNAME", "")).strip(),
        SMTP_PASSWORD=str(source.get("SMTP_PASSWORD", "")),
        SMTP_USE_TLS=env_flag("SMTP_USE_TLS", default=True, environ=source),
        SMTP_USE_SSL=env_flag("SMTP_USE_SSL", default=False, environ=source),
        MAIL_FROM=str(source.get("MAIL_FROM", "")).strip(),
        EMAIL_VERIFICATION_REQUIRED=env_flag(
            "EMAIL_VERIFICATION_REQUIRED", default=is_production, environ=source
        ),
        SYMPTOM_RETENTION_DAYS=env_int(
            "SYMPTOM_RETENTION_DAYS", 90, 7, 365, source
        ),
        ANALYSIS_JOB_RETENTION_HOURS=env_int(
            "ANALYSIS_JOB_RETENTION_HOURS", 24, 1, 168, source
        ),
        BACKGROUND_ANALYSIS_WORKERS=env_int(
            "BACKGROUND_ANALYSIS_WORKERS", 1, 1, 2, source
        ),
        ANALYSIS_JOB_STALE_MINUTES=env_int(
            "ANALYSIS_JOB_STALE_MINUTES", 30, 5, 180, source
        ),
    )

    if is_production and env_flag(
        "STRICT_PRODUCTION_CONFIG", default=True, environ=source
    ):
        errors = []
        if not app.config["SESSION_COOKIE_SECURE"]:
            errors.append("SESSION_COOKIE_SECURE 必須設為 1")
        if rate_limit_storage == "memory://":
            errors.append("RATELIMIT_STORAGE_URI 必須使用 Redis 等共享儲存")
        if app.config["EMAIL_VERIFICATION_REQUIRED"]:
            if not app.config["SMTP_HOST"]:
                errors.append("啟用 Email 驗證時必須設定 SMTP_HOST")
            if not app.config["MAIL_FROM"]:
                errors.append("啟用 Email 驗證時必須設定 MAIL_FROM")
            if not app.config["PUBLIC_BASE_URL"]:
                errors.append("啟用 Email 驗證時必須設定 PUBLIC_BASE_URL")
        if errors:
            raise RuntimeError("正式環境設定不安全：" + "；".join(errors))

    return app.config
