import json
import logging
import threading
import uuid
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta

from flask import jsonify, request, url_for
from flask_login import current_user, login_required

from database import connect_database


LOGGER = logging.getLogger(__name__)
TERMINAL_STATUSES = {"succeeded", "failed", "cancelled"}


def _timestamp(value=None):
    return (value or datetime.now()).strftime("%Y-%m-%d %H:%M:%S")


class AnalysisJobService:
    def __init__(self, app, database_path, callback):
        self.app = app
        self.database_path = database_path
        self.callback = callback
        self.executor = ThreadPoolExecutor(
            max_workers=app.config.get("BACKGROUND_ANALYSIS_WORKERS", 1),
            thread_name_prefix="hospital-analysis",
        )
        self._futures = {}
        self._future_lock = threading.Lock()
        self._recover_interrupted_jobs()

    def create(self, user_id, hospital_name):
        public_id = uuid.uuid4().hex
        now = datetime.now()
        expires_at = now + timedelta(
            hours=self.app.config.get("ANALYSIS_JOB_RETENTION_HOURS", 24)
        )
        with connect_database(self.database_path) as connection:
            self._cleanup_expired(connection, now)
            connection.execute(
                """
                INSERT INTO analysis_jobs(
                    public_id, user_id, hospital_name, status,
                    created_at, expires_at
                ) VALUES (?, ?, ?, 'queued', ?, ?)
                """,
                (
                    public_id,
                    user_id,
                    hospital_name,
                    _timestamp(now),
                    _timestamp(expires_at),
                ),
            )
            connection.commit()

        future = self.executor.submit(self._execute, public_id, user_id, hospital_name)
        with self._future_lock:
            self._futures[public_id] = future
        future.add_done_callback(lambda _future: self._forget_future(public_id))
        return public_id

    def get(self, public_id, user_id, is_admin=False):
        with connect_database(self.database_path, rows=True) as connection:
            if is_admin:
                return connection.execute(
                    "SELECT * FROM analysis_jobs WHERE public_id = ?",
                    (public_id,),
                ).fetchone()
            return connection.execute(
                "SELECT * FROM analysis_jobs WHERE public_id = ? AND user_id = ?",
                (public_id, user_id),
            ).fetchone()

    def cancel(self, public_id, user_id, is_admin=False):
        job = self.get(public_id, user_id, is_admin=is_admin)
        if not job or job["status"] != "queued":
            return False
        with self._future_lock:
            future = self._futures.get(public_id)
        if future and not future.cancel():
            return False
        with connect_database(self.database_path) as connection:
            connection.execute(
                """
                UPDATE analysis_jobs
                SET status = 'cancelled', finished_at = ?, error_message = NULL
                WHERE public_id = ? AND status = 'queued'
                """,
                (_timestamp(), public_id),
            )
            connection.commit()
        return True

    def _execute(self, public_id, user_id, hospital_name):
        with connect_database(self.database_path) as connection:
            cursor = connection.execute(
                """
                UPDATE analysis_jobs
                SET status = 'running', started_at = ?
                WHERE public_id = ? AND status = 'queued'
                """,
                (_timestamp(), public_id),
            )
            connection.commit()
            if cursor.rowcount != 1:
                return

        try:
            payload, status_code = self.callback(user_id, hospital_name)
            succeeded = status_code < 400 and payload.get("status") == "success"
            final_status = "succeeded" if succeeded else "failed"
            error_message = None if succeeded else str(
                payload.get("message") or payload.get("error") or "分析失敗"
            )[:500]
            result_json = json.dumps(payload, ensure_ascii=False) if succeeded else None
        except Exception:
            LOGGER.exception(
                "analysis_job_failed",
                extra={"analysis_job_id": public_id},
            )
            final_status = "failed"
            result_json = None
            error_message = "分析服務暫時無法完成，請稍後重試。"

        with connect_database(self.database_path) as connection:
            connection.execute(
                """
                UPDATE analysis_jobs
                SET status = ?, result_json = ?, error_message = ?, finished_at = ?
                WHERE public_id = ?
                """,
                (
                    final_status,
                    result_json,
                    error_message,
                    _timestamp(),
                    public_id,
                ),
            )
            connection.commit()

    def _recover_interrupted_jobs(self):
        with connect_database(self.database_path) as connection:
            connection.execute(
                """
                UPDATE analysis_jobs
                SET status = 'failed',
                    error_message = '服務重新啟動，請重新送出查詢。',
                    finished_at = ?
                WHERE status IN ('queued', 'running')
                """,
                (_timestamp(),),
            )
            connection.commit()

    @staticmethod
    def _cleanup_expired(connection, now):
        connection.execute(
            """
            DELETE FROM analysis_jobs
            WHERE expires_at <= ?
              AND status IN ('succeeded', 'failed', 'cancelled')
            """,
            (_timestamp(now),),
        )

    def _forget_future(self, public_id):
        with self._future_lock:
            self._futures.pop(public_id, None)


def register_analysis_job_routes(app, *, database_path, limiter, callback):
    service = AnalysisJobService(app, database_path, callback)

    @app.route("/api/analysis-jobs", methods=["POST"])
    @login_required
    @limiter.limit("2 per minute")
    def create_analysis_job():
        hospital_name = str(request.form.get("hospital") or "").replace("臺", "台").strip()
        if not 2 <= len(hospital_name) <= 200:
            return jsonify({"status": "error", "message": "請輸入有效的醫院名稱。"}), 400
        public_id = service.create(current_user.id, hospital_name)
        return (
            jsonify(
                {
                    "status": "queued",
                    "job_id": public_id,
                    "status_url": url_for("analysis_job_status", public_id=public_id),
                }
            ),
            202,
        )

    @app.route("/api/analysis-jobs/<public_id>")
    @login_required
    @limiter.limit("120 per minute")
    def analysis_job_status(public_id):
        job = service.get(public_id, current_user.id, is_admin=current_user.is_admin)
        if not job:
            return jsonify({"status": "error", "message": "找不到查詢任務。"}), 404
        payload = {
            "job_id": job["public_id"],
            "status": job["status"],
            "hospital": job["hospital_name"],
            "created_at": job["created_at"],
            "started_at": job["started_at"],
            "finished_at": job["finished_at"],
            "message": job["error_message"],
        }
        if job["status"] == "succeeded" and job["result_json"]:
            payload["result"] = json.loads(job["result_json"])
        return jsonify(payload)

    @app.route("/api/analysis-jobs/<public_id>/cancel", methods=["POST"])
    @login_required
    @limiter.limit("10 per minute")
    def cancel_analysis_job(public_id):
        cancelled = service.cancel(
            public_id,
            current_user.id,
            is_admin=current_user.is_admin,
        )
        if not cancelled:
            return jsonify(
                {"status": "error", "message": "任務已開始或無法取消。"}
            ), 409
        return jsonify({"status": "cancelled"})

    return service
