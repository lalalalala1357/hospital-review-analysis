"""Administrative user role, hospital approval, and account removal routes."""

from datetime import datetime
import os
import sqlite3
import time

from flask import flash, redirect, request, url_for
from flask_login import current_user, login_required

from access_control import admin_required
from database import connect_database, remove_file_quietly


def register_admin_user_routes(app, *, database_path, bcrypt, upload_folder):
    @app.route('/admin/toggle_admin/<int:user_id>', methods=['POST'])
    @login_required
    @admin_required
    def toggle_admin(user_id):
        if not current_user.is_admin:
            return redirect(url_for('index'))
        if user_id == current_user.id:
            flash('您不能取消自己的管理員權限', 'analyze_error')
            return redirect(url_for('admin_page'))

        with connect_database(database_path) as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT is_admin FROM users WHERE id = ?', (user_id,))
            row = cursor.fetchone()
            if not row:
                flash('找不到指定的使用者', 'analyze_error')
                return redirect(url_for('admin_page') + '#users')
            new_status = 0 if row[0] == 1 else 1
            new_role = 'admin' if new_status == 1 else 'user'
            cursor.execute("""
                UPDATE users
                SET is_admin = ?, role = ?, approval_status = 'approved', hospital_id = NULL
                WHERE id = ?
            """, (new_status, new_role, user_id))
            conn.commit()

        message = '已升級為管理員' if new_status == 1 else '已降級為一般會員'
        flash(f'權限變更成功：{message}', 'analyze_success')
        return redirect(url_for('admin_page'))

    @app.route('/admin/update_user_role/<int:user_id>', methods=['POST'])
    @login_required
    @admin_required
    def update_user_role(user_id):
        if not current_user.is_admin:
            return redirect(url_for('index'))
        if user_id == current_user.id:
            flash('不能在這裡變更自己的角色', 'analyze_error')
            return redirect(url_for('admin_page') + '#users')

        role = request.form.get('role', 'user')
        approval_status = request.form.get('approval_status', 'approved')
        review_action = request.form.get('review_action', '').strip()
        hospital_id = request.form.get('hospital_id') or None
        admin_note = request.form.get('admin_note', '').strip()
        rejection_reason = request.form.get('rejection_reason', '').strip()
        custom_rejection_reason = request.form.get('custom_rejection_reason', '').strip()

        if role not in ['user', 'hospital', 'admin']:
            role = 'user'
        if approval_status not in ['pending', 'approved', 'rejected']:
            approval_status = 'pending' if role == 'hospital' else 'approved'

        is_admin_value = int(role == 'admin')
        if role != 'hospital':
            hospital_id = None
            approval_status = 'approved'
        elif review_action == 'reject':
            approval_status = 'rejected'
        elif review_action == 'approve':
            approval_status = 'approved'

        if role == 'hospital' and approval_status == 'rejected':
            hospital_id = None
            if rejection_reason == '其他':
                rejection_reason = custom_rejection_reason
            if not rejection_reason:
                flash('退回醫院帳號時，請選擇或填寫退回原因', 'analyze_error')
                return redirect(url_for('admin_page') + '#users')
        else:
            rejection_reason = None

        if approval_status == 'approved':
            rejection_reason = None

        with connect_database(database_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute("""
                SELECT id, username, requested_hospital_name, hospital_id, approval_status
                FROM users
                WHERE id = ?
            """, (user_id,))
            target_user = cursor.fetchone()
            if not target_user:
                flash('找不到指定的使用者', 'analyze_error')
                return redirect(url_for('admin_page') + '#users')

            notification_hospital_id = hospital_id
            if role == 'hospital' and not notification_hospital_id and target_user['requested_hospital_name']:
                cursor.execute("""
                    SELECT id
                    FROM hospitals
                    WHERE REPLACE(name, '臺', '台') = REPLACE(?, '臺', '台')
                       OR REPLACE(?, '臺', '台') LIKE '%' || REPLACE(name, '臺', '台') || '%'
                       OR REPLACE(name, '臺', '台') LIKE '%' || REPLACE(?, '臺', '台') || '%'
                    ORDER BY
                        CASE WHEN REPLACE(name, '臺', '台') = REPLACE(?, '臺', '台') THEN 0 ELSE 1 END,
                        LENGTH(name) DESC
                    LIMIT 1
                """, (
                    target_user['requested_hospital_name'],
                    target_user['requested_hospital_name'],
                    target_user['requested_hospital_name'],
                    target_user['requested_hospital_name'],
                ))
                hospital_row = cursor.fetchone()
                if hospital_row:
                    notification_hospital_id = hospital_row['id']
                    if role == 'hospital' and approval_status == 'approved' and not hospital_id:
                        hospital_id = str(hospital_row['id'])
                        notification_hospital_id = hospital_id

            if role == 'hospital' and approval_status == 'approved' and not hospital_id:
                flash('找不到申請醫院可綁定，請先確認醫院名稱是否已收錄', 'analyze_error')
                return redirect(url_for('admin_page') + '#users')

            cursor.execute("""
                UPDATE users
                SET role = ?, is_admin = ?, approval_status = ?, hospital_id = ?, rejection_reason = ?
                WHERE id = ?
            """, (role, is_admin_value, approval_status, hospital_id, rejection_reason, user_id))

            if role == 'hospital':
                old_status = target_user['approval_status']
                old_hospital_id = str(target_user['hospital_id']) if target_user['hospital_id'] else None
                new_hospital_id = str(hospital_id) if hospital_id else None
                changed = old_status != approval_status or old_hospital_id != new_hospital_id
                if changed or approval_status in ['approved', 'rejected']:
                    history_note = rejection_reason if approval_status == 'rejected' else (admin_note or None)
                    cursor.execute("""
                        INSERT INTO hospital_user_review_history
                            (user_id, action, hospital_id, note, actor_id, created_at)
                        VALUES (?, ?, ?, ?, ?, ?)
                    """, (
                        user_id,
                        approval_status,
                        hospital_id,
                        history_note,
                        current_user.id,
                        datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                    ))

            if role == 'hospital' and approval_status in ['approved', 'rejected']:
                if approval_status == 'approved':
                    title = '院方帳號審核通過'
                    content = '您的院方帳號已審核通過，現在可以查看院方儀表板、評論分析與管理員提醒。'
                    if admin_note:
                        content += f' 審核備註：{admin_note}'
                else:
                    title = '院方帳號申請退回'
                    content = f'您的院方帳號申請已被退回。退回原因：{rejection_reason}。請補齊資料後重新送審。'

                cursor.execute("""
                    INSERT INTO hospital_notifications
                        (hospital_id, user_id, title, content, status, category,
                         link_url, created_at, created_by)
                    VALUES (?, ?, ?, ?, 'unread', 'account', ?, ?, ?)
                """, (
                    notification_hospital_id,
                    user_id,
                    title,
                    content,
                    url_for('hospital_application_status'),
                    datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                    current_user.id,
                ))
            conn.commit()

        flash('使用者角色與醫院綁定已更新', 'analyze_success')
        return redirect(url_for('admin_page') + '#users')

    @app.route('/admin/delete_user/<int:user_id>', methods=['POST'])
    @login_required
    @admin_required
    def delete_user(user_id):
        if not current_user.is_admin:
            return redirect(url_for('index'))
        if user_id == current_user.id:
            flash('不能刪除目前登入中的管理員帳號', 'analyze_error')
            return redirect(url_for('admin_page') + '#users')

        proof_filename = None
        with connect_database(database_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            target = cursor.execute(
                """SELECT proof_document FROM users
                   WHERE id = ? AND role = 'hospital' AND COALESCE(is_active, 1) = 1""",
                (user_id,),
            ).fetchone()
            if target:
                proof_filename = target['proof_document']
            anonymized_username = f'deleted-{user_id}-{int(time.time())}'
            unusable_password = bcrypt.generate_password_hash(os.urandom(32).hex()).decode('utf-8')
            cursor.execute("""
                UPDATE users
                SET username = ?, password = ?, is_admin = 0, role = 'user',
                    approval_status = 'rejected', hospital_id = NULL,
                    official_email = NULL, contact_name = NULL, contact_phone = NULL,
                    institution_code = NULL, requested_hospital_name = NULL,
                    rejection_reason = NULL, proof_document = NULL,
                    is_active = 0, deleted_at = ?
                WHERE id = ? AND role = 'hospital' AND COALESCE(is_active, 1) = 1
            """, (
                anonymized_username,
                unusable_password,
                datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                user_id,
            ))
            deleted = cursor.rowcount
            conn.commit()

        if deleted and proof_filename:
            remove_file_quietly(os.path.join(upload_folder, proof_filename))

        flash(
            '醫院帳號已停用並移除個人資料' if deleted else '找不到可停用的醫院帳號',
            'analyze_success' if deleted else 'analyze_error',
        )
        return redirect(url_for('admin_page') + '#users')
