"""Manual sentiment audit metrics and routes."""

from datetime import datetime
import sqlite3

from flask import flash, jsonify, redirect, render_template, request, url_for
from flask_login import login_required

from database import connect_database


def normalize_binary_sentiment(value):
    text = str(value or '').strip().upper()
    if text in ('POSITIVE', 'NEGATIVE'):
        return text
    if text in ('正面', '正向', '好評', '正評', 'POS', '1'):
        return 'POSITIVE'
    if text in ('負面', '負向', '差評', '負評', 'NEG', '0', '-1'):
        return 'NEGATIVE'
    return None


def calculate_sentiment_audit_metrics(items):
    total = len(items)
    tp = fn = fp = tn = 0
    manual_positive = manual_negative = model_positive = model_negative = correct = 0

    for item in items:
        manual = normalize_binary_sentiment(item.get('manual_sentiment'))
        model = normalize_binary_sentiment(item.get('model_sentiment'))
        if manual == 'POSITIVE':
            manual_positive += 1
        elif manual == 'NEGATIVE':
            manual_negative += 1

        if model == 'POSITIVE':
            model_positive += 1
        elif model == 'NEGATIVE':
            model_negative += 1

        if manual == model:
            correct += 1
        if manual == 'POSITIVE' and model == 'POSITIVE':
            tp += 1
        elif manual == 'POSITIVE' and model == 'NEGATIVE':
            fn += 1
        elif manual == 'NEGATIVE' and model == 'POSITIVE':
            fp += 1
        elif manual == 'NEGATIVE' and model == 'NEGATIVE':
            tn += 1

    def safe_div(numerator, denominator):
        return numerator / denominator if denominator else 0

    positive_precision = safe_div(tp, tp + fp)
    positive_recall = safe_div(tp, tp + fn)
    negative_precision = safe_div(tn, tn + fn)
    negative_recall = safe_div(tn, tn + fp)

    def f1(precision, recall):
        return safe_div(2 * precision * recall, precision + recall)

    return {
        'total': total,
        'manual_positive': manual_positive,
        'manual_negative': manual_negative,
        'model_positive': model_positive,
        'model_negative': model_negative,
        'correct': correct,
        'incorrect': total - correct,
        'accuracy': safe_div(correct, total),
        'positive_precision': positive_precision,
        'positive_recall': positive_recall,
        'positive_f1': f1(positive_precision, positive_recall),
        'negative_precision': negative_precision,
        'negative_recall': negative_recall,
        'negative_f1': f1(negative_precision, negative_recall),
        'tp': tp,
        'fn': fn,
        'fp': fp,
        'tn': tn,
    }


def fetch_sentiment_audit_items(cursor, batch_id):
    cursor.execute("""
        SELECT sai.id, sai.batch_id, sai.review_id, sai.manual_sentiment, sai.model_sentiment,
               sai.is_correct, r.content, r.rating, h.name AS hospital_name
        FROM sentiment_audit_items sai
        JOIN reviews r ON r.id = sai.review_id
        JOIN hospitals h ON h.id = r.hospital_id
        WHERE sai.batch_id = ?
        ORDER BY sai.id
    """, (batch_id,))
    return [dict(row) for row in cursor.fetchall()]


def register_sentiment_audit_routes(app, database_path):
    @app.route('/sentiment_audit')
    @login_required
    def sentiment_audit_list():
        with connect_database(database_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute("""
                SELECT b.id, b.batch_name, b.sample_size, b.status, b.created_at, b.completed_at,
                       COUNT(i.id) AS actual_sample_size
                FROM sentiment_audit_batches b
                LEFT JOIN sentiment_audit_items i ON i.batch_id = b.id
                GROUP BY b.id
                ORDER BY b.id DESC
            """)
            batches = [dict(row) for row in cursor.fetchall()]
        return render_template('sentiment_audit_list.html', batches=batches)

    @app.route('/api/sentiment_audit/create', methods=['POST'])
    @login_required
    def create_sentiment_audit_batch():
        sample_size = 30
        created_at = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

        with connect_database(database_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO sentiment_audit_batches (batch_name, sample_size, status, created_at)
                VALUES (?, ?, 'pending', ?)
            """, ('情緒分析人工抽驗', sample_size, created_at))
            batch_id = cursor.lastrowid
            cursor.execute(
                'UPDATE sentiment_audit_batches SET batch_name = ? WHERE id = ?',
                (f'情緒分析人工抽驗 #{batch_id}', batch_id),
            )

            selected = []
            selected_ids = set()
            for exclude_audited in (True, False):
                if len(selected) >= sample_size:
                    break
                remaining = sample_size - len(selected)
                params = []
                conditions = [
                    'r.content IS NOT NULL',
                    "TRIM(r.content) != ''",
                    """(
                        UPPER(TRIM(r.analyzed_sentiment)) IN ('POSITIVE', 'NEGATIVE')
                        OR TRIM(r.analyzed_sentiment) IN ('正面', '正向', '好評', '正評', '負面', '負向', '差評', '負評')
                    )""",
                ]
                if exclude_audited:
                    conditions.append("""
                        NOT EXISTS (
                            SELECT 1 FROM sentiment_audit_items old_item
                            WHERE old_item.review_id = r.id
                        )
                    """)
                if selected_ids:
                    placeholders = ','.join(['?'] * len(selected_ids))
                    conditions.append(f'r.id NOT IN ({placeholders})')
                    params.extend(selected_ids)
                params.append(remaining)
                cursor.execute(f"""
                    SELECT r.id, r.analyzed_sentiment
                    FROM reviews r
                    WHERE {' AND '.join(conditions)}
                    ORDER BY RANDOM()
                    LIMIT ?
                """, params)
                for row in cursor.fetchall():
                    model_sentiment = normalize_binary_sentiment(row['analyzed_sentiment'])
                    if model_sentiment:
                        selected.append({'id': row['id'], 'model_sentiment': model_sentiment})
                        selected_ids.add(row['id'])

            cursor.executemany("""
                INSERT INTO sentiment_audit_items (batch_id, review_id, model_sentiment, created_at)
                VALUES (?, ?, ?, ?)
            """, [
                (batch_id, item['id'], item['model_sentiment'], created_at)
                for item in selected
            ])
            cursor.execute(
                'UPDATE sentiment_audit_batches SET sample_size = ? WHERE id = ?',
                (len(selected), batch_id),
            )
            conn.commit()

        return jsonify({
            'success': True,
            'batch_id': batch_id,
            'sample_size': len(selected),
            'redirect_url': url_for('sentiment_audit_detail', batch_id=batch_id),
        })

    @app.route('/sentiment_audit/<int:batch_id>')
    @login_required
    def sentiment_audit_detail(batch_id):
        with connect_database(database_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM sentiment_audit_batches WHERE id = ?', (batch_id,))
            batch = cursor.fetchone()
            if not batch:
                flash('找不到指定的情緒分析人工抽驗批次。', 'analyze_error')
                return redirect(url_for('sentiment_audit_list'))

            items = fetch_sentiment_audit_items(cursor, batch_id)
            metrics = calculate_sentiment_audit_metrics(items) if batch['status'] == 'completed' else None

        return render_template(
            'sentiment_audit_detail.html',
            batch=dict(batch),
            items=items,
            metrics=metrics,
        )

    @app.route('/api/sentiment_audit/<int:batch_id>/submit', methods=['POST'])
    @login_required
    def submit_sentiment_audit_batch(batch_id):
        payload = request.get_json(silent=True) or request.form
        raw_items = payload.get('items') if isinstance(payload, dict) else None
        if raw_items is None:
            raw_items = []
            for key, value in request.form.items():
                if key.startswith('manual_sentiment_'):
                    raw_items.append({
                        'item_id': key.replace('manual_sentiment_', '', 1),
                        'manual_sentiment': value,
                    })

        with connect_database(database_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM sentiment_audit_batches WHERE id = ?', (batch_id,))
            batch = cursor.fetchone()
            if not batch:
                return jsonify({'success': False, 'message': '找不到指定批次。'}), 404
            if batch['status'] == 'completed':
                return jsonify({'success': False, 'message': '此批次已完成，不能重複送出。'}), 400

            items = fetch_sentiment_audit_items(cursor, batch_id)
            item_ids = {item['id'] for item in items}
            manual_by_id = {}
            for item in raw_items:
                try:
                    item_id = int(item.get('item_id'))
                except (TypeError, ValueError):
                    return jsonify({'success': False, 'message': '送出的項目格式不正確。'}), 400
                manual_sentiment = normalize_binary_sentiment(item.get('manual_sentiment'))
                if item_id not in item_ids or manual_sentiment not in ('POSITIVE', 'NEGATIVE'):
                    return jsonify({
                        'success': False,
                        'message': '人工標記只能是 POSITIVE 或 NEGATIVE。',
                    }), 400
                manual_by_id[item_id] = manual_sentiment

            if len(manual_by_id) != len(items):
                return jsonify({
                    'success': False,
                    'message': '請完成所有評論的人工標記後再送出。',
                }), 400

            for item in items:
                manual_sentiment = manual_by_id[item['id']]
                is_correct = int(
                    manual_sentiment == normalize_binary_sentiment(item['model_sentiment'])
                )
                cursor.execute("""
                    UPDATE sentiment_audit_items
                    SET manual_sentiment = ?, is_correct = ?
                    WHERE id = ? AND batch_id = ?
                """, (manual_sentiment, is_correct, item['id'], batch_id))

            cursor.execute("""
                UPDATE sentiment_audit_batches
                SET status = 'completed', completed_at = ?
                WHERE id = ?
            """, (datetime.now().strftime('%Y-%m-%d %H:%M:%S'), batch_id))
            conn.commit()

        return jsonify({
            'success': True,
            'message': '情緒分析人工抽驗已完成並計算結果。',
            'redirect_url': url_for('sentiment_audit_detail', batch_id=batch_id),
        })
