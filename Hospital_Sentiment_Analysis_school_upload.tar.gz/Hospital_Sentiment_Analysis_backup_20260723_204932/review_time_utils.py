import re
from datetime import datetime, timedelta

CHINESE_NUMERAL_MAP = {
    "零": 0, "〇": 0, "一": 1, "二": 2, "兩": 2, "俩": 2, "三": 3, "四": 4, "五": 5,
    "六": 6, "七": 7, "八": 8, "九": 9, "十": 10, "半": 0.5,
}


def parse_chinese_number(value):
    """支援 Google 評論常見的中文數字，例如：一、兩、十、十一、二十。"""
    value = str(value or "").strip()
    if not value:
        return 1

    try:
        return float(value)
    except ValueError:
        pass

    if value in CHINESE_NUMERAL_MAP:
        return CHINESE_NUMERAL_MAP[value]

    if "十" in value:
        left, _, right = value.partition("十")
        tens = CHINESE_NUMERAL_MAP.get(left, 1) if left else 1
        ones = CHINESE_NUMERAL_MAP.get(right, 0) if right else 0
        return tens * 10 + ones

    total = 0
    for char in value:
        total = total * 10 + CHINESE_NUMERAL_MAP.get(char, 0)
    return total or 1


def subtract_months(base_date, months):
    month_index = base_date.month - 1 - months
    year = base_date.year + month_index // 12
    month = month_index % 12 + 1
    days_in_month = [
        31,
        29 if year % 4 == 0 and (year % 100 != 0 or year % 400 == 0) else 28,
        31, 30, 31, 30, 31, 31, 30, 31, 30, 31,
    ]
    day = min(base_date.day, days_in_month[month - 1])
    return base_date.replace(year=year, month=month, day=day)


def normalize_google_review_time(raw_time, now=None):
    """
    將 Google Maps 的相對評論時間轉成日期字串。
    注意：「幾個月前 / 幾年前」在 Google 端本來就是模糊值，因此這裡是估算日期。
    """
    text = str(raw_time or "").replace("上次編輯：", "").replace("上次編輯:", "").strip()
    if not text or text in ["未知時間", "Unknown"]:
        return text or "未知時間"

    now = now or datetime.now()
    clean_text = re.sub(r"\s+", "", text)

    if clean_text in ["剛剛", "剛才"]:
        return now.strftime("%Y/%m/%d")
    if clean_text == "昨天":
        return (now - timedelta(days=1)).strftime("%Y/%m/%d")
    if clean_text == "前天":
        return (now - timedelta(days=2)).strftime("%Y/%m/%d")

    match = re.search(r"([0-9]+(?:\.[0-9]+)?|[零〇一二兩俩三四五六七八九十半]+)(?:個)?(分鐘|分|小時|時|天|日|週|周|星期|禮拜|月|年)前", clean_text)
    if not match:
        return text

    amount = parse_chinese_number(match.group(1))
    unit = match.group(2)

    if unit in ["分鐘", "分"]:
        target = now - timedelta(minutes=amount)
    elif unit in ["小時", "時"]:
        target = now - timedelta(hours=amount)
    elif unit in ["天", "日"]:
        target = now - timedelta(days=amount)
    elif unit in ["週", "周", "星期", "禮拜"]:
        target = now - timedelta(days=amount * 7)
    elif unit == "月":
        target = subtract_months(now, int(amount))
    elif unit == "年":
        target = subtract_months(now, int(amount) * 12)
    else:
        return text

    return target.strftime("%Y/%m/%d")


def normalize_stored_review_time(raw_time, stored_at=None):
    if not raw_time:
        return "未知時間"

    text = str(raw_time).strip()
    date_match = re.match(r"^(\d{4})[-/](\d{1,2})[-/](\d{1,2})", text)
    if date_match:
        year, month, day = date_match.groups()
        return f"{int(year):04d}/{int(month):02d}/{int(day):02d}"

    base_time = None
    if stored_at:
        for date_format in ("%Y-%m-%d %H:%M:%S", "%Y/%m/%d %H:%M:%S", "%Y-%m-%d", "%Y/%m/%d"):
            try:
                base_time = datetime.strptime(str(stored_at), date_format)
                break
            except ValueError:
                continue

    return normalize_google_review_time(text, base_time or datetime.now())
