import calendar
import json
import logging
import re
import threading
from collections import Counter, defaultdict
from datetime import date, datetime, time, timedelta

from database import connect_database
from review_time_utils import normalize_stored_review_time


LOGGER = logging.getLogger(__name__)

ALLOWED_PERIODS = (30, 90, 180, 365)
ISSUE_RULES = (
    ("等待時間", ("等很久", "久等", "等待", "排隊", "候診", "等太久")),
    ("服務態度", ("態度", "冷漠", "不耐煩", "口氣", "很兇", "敷衍")),
    ("醫療品質", ("誤診", "延誤", "醫療疏失", "診斷", "治療", "專業")),
    ("收費與流程", ("收費", "費用", "自費", "掛號", "流程", "批價")),
    ("環境設施", ("環境", "廁所", "停車", "病房", "髒", "設備")),
    ("溝通說明", ("說明", "溝通", "解釋", "告知", "沒說")),
)
RECOMMENDATIONS = {
    "等待時間": "檢視尖峰時段人力與叫號流程，公開預估候診時間並追蹤逾時案件。",
    "服務態度": "將高頻服務情境納入第一線溝通訓練，並由主管抽查處理紀錄。",
    "醫療品質": "交由醫療品質單位進行個案複核，確認診療、轉介及告知流程是否完整。",
    "收費與流程": "在掛號與批價前清楚揭露自費項目，統一各接觸點的說明內容。",
    "環境設施": "依評論提及位置建立巡檢清單，設定改善負責人與完成期限。",
    "溝通說明": "建立重要醫療資訊的標準說明與回覆範本，保留病患理解確認紀錄。",
    "其他問題": "由客服逐則標記原因並回報主管，補充分類後再安排改善優先順序。",
}

_SCHEDULER_LOCK = threading.Lock()
_STARTED_DATABASES = set()


def normalize_period(value, default=90):
    try:
        period = int(value)
    except (TypeError, ValueError):
        return default
    return period if period in ALLOWED_PERIODS else default


def classify_issue(content):
    text = str(content or "")
    for category, keywords in ISSUE_RULES:
        if any(keyword in text for keyword in keywords):
            return category
    return "其他問題"


def _parse_review_date(review_time, stored_at):
    normalized = normalize_stored_review_time(review_time, stored_at)
    for value, formats in (
        (normalized, ("%Y/%m/%d", "%Y-%m-%d")),
        (stored_at, ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d", "%Y/%m/%d")),
    ):
        if not value:
            continue
        for date_format in formats:
            try:
                return datetime.strptime(str(value), date_format).date()
            except ValueError:
                continue
    return None


def _review_from_row(row):
    sentiment = str(row["analyzed_sentiment"] or "").upper()
    rating = row["rating"]
    return {
        "id": row["id"],
        "hospital_id": row["hospital_id"],
        "content": row["content"] or "",
        "rating": float(rating) if rating is not None else None,
        "sentiment": sentiment,
        "review_time": row["review_time"],
        "stored_at": row["stored_at"],
        "date": _parse_review_date(row["review_time"], row["stored_at"]),
        "department": row["department"] or "綜合/未提及",
    }


def _metrics(reviews):
    total = len(reviews)
    positive = sum(1 for review in reviews if review["sentiment"] == "POSITIVE")
    negative = sum(1 for review in reviews if review["sentiment"] == "NEGATIVE")
    ratings = [review["rating"] for review in reviews if review["rating"] is not None]
    return {
        "total": total,
        "positive": positive,
        "negative": negative,
        "positive_rate": round(positive / total * 100, 1) if total else 0.0,
        "negative_rate": round(negative / total * 100, 1) if total else 0.0,
        "average_rating": round(sum(ratings) / len(ratings), 2) if ratings else None,
        "rated_reviews": len(ratings),
    }


def _delta(current, previous):
    if current is None or previous is None:
        return None
    return round(current - previous, 1)


def _city_from_address(address):
    normalized = str(address or "").replace("臺", "台").strip()
    match = re.match(
        r"^(台北市|新北市|桃園市|台中市|台南市|高雄市|基隆市|新竹市|"
        r"嘉義市|新竹縣|苗栗縣|彰化縣|南投縣|雲林縣|嘉義縣|屏東縣|"
        r"宜蘭縣|花蓮縣|台東縣|澎湖縣|金門縣|連江縣)",
        normalized,
    )
    return match.group(1) if match else None


def _build_trend(reviews, period_days):
    buckets = defaultdict(list)
    for review in reviews:
        review_date = review["date"]
        if not review_date:
            continue
        if period_days <= 30:
            bucket_date = review_date
        else:
            bucket_date = review_date - timedelta(days=review_date.weekday())
        buckets[bucket_date].append(review)

    trend = []
    for bucket_date in sorted(buckets):
        metrics = _metrics(buckets[bucket_date])
        trend.append(
            {
                "label": bucket_date.isoformat(),
                "total": metrics["total"],
                "positive_rate": metrics["positive_rate"],
                "negative": metrics["negative"],
                "average_rating": metrics["average_rating"],
            }
        )
    return trend


def _build_issues(reviews):
    negative_reviews = [
        review for review in reviews if review["sentiment"] == "NEGATIVE"
    ]
    counter = Counter(classify_issue(review["content"]) for review in negative_reviews)
    return [
        {
            "name": name,
            "count": count,
            "share": round(count / len(negative_reviews) * 100, 1)
            if negative_reviews
            else 0.0,
        }
        for name, count in counter.most_common(6)
    ]


def _build_departments(reviews):
    grouped = defaultdict(list)
    for review in reviews:
        grouped[review["department"]].append(review)
    rows = []
    for department, items in grouped.items():
        metrics = _metrics(items)
        rows.append(
            {
                "name": department,
                "total": metrics["total"],
                "negative": metrics["negative"],
                "negative_rate": metrics["negative_rate"],
            }
        )
    return sorted(rows, key=lambda item: (-item["negative"], -item["total"]))[:8]


def _build_recommendations(issues):
    if not issues:
        return [
            {
                "title": "維持服務品質",
                "priority": "例行",
                "description": "目前期間沒有明顯負評集中，建議持續監測新評論與回覆時效。",
            }
        ]
    return [
        {
            "title": issue["name"],
            "priority": "高" if index == 0 else "中",
            "description": RECOMMENDATIONS[issue["name"]],
        }
        for index, issue in enumerate(issues[:3])
    ]


def _build_competition(connection, hospital, start_date, end_date):
    city = _city_from_address(hospital["address"])
    rows = connection.execute(
        """
        SELECT
            review.id, review.hospital_id, review.content, review.rating,
            review.review_time, review.stored_at, review.analyzed_sentiment,
            review.department, hospital.address AS hospital_address
        FROM reviews review
        JOIN hospitals hospital ON hospital.id = review.hospital_id
        ORDER BY review.id
        """
    ).fetchall()

    grouped = defaultdict(list)
    for row in rows:
        row_city = _city_from_address(row["hospital_address"])
        if city and row_city != city:
            continue
        review = _review_from_row(row)
        if review["date"] and start_date <= review["date"] <= end_date:
            grouped[row["hospital_id"]].append(review)

    own_metrics = _metrics(grouped.get(hospital["id"], []))
    peer_metrics = [
        _metrics(reviews)
        for hospital_id, reviews in grouped.items()
        if hospital_id != hospital["id"] and len(reviews) >= 3
    ]

    def peer_average(metric_name):
        values = [
            metrics[metric_name]
            for metrics in peer_metrics
            if metrics[metric_name] is not None
        ]
        return round(sum(values) / len(values), 1) if values else None

    benchmarks = []
    for label, metric_name, unit in (
        ("正評率", "positive_rate", "%"),
        ("負評率", "negative_rate", "%"),
        ("期間評論數", "total", "則"),
        ("平均星等", "average_rating", "星"),
    ):
        peer_value = peer_average(metric_name)
        own_value = own_metrics[metric_name]
        benchmarks.append(
            {
                "label": label,
                "hospital_value": own_value,
                "peer_average": peer_value,
                "difference": _delta(own_value, peer_value),
                "unit": unit,
            }
        )

    return {
        "scope": city or "全台資料庫",
        "peer_count": len(peer_metrics),
        "benchmarks": benchmarks,
    }


def build_operations_dashboard(database_path, hospital_id, period_days=90, today=None):
    period_days = normalize_period(period_days)
    today = today or date.today()
    current_start = today - timedelta(days=period_days - 1)
    previous_end = current_start - timedelta(days=1)
    previous_start = previous_end - timedelta(days=period_days - 1)

    with connect_database(database_path, rows=True, read_only=True) as connection:
        hospital_row = connection.execute(
            "SELECT id, name, address, created_at FROM hospitals WHERE id = ?",
            (hospital_id,),
        ).fetchone()
        if not hospital_row:
            return None
        hospital = dict(hospital_row)
        review_rows = connection.execute(
            """
            SELECT id, hospital_id, content, rating, review_time, stored_at,
                   analyzed_sentiment, department
            FROM reviews
            WHERE hospital_id = ?
            ORDER BY id DESC
            """,
            (hospital_id,),
        ).fetchall()
        reviews = [_review_from_row(row) for row in review_rows]
        current_reviews = [
            review
            for review in reviews
            if review["date"] and current_start <= review["date"] <= today
        ]
        previous_reviews = [
            review
            for review in reviews
            if review["date"] and previous_start <= review["date"] <= previous_end
        ]
        current_metrics = _metrics(current_reviews)
        previous_metrics = _metrics(previous_reviews)
        issues = _build_issues(current_reviews)
        competition = _build_competition(
            connection, hospital_row, current_start, today
        )

    negative_reviews = sorted(
        (
            review
            for review in current_reviews
            if review["sentiment"] == "NEGATIVE"
        ),
        key=lambda review: (review["date"], review["id"]),
        reverse=True,
    )
    recent_negative = [
        {
            **review,
            "date": review["date"].isoformat() if review["date"] else None,
            "issue": classify_issue(review["content"]),
        }
        for review in negative_reviews[:8]
    ]

    latest_date = next(
        (review["date"].isoformat() for review in reviews if review["date"]),
        None,
    )
    return {
        "hospital": hospital,
        "period_days": period_days,
        "period_start": current_start.isoformat(),
        "period_end": today.isoformat(),
        "previous_start": previous_start.isoformat(),
        "previous_end": previous_end.isoformat(),
        "latest_review_date": latest_date,
        "metrics": current_metrics,
        "previous_metrics": previous_metrics,
        "deltas": {
            "total": current_metrics["total"] - previous_metrics["total"],
            "positive_rate": _delta(
                current_metrics["positive_rate"], previous_metrics["positive_rate"]
            ),
            "negative_rate": _delta(
                current_metrics["negative_rate"], previous_metrics["negative_rate"]
            ),
            "average_rating": _delta(
                current_metrics["average_rating"], previous_metrics["average_rating"]
            ),
        },
        "trend": _build_trend(current_reviews, period_days),
        "issues": issues,
        "departments": _build_departments(current_reviews),
        "recent_negative_reviews": recent_negative,
        "recommendations": _build_recommendations(issues),
        "competition": competition,
    }


def get_operations_state(database_path, hospital_id):
    with connect_database(database_path, rows=True, read_only=True) as connection:
        reports = connection.execute(
            """
            SELECT id, period_days, period_start, period_end, source,
                   delivery_status, created_at
            FROM business_reports
            WHERE hospital_id = ?
            ORDER BY id DESC
            LIMIT 12
            """,
            (hospital_id,),
        ).fetchall()
        schedule = connection.execute(
            "SELECT * FROM business_report_schedules WHERE hospital_id = ?",
            (hospital_id,),
        ).fetchone()
    return {
        "reports": [dict(row) for row in reports],
        "schedule": dict(schedule) if schedule else None,
    }


def create_business_report(
    database_path,
    hospital_id,
    period_days=90,
    created_by=None,
    source="manual",
    schedule_id=None,
    scheduled_for=None,
):
    dashboard = build_operations_dashboard(database_path, hospital_id, period_days)
    if not dashboard:
        raise LookupError("找不到醫院")
    created_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    payload = json.dumps(dashboard, ensure_ascii=False, default=str)
    with connect_database(database_path) as connection:
        cursor = connection.execute(
            """
            INSERT OR IGNORE INTO business_reports(
                hospital_id, period_days, period_start, period_end, payload,
                source, delivery_status, created_by, schedule_id,
                scheduled_for, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, 'ready', ?, ?, ?, ?)
            """,
            (
                hospital_id,
                dashboard["period_days"],
                dashboard["period_start"],
                dashboard["period_end"],
                payload,
                source,
                created_by,
                schedule_id,
                scheduled_for,
                created_at,
            ),
        )
        if cursor.rowcount:
            report_id = cursor.lastrowid
        else:
            row = connection.execute(
                """
                SELECT id FROM business_reports
                WHERE schedule_id = ? AND scheduled_for = ?
                """,
                (schedule_id, scheduled_for),
            ).fetchone()
            report_id = row[0]
        connection.commit()
    return report_id


def get_business_report(database_path, report_id, hospital_id):
    with connect_database(database_path, rows=True, read_only=True) as connection:
        row = connection.execute(
            """
            SELECT report.*, hospital.name AS hospital_name
            FROM business_reports report
            JOIN hospitals hospital ON hospital.id = report.hospital_id
            WHERE report.id = ? AND report.hospital_id = ?
            """,
            (report_id, hospital_id),
        ).fetchone()
    if not row:
        return None
    report = dict(row)
    report["payload"] = json.loads(report["payload"])
    return report


def _next_schedule_at(frequency, report_day, now=None):
    now = now or datetime.now()
    if frequency == "weekly":
        target_weekday = max(1, min(int(report_day), 7)) - 1
        days_ahead = (target_weekday - now.weekday()) % 7
        candidate = datetime.combine(now.date() + timedelta(days=days_ahead), time(8))
        if candidate <= now:
            candidate += timedelta(days=7)
        return candidate

    target_day = max(1, min(int(report_day), 28))
    candidate = datetime(now.year, now.month, target_day, 8)
    if candidate <= now:
        if now.month == 12:
            year, month = now.year + 1, 1
        else:
            year, month = now.year, now.month + 1
        day = min(target_day, calendar.monthrange(year, month)[1])
        candidate = datetime(year, month, day, 8)
    return candidate


def save_report_schedule(
    database_path, hospital_id, enabled, frequency, report_day, period_days
):
    if frequency not in {"weekly", "monthly"}:
        raise ValueError("無效的報告頻率")
    period_days = normalize_period(period_days)
    report_day = int(report_day)
    if frequency == "weekly":
        report_day = max(1, min(report_day, 7))
    else:
        report_day = max(1, min(report_day, 28))
    now = datetime.now()
    next_run = _next_schedule_at(frequency, report_day, now)
    now_text = now.strftime("%Y-%m-%d %H:%M:%S")
    with connect_database(database_path) as connection:
        connection.execute(
            """
            INSERT INTO business_report_schedules(
                hospital_id, enabled, frequency, report_day, period_days,
                next_run_at, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(hospital_id) DO UPDATE SET
                enabled = excluded.enabled,
                frequency = excluded.frequency,
                report_day = excluded.report_day,
                period_days = excluded.period_days,
                next_run_at = excluded.next_run_at,
                updated_at = excluded.updated_at
            """,
            (
                hospital_id,
                1 if enabled else 0,
                frequency,
                report_day,
                period_days,
                next_run.strftime("%Y-%m-%d %H:%M:%S"),
                now_text,
                now_text,
            ),
        )
        connection.commit()


def process_due_reports(database_path, now=None):
    now = now or datetime.now()
    now_text = now.strftime("%Y-%m-%d %H:%M:%S")
    with connect_database(database_path, rows=True, read_only=True) as connection:
        schedules = connection.execute(
            """
            SELECT * FROM business_report_schedules
            WHERE enabled = 1 AND next_run_at IS NOT NULL AND next_run_at <= ?
            ORDER BY next_run_at, id
            """,
            (now_text,),
        ).fetchall()

    generated = 0
    for schedule in schedules:
        report_id = create_business_report(
            database_path,
            schedule["hospital_id"],
            schedule["period_days"],
            source="scheduled",
            schedule_id=schedule["id"],
            scheduled_for=schedule["next_run_at"],
        )
        next_run = _next_schedule_at(
            schedule["frequency"], schedule["report_day"], now
        )
        with connect_database(database_path) as connection:
            connection.execute(
                """
                UPDATE business_report_schedules
                SET last_run_at = ?, next_run_at = ?, updated_at = ?
                WHERE id = ?
                """,
                (
                    now_text,
                    next_run.strftime("%Y-%m-%d %H:%M:%S"),
                    now_text,
                    schedule["id"],
                ),
            )
            connection.execute(
                """
                INSERT INTO hospital_notifications(
                    hospital_id, title, content, status, category,
                    link_url, created_at
                ) VALUES (?, '營運報告已產生', ?, 'unread',
                          'business_report', ?, ?)
                """,
                (
                    schedule["hospital_id"],
                    f"第 {report_id} 號定期口碑報告已完成，可前往營運中心查看。",
                    f"/hospital/operations/reports/{report_id}",
                    now_text,
                ),
            )
            connection.commit()
        generated += 1
    return generated


def _operations_scheduler_loop(database_path, interval_seconds):
    while True:
        try:
            process_due_reports(database_path)
        except Exception:
            LOGGER.exception("operations_scheduler_failed")
        threading.Event().wait(interval_seconds)


def start_operations_scheduler(database_path, interval_seconds=300):
    with _SCHEDULER_LOCK:
        if database_path in _STARTED_DATABASES:
            return False
        _STARTED_DATABASES.add(database_path)
        thread = threading.Thread(
            target=_operations_scheduler_loop,
            args=(database_path, max(60, int(interval_seconds))),
            daemon=True,
            name="hospital-operations-scheduler",
        )
        thread.start()
    return True
