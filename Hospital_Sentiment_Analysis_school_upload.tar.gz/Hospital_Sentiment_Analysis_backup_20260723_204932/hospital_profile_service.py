"""Hospital profile aggregation service.

This module owns the read model used by the hospital profile and report pages.
It intentionally has no Flask route dependencies, which keeps the business
logic testable and prevents profile work from coupling to crawler code.
"""

from collections import Counter
from datetime import datetime
import sqlite3

from database import connect_database
from review_time_utils import normalize_stored_review_time


class HospitalProfileService:
    def __init__(
        self,
        *,
        database_path,
        award_departments,
        classify_negative_issue,
        get_negative_issue_rows,
        generate_improvement_suggestions,
        get_representative_reviews,
        extract_keywords,
        generate_hospital_feature_tags,
        resolve_hospital_address,
        get_favorite_info,
    ):
        self.database_path = database_path
        self.award_departments = award_departments
        self.classify_negative_issue = classify_negative_issue
        self.get_negative_issue_rows = get_negative_issue_rows
        self.generate_improvement_suggestions = generate_improvement_suggestions
        self.get_representative_reviews = get_representative_reviews
        self.extract_keywords = extract_keywords
        self.generate_hospital_feature_tags = generate_hospital_feature_tags
        self.resolve_hospital_address = resolve_hospital_address
        self.get_favorite_info = get_favorite_info

    def build(self, hospital_id, user):
        with connect_database(self.database_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()

            cursor.execute("SELECT * FROM hospitals WHERE id = ?", (hospital_id,))
            hospital = cursor.fetchone()
            if not hospital:
                return None

            cursor.execute("""
                SELECT id, content, analyzed_sentiment, review_time, stored_at, department
                FROM reviews
                WHERE hospital_id = ?
                ORDER BY
                    CASE
                        WHEN review_time GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]' THEN review_time
                        ELSE stored_at
                    END DESC,
                    id DESC
            """, (hospital_id,))
            review_rows = cursor.fetchall()

            cursor.execute("""
                SELECT department, award_name
                FROM hospital_awards
                WHERE REPLACE(hospital_name, '臺', '台') = REPLACE(?, '臺', '台')
                ORDER BY department, award_name
            """, (hospital['name'],))
            awards = [dict(row) for row in cursor.fetchall()]

            cursor.execute("""
                SELECT id, department, award_name, status, admin_note, proof_document, created_at, reviewed_at
                FROM hospital_award_applications
                WHERE hospital_id = ?
                   OR REPLACE(hospital_name, '臺', '台') = REPLACE(?, '臺', '台')
                ORDER BY id DESC
                LIMIT 8
            """, (hospital_id, hospital['name']))
            award_applications = [dict(row) for row in cursor.fetchall()]

            if award_applications:
                placeholders = ",".join(["?"] * len(award_applications))
                cursor.execute(f"""
                    SELECT
                        h.application_id, h.action, h.note, h.proof_document,
                        h.actor_id, h.created_at, u.username AS actor_username
                    FROM hospital_award_application_history h
                    LEFT JOIN users u ON h.actor_id = u.id
                    WHERE h.application_id IN ({placeholders})
                    ORDER BY h.id DESC
                """, [item['id'] for item in award_applications])
                award_history_map = {}
                for row in cursor.fetchall():
                    award_history_map.setdefault(row['application_id'], []).append(dict(row))
                for item in award_applications:
                    item['history'] = award_history_map.get(item['id'], [])

            notifications = []
            if getattr(user, 'role', None) == 'hospital' and user.hospital_id == hospital_id:
                cursor.execute("""
                    SELECT id, title, content, status, category, link_url, created_at
                    FROM hospital_notifications
                    WHERE hospital_id = ?
                      AND (user_id IS NULL OR user_id = ?)
                      AND COALESCE(category, 'general') NOT IN ('ai_quota', 'reputation_alert')
                    ORDER BY id DESC
                    LIMIT 1
                """, (hospital_id, user.id))
                notifications = [dict(row) for row in cursor.fetchall()]

                cursor.execute("""
                    SELECT COUNT(*)
                    FROM hospital_notifications
                    WHERE hospital_id = ?
                      AND (user_id IS NULL OR user_id = ?)
                      AND status = 'unread'
                      AND COALESCE(category, 'general') NOT IN ('ai_quota', 'reputation_alert')
                """, (hospital_id, user.id))
                unread_notification_count = cursor.fetchone()[0]
            else:
                unread_notification_count = 0

        reviews = []
        sentiment_items = []
        for row in review_rows:
            sentiment = row['analyzed_sentiment'] or 'NEUTRAL'
            issue_category = self.classify_negative_issue(row['content'] or '', sentiment)
            score = 100.0 if sentiment == 'POSITIVE' else 0.0
            normalized_time = normalize_stored_review_time(row['review_time'], row['stored_at'])
            try:
                review_date = datetime.strptime(normalized_time, "%Y/%m/%d").strftime("%Y-%m-%d")
            except ValueError:
                review_date = None

            review_item = {
                'id': row['id'],
                'content': row['content'] or '',
                'text': row['content'] or '',
                'sentiment': sentiment,
                'label': sentiment,
                'time': normalized_time,
                'review_date': review_date,
                'stored_at': row['stored_at'],
                'department': row['department'] or '綜合/未提及',
                'score': score,
                'issue_category': issue_category,
            }
            reviews.append(review_item)
            sentiment_items.append({
                'text': review_item['text'],
                'label': sentiment,
                'time': review_item['time'],
                'score': score,
                'department': review_item['department'],
                'issue_category': issue_category,
            })

        total_count = len(reviews)
        pos_count = sum(1 for item in reviews if item['sentiment'] == 'POSITIVE')
        neg_count = sum(1 for item in reviews if item['sentiment'] == 'NEGATIVE')
        positive_rate = round(pos_count / total_count * 100) if total_count else 0
        negative_rate = round(neg_count / total_count * 100) if total_count else 0
        satisfaction_score = round(positive_rate / 10, 1) if total_count else 0

        issue_rows = self.get_negative_issue_rows(sentiment_items, limit=8)
        suggestions = self.generate_improvement_suggestions(issue_rows, neg_count, total_count)
        representative_reviews = self.get_representative_reviews(reviews, issue_rows)
        keywords = (
            self.extract_keywords(sentiment_items, top_n=10)
            if sentiment_items
            else {'labels': [], 'data': []}
        )
        feature_tags = self.generate_hospital_feature_tags(reviews, issue_rows, awards, {
            'total': total_count,
            'positive_rate': positive_rate,
            'negative_rate': negative_rate,
        })

        department_counter = Counter(item['department'] for item in reviews)
        department_rows = [
            {'department': department, 'count': count}
            for department, count in department_counter.most_common(8)
        ]

        trend_by_date = {}
        for item in reviews:
            date_label = item['time'] or '未知時間'
            trend_bucket = trend_by_date.setdefault(date_label, {'total_score': 0, 'count': 0})
            trend_bucket['total_score'] += 10 if item['sentiment'] == 'POSITIVE' else 0
            trend_bucket['count'] += 1

        def trend_sort_key(row):
            try:
                return datetime.strptime(row['label'], "%Y/%m/%d")
            except ValueError:
                return datetime.max

        trend = [
            {
                'label': date_label,
                'score': round(data['total_score'] / data['count'], 1) if data['count'] else 0,
                'count': data['count'],
                'sentiment': 'POSITIVE' if data['total_score'] / data['count'] >= 5 else 'NEGATIVE',
            }
            for date_label, data in trend_by_date.items()
        ]
        trend.sort(key=trend_sort_key)

        latest_update = None
        review_dates = []
        for item in reviews:
            if item['stored_at'] and (not latest_update or item['stored_at'] > latest_update):
                latest_update = item['stored_at']
            if item.get('review_date'):
                review_dates.append(item['review_date'])

        hospital_data = dict(hospital)
        display_address, address_source = self.resolve_hospital_address(
            hospital_data.get('name'), hospital_data.get('address')
        )
        hospital_data['display_address'] = display_address
        hospital_data['address_source'] = address_source

        return {
            'hospital': hospital_data,
            'stats': {
                'total': total_count,
                'positive': pos_count,
                'negative': neg_count,
                'positive_rate': positive_rate,
                'negative_rate': negative_rate,
                'satisfaction_score': satisfaction_score,
                'latest_update': latest_update or hospital['created_at'] or '--',
                'period_start': min(review_dates) if review_dates else '--',
                'period_end': max(review_dates) if review_dates else '--',
            },
            'issues': issue_rows,
            'suggestions': suggestions,
            'representative_reviews': representative_reviews,
            'keywords': keywords,
            'feature_tags': feature_tags,
            'departments': department_rows,
            'trend': trend,
            'reviews': reviews,
            'awards': awards,
            'award_applications': award_applications,
            'notifications': notifications,
            'unread_notification_count': unread_notification_count,
            'award_departments': self.award_departments,
            'favorite': self.get_favorite_info(user.id, hospital_id),
        }
