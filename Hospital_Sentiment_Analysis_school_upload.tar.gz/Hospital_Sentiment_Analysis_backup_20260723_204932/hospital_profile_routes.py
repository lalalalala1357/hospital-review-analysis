"""Hospital-facing routes with stable legacy endpoint names."""

from dataclasses import dataclass
from datetime import datetime
import sqlite3
from typing import Callable, Sequence

from flask import flash, jsonify, redirect, render_template, request, url_for
from flask_login import current_user, login_required, logout_user

from database import connect_database


@dataclass(frozen=True)
class HospitalProfileRouteDependencies:
    database_path: str
    hospital_names: Sequence[str]
    get_profile_data: Callable
    can_view_profile: Callable
    get_user_favorites: Callable
    save_proof_document: Callable
    log_award_application_history: Callable
    normalize_hospital_name: Callable


def register_hospital_profile_routes(app, dependencies):
    """Register hospital routes without changing their existing endpoints."""
    deps = dependencies

    @app.route('/hospital/<int:hospital_id>')
    @login_required
    def hospital_profile(hospital_id):
        if not deps.can_view_profile(hospital_id):
            flash('您只能查看已授權的醫院詳細檔案', 'analyze_error')
            return redirect(url_for('index'))

        profile = deps.get_profile_data(hospital_id)
        if not profile:
            flash('找不到該醫院檔案', 'analyze_error')
            return redirect(url_for('google_page'))

        return render_template('hospital_profile.html', profile=profile)

    @app.route('/hospital/<int:hospital_id>/report')
    @login_required
    def hospital_report(hospital_id):
        if not deps.can_view_profile(hospital_id):
            flash('您只能匯出已授權的醫院報告', 'analyze_error')
            return redirect(url_for('index'))

        profile = deps.get_profile_data(hospital_id)
        if not profile:
            flash('找不到該醫院檔案', 'analyze_error')
            return redirect(url_for('google_page'))

        return render_template('hospital_report.html', profile=profile)

    @app.route('/hospital/<int:hospital_id>/award_application', methods=['POST'])
    @login_required
    def submit_award_application(hospital_id):
        if not (
            getattr(current_user, 'role', None) == 'hospital'
            and current_user.approval_status == 'approved'
            and current_user.hospital_id == hospital_id
        ):
            flash('只有已審核通過的醫院帳號可以提出獎項或認證申請。', 'analyze_error')
            return redirect(url_for('hospital_profile', hospital_id=hospital_id))

        department = request.form.get('department', '').strip()
        award_name = request.form.get('award_name', '').strip()
        proof_filename = None

        if not department or not award_name:
            flash('請選擇所屬科別並填寫獎項/認證名稱。', 'analyze_error')
            return redirect(url_for('hospital_profile', hospital_id=hospital_id))

        if 'proof_document' in request.files:
            proof_filename, upload_error = deps.save_proof_document(request.files['proof_document'])
            if upload_error:
                flash(upload_error, 'analyze_error')
                return redirect(url_for('hospital_profile', hospital_id=hospital_id))

        with connect_database(deps.database_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute("SELECT name FROM hospitals WHERE id = ?", (hospital_id,))
            hospital = cursor.fetchone()
            if not hospital:
                flash('找不到醫院資料，無法送出申請。', 'analyze_error')
                return redirect(url_for('hospital_dashboard'))

            cursor.execute("""
                SELECT id FROM hospital_award_applications
                WHERE hospital_id = ?
                  AND department = ?
                  AND award_name = ?
                  AND status = 'pending'
                LIMIT 1
            """, (hospital_id, department, award_name))
            if cursor.fetchone():
                flash('這筆獎項/認證已在待審核清單中，請等待管理員審核。', 'analyze_error')
                return redirect(url_for('hospital_profile', hospital_id=hospital_id))

            cursor.execute("""
                INSERT INTO hospital_award_applications
                    (hospital_id, hospital_name, user_id, department, award_name, status, proof_document, created_at)
                VALUES (?, ?, ?, ?, ?, 'pending', ?, ?)
            """, (
                hospital_id,
                deps.normalize_hospital_name(hospital['name']),
                current_user.id,
                department,
                award_name,
                proof_filename,
                datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            ))
            application_id = cursor.lastrowid
            deps.log_award_application_history(
                cursor,
                application_id,
                'submitted',
                '院方送出獎項/認證申請',
                proof_filename,
                current_user.id,
            )
            conn.commit()

        flash('獎項/認證申請已送出，待管理員審核後才會公開顯示。', 'analyze_success')
        return redirect(url_for('hospital_profile', hospital_id=hospital_id))

    @app.route('/hospital/by-name/<path:hospital_name>')
    @login_required
    def hospital_profile_by_name(hospital_name):
        normalized_name = hospital_name.replace("臺", "台").strip()
        place_id = normalized_name.lower().replace(" ", "_")

        with connect_database(deps.database_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute("""
                SELECT id
                FROM hospitals
                WHERE google_place_id = ?
                   OR REPLACE(name, '臺', '台') = ?
                ORDER BY id DESC
                LIMIT 1
            """, (place_id, normalized_name))
            row = cursor.fetchone()

        if row:
            return redirect(url_for('hospital_profile', hospital_id=row['id']))

        return redirect(url_for('google_page', hospital=normalized_name))

    @app.route('/favorites')
    @login_required
    def favorites_page():
        return render_template('favorites.html', favorites=deps.get_user_favorites(current_user.id))

    @app.route('/hospital/<int:hospital_id>/favorite', methods=['POST'])
    @login_required
    def toggle_hospital_favorite(hospital_id):
        action = request.form.get('action', 'add')
        note = request.form.get('note', '').strip()
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        with connect_database(deps.database_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM hospitals WHERE id = ?", (hospital_id,))
            if not cursor.fetchone():
                flash('找不到該醫院，無法加入收藏。', 'analyze_error')
                return redirect(url_for('favorites_page'))

            if action == 'remove':
                cursor.execute("""
                    DELETE FROM user_hospital_favorites
                    WHERE user_id = ? AND hospital_id = ?
                """, (current_user.id, hospital_id))
                flash('已從收藏清單移除。', 'analyze_success')
            else:
                cursor.execute("""
                    INSERT INTO user_hospital_favorites(user_id, hospital_id, note, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?)
                    ON CONFLICT(user_id, hospital_id)
                    DO UPDATE SET note = excluded.note, updated_at = excluded.updated_at
                """, (current_user.id, hospital_id, note, now, now))
                flash('已儲存到我的收藏。', 'analyze_success')
            conn.commit()

        return redirect(request.referrer or url_for('favorites_page'))

    @app.route('/api/hospital/<int:hospital_id>/favorite', methods=['POST'])
    @login_required
    def api_toggle_hospital_favorite(hospital_id):
        payload = request.get_json(silent=True) or {}
        action = payload.get('action', 'add')
        note = str(payload.get('note') or '').strip()
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        with connect_database(deps.database_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute("SELECT id, name FROM hospitals WHERE id = ?", (hospital_id,))
            hospital = cursor.fetchone()
            if not hospital:
                return jsonify({'status': 'error', 'message': '找不到該醫院，無法加入收藏。'}), 404

            if action == 'remove':
                cursor.execute("""
                    DELETE FROM user_hospital_favorites
                    WHERE user_id = ? AND hospital_id = ?
                """, (current_user.id, hospital_id))
                is_favorite = False
                message = '已從收藏清單移除。'
            else:
                cursor.execute("""
                    INSERT INTO user_hospital_favorites(user_id, hospital_id, note, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?)
                    ON CONFLICT(user_id, hospital_id)
                    DO UPDATE SET note = excluded.note, updated_at = excluded.updated_at
                """, (current_user.id, hospital_id, note, now, now))
                is_favorite = True
                message = f'已將「{hospital["name"]}」加入收藏。'
            conn.commit()

        return jsonify({'status': 'ok', 'message': message, 'is_favorite': is_favorite})

    @app.route('/favorites/<int:hospital_id>/note', methods=['POST'])
    @login_required
    def update_favorite_note(hospital_id):
        note = request.form.get('note', '').strip()
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with connect_database(deps.database_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE user_hospital_favorites
                SET note = ?, updated_at = ?
                WHERE user_id = ? AND hospital_id = ?
            """, (note, now, current_user.id, hospital_id))
            conn.commit()
        flash('收藏備註已更新。', 'analyze_success')
        return redirect(url_for('favorites_page'))

    @app.route('/hospital/dashboard')
    @login_required
    def hospital_dashboard():
        if getattr(current_user, 'role', None) != 'hospital':
            return redirect(url_for('index'))
        if current_user.approval_status != 'approved' or not current_user.hospital_id:
            flash('醫院帳號尚未通過管理員審核，請等待核准。', 'login_error')
            return redirect(url_for('hospital_application_status'))
        return redirect(url_for('hospital_operations.dashboard'))

    @app.route('/hospital/notifications')
    @login_required
    def hospital_notifications_page():
        if getattr(current_user, 'role', None) != 'hospital':
            flash('只有院方帳號可以查看通知中心。', 'analyze_error')
            return redirect(url_for('index'))

        with connect_database(deps.database_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            if current_user.hospital_id:
                cursor.execute("""
                    SELECT id, title, content, status, category, link_url, created_at
                    FROM hospital_notifications
                    WHERE (
                        (hospital_id = ? AND (user_id IS NULL OR user_id = ?))
                        OR user_id = ?
                    )
                      AND COALESCE(category, 'general') NOT IN ('ai_quota', 'reputation_alert')
                    ORDER BY CASE status WHEN 'unread' THEN 0 ELSE 1 END, id DESC
                """, (current_user.hospital_id, current_user.id, current_user.id))
            else:
                cursor.execute("""
                    SELECT id, title, content, status, category, link_url, created_at
                    FROM hospital_notifications
                    WHERE user_id = ?
                      AND COALESCE(category, 'general') NOT IN ('ai_quota', 'reputation_alert')
                    ORDER BY CASE status WHEN 'unread' THEN 0 ELSE 1 END, id DESC
                """, (current_user.id,))
            notifications = [dict(row) for row in cursor.fetchall()]

        return render_template('hospital_notifications.html', notifications=notifications)

    @app.route('/hospital/notifications/<int:notification_id>/read', methods=['POST'])
    @login_required
    def mark_hospital_notification_read(notification_id):
        if getattr(current_user, 'role', None) != 'hospital':
            return redirect(url_for('index'))

        with connect_database(deps.database_path) as conn:
            cursor = conn.cursor()
            if current_user.hospital_id:
                cursor.execute("""
                    UPDATE hospital_notifications
                    SET status = 'read'
                    WHERE id = ?
                      AND ((hospital_id = ? AND (user_id IS NULL OR user_id = ?)) OR user_id = ?)
                """, (notification_id, current_user.hospital_id, current_user.id, current_user.id))
            else:
                cursor.execute("""
                    UPDATE hospital_notifications
                    SET status = 'read'
                    WHERE id = ? AND user_id = ?
                """, (notification_id, current_user.id))
            conn.commit()

        return redirect(request.referrer or url_for('hospital_notifications_page'))

    @app.route('/hospital/notifications/read_all', methods=['POST'])
    @login_required
    def mark_all_hospital_notifications_read():
        if getattr(current_user, 'role', None) != 'hospital':
            return redirect(url_for('index'))

        with connect_database(deps.database_path) as conn:
            cursor = conn.cursor()
            if current_user.hospital_id:
                cursor.execute("""
                    UPDATE hospital_notifications
                    SET status = 'read'
                    WHERE ((hospital_id = ? AND (user_id IS NULL OR user_id = ?)) OR user_id = ?)
                      AND status = 'unread'
                """, (current_user.hospital_id, current_user.id, current_user.id))
            else:
                cursor.execute("""
                    UPDATE hospital_notifications
                    SET status = 'read'
                    WHERE user_id = ? AND status = 'unread'
                """, (current_user.id,))
            conn.commit()

        flash('所有通知已標記為已讀。', 'analyze_success')
        return redirect(request.referrer or url_for('hospital_notifications_page'))

    @app.route('/hospital/application', methods=['GET', 'POST'])
    @login_required
    def hospital_application_status():
        if getattr(current_user, 'role', None) != 'hospital':
            return redirect(url_for('index'))

        if request.method == 'POST':
            proof_filename = None
            if 'proof_document' in request.files:
                proof_filename, upload_error = deps.save_proof_document(request.files['proof_document'])
                if upload_error:
                    flash(upload_error, 'analyze_error')
                    return redirect(url_for('hospital_application_status'))

            with connect_database(deps.database_path) as conn:
                cursor = conn.cursor()
                fields = (
                    request.form.get('requested_hospital_name', '').replace("臺", "台").strip(),
                    request.form.get('official_email', '').strip(),
                    request.form.get('contact_name', '').strip(),
                    request.form.get('contact_phone', '').strip(),
                    request.form.get('institution_code', '').strip(),
                )
                if proof_filename:
                    cursor.execute("""
                        UPDATE users
                        SET approval_status = 'pending', hospital_id = NULL,
                            requested_hospital_name = ?, official_email = ?, contact_name = ?,
                            contact_phone = ?, institution_code = ?, rejection_reason = NULL,
                            proof_document = ?
                        WHERE id = ? AND role = 'hospital'
                    """, (*fields, proof_filename, current_user.id))
                else:
                    cursor.execute("""
                        UPDATE users
                        SET approval_status = 'pending', hospital_id = NULL,
                            requested_hospital_name = ?, official_email = ?, contact_name = ?,
                            contact_phone = ?, institution_code = ?, rejection_reason = NULL
                        WHERE id = ? AND role = 'hospital'
                    """, (*fields, current_user.id))
                conn.commit()

            logout_user()
            flash('申請資料已重新送出，請等待管理員審核後再登入。', 'register_success')
            return redirect(url_for('login'))

        with connect_database(deps.database_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute("""
                SELECT username, approval_status, requested_hospital_name, official_email,
                       contact_name, contact_phone, institution_code, rejection_reason
                FROM users
                WHERE id = ?
            """, (current_user.id,))
            application = cursor.fetchone()

        return render_template(
            'hospital_application.html',
            application=application,
            all_hospitals=deps.hospital_names,
        )

    @app.route('/hospital/award_application/<int:app_id>/resubmit', methods=['POST'])
    @login_required
    def resubmit_award_application(app_id):
        if getattr(current_user, 'role', None) != 'hospital' or current_user.approval_status != 'approved':
            flash('無權限操作。', 'analyze_error')
            return redirect(url_for('index'))

        department = request.form.get('department', '').strip()
        award_name = request.form.get('award_name', '').strip()
        proof_filename = None

        if not department or not award_name:
            flash('請選擇科別並填寫獎項名稱。', 'analyze_error')
            return redirect(url_for('hospital_profile', hospital_id=current_user.hospital_id))

        if 'proof_document' in request.files:
            proof_filename, upload_error = deps.save_proof_document(request.files['proof_document'])
            if upload_error:
                flash(upload_error, 'analyze_error')
                return redirect(url_for('hospital_profile', hospital_id=current_user.hospital_id))

        with connect_database(deps.database_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute("""
                SELECT id, proof_document FROM hospital_award_applications
                WHERE id = ? AND hospital_id = ? AND status = 'rejected'
            """, (app_id, current_user.hospital_id))
            application = cursor.fetchone()

            if not application:
                flash('找不到該退回紀錄或已無法編輯。', 'analyze_error')
                return redirect(url_for('hospital_profile', hospital_id=current_user.hospital_id))

            final_proof_document = proof_filename or application['proof_document']
            cursor.execute("""
                UPDATE hospital_award_applications
                SET department = ?, award_name = ?, status = 'pending',
                    admin_note = NULL, proof_document = ?, created_at = ?
                WHERE id = ?
            """, (
                department,
                award_name,
                final_proof_document,
                datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                app_id,
            ))
            deps.log_award_application_history(
                cursor,
                app_id,
                'resubmitted',
                '院方修正後重新送審',
                final_proof_document,
                current_user.id,
            )
            conn.commit()

        flash('獎項已修正並重新送出申請，請等待管理員審核。', 'analyze_success')
        return redirect(url_for('hospital_profile', hospital_id=current_user.hospital_id))

    @app.route('/hospital/award_application/<int:app_id>/delete', methods=['POST'])
    @login_required
    def delete_award_application(app_id):
        if getattr(current_user, 'role', None) != 'hospital' or current_user.approval_status != 'approved':
            flash('無權限操作。', 'analyze_error')
            return redirect(url_for('index'))
        if not current_user.hospital_id:
            flash('找不到您的院方資料，無法刪除申請。', 'analyze_error')
            return redirect(url_for('index'))

        with connect_database(deps.database_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute("""
                SELECT id, status FROM hospital_award_applications
                WHERE id = ? AND hospital_id = ?
            """, (app_id, current_user.hospital_id))
            application = cursor.fetchone()

            if not application:
                flash('找不到該申請紀錄，或您沒有權限刪除。', 'analyze_error')
                return redirect(url_for('hospital_profile', hospital_id=current_user.hospital_id))
            if application['status'] != 'rejected':
                flash('只能刪除已退回的申請；審核中的申請請等待管理員處理。', 'analyze_error')
                return redirect(url_for('hospital_profile', hospital_id=current_user.hospital_id))

            cursor.execute(
                "DELETE FROM hospital_award_application_history WHERE application_id = ?",
                (app_id,),
            )
            cursor.execute(
                "DELETE FROM hospital_award_applications WHERE id = ? AND hospital_id = ?",
                (app_id, current_user.hospital_id),
            )
            conn.commit()

        flash('已刪除這筆退回申請。', 'analyze_success')
        return redirect(url_for('hospital_profile', hospital_id=current_user.hospital_id))
